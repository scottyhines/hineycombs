Skip to content
Chat history

You said:
  can you list the sabermeterics and how theu can be applied to executive performance evaution? for instance WAR has direct applications. i am looking at havoc ratio for innovation, but there are ohters. please think about this and return a list of the most promising 
ChatGPT said:
  Absolutely — here is a curated list of sabermetric-style baseball metrics and how each can be analogized to executive performance evaluation, with particular attention to innovation, leadership influence, decision quality, and organizational impact. I’ll highlight the ones that translate most naturally into your SNA- and innovation-heavy environment.

⭐ Top Sabermetric Metrics With High Executive-Performance Analogy Potential
Below are 15 of the most promising, each with:
  
  Baseball meaning

Executive-world translation

Possible data sources in your org (meeting networks, sentiment, innovation climate, performance data, etc.)

How you could compute it

1. WAR — Wins Above Replacement
Baseball: Overall value compared to a replacement-level player.
Executive version: Value Added Beyond Replacement (VABR) or the PABR concept you already created.
Measures things like:
  
  Innovation sentiment lift

Network centrality relative to expected

Team performance changes under the executive

Attrition reduction vs. predicted levels

Business value generated vs. comparable teams

Why it’s great: Composite, intuitive, business leaders “get” it immediately.

2. WPA — Win Probability Added
Baseball: How much a player increases chances of winning with each action.
Executive analogue: Meeting Probability Added (MPA) or Decision Probability Added.

Use-case:
  Quantify contributions in moments that matter:
  
  Participation in key decision meetings

Breaking stalemates

Driving alignment

Unblocking delivery

Data sources: Meeting transcripts, SNA influence edges, topic classification, “moment-of-truth” decisions.

3. RE24 / Run Expectancy Models
Baseball: The change in expected runs given a situation.
Exec analogue: Expected Outcome Lift (EOL).

Think of each meeting/project phase as a “base–out state.”
Executive increases expected positive outcome by (X%).

Data inputs:
  
  S-curves for innovation/decision stages

Influence of leader at key inflection points

Past project outcomes under different leaders

4. BABIP — Batting Average on Balls in Play
Baseball: Measures luck vs skill.
Exec analogue: Execution Efficiency on Controllable Work (EECW).

Is the executive’s success due to:
  
  Good conditions?
  
  Strong support teams?
  
  Favorable projects?
  Or do they consistently convert difficult situations into wins?
  
  Metric: “% of controllable tasks that end in success.”

5. FIP — Fielding Independent Pitching
Baseball: Pitching performance independent of defense.
Exec analogue: Leadership Independent Contribution (LIC).

Removes external support factors:
  
  Strong team

Favorable resources

Organizational tailwinds

Focuses on:
  
  Strategy clarity

Executive presence

Thought leadership

Alignment behavior

Speed / decisiveness

Useful for isolating pure executive skill.

6. OPS+ — Adjusted Production
Baseball: Context-adjusted on-base plus slugging.
Exec analogue: Innovation Production Plus (IP+) or Performance+.

Measures:
  
  Innovation output

Team productivity

Influence centrality

Sentiment

Then adjusts for:
  
  Org complexity

Team size

Technical domain difficulty

Lets you compare teams on a neutral scale.

7. Havoc Ratio
Baseball: % of plays that disrupt the opponent (TFLs, breakups, etc.).
Exec analogue: Innovation Havoc Ratio (IHR).

You’re already developing this. Extend it to capture:
  
  Challenging bureaucracy

Breaking silos

Introducing new ideas

Increasing exploration in oscillation models

Speed of prototype–learn cycles

8. Clutch / Leverage Index
Baseball: Performance in high-pressure moments.
Exec analogue: Clutch Leadership Index (CLI).

Quantifies performance when:
  
  Deadlines loom

Org change happens

AI/strategy pivots

Senior leadership reviews occur

Uses: meeting transcripts, sentiment shifts, SNA snapshots before/after key decisions.

9. DZ Runs Saved / Defensive Metrics
Baseball: Measures preventing negative outcomes.
Exec analogue: Risk Prevention Above Expected (RPAE).

Measures how often the exec:
  
  Prevents failures

Identifies unseen risks

Improves psychological safety

Reduces attrition

Often overlooked but powerful.

10. Plate Discipline Metrics (O-Swing%, Z-Swing%, etc.)
Baseball: Ability to swing at good pitches, avoid bad ones.
Exec analogue: Decision Discipline Index (DDI).

Quantifies:
  
  Stopping low-value work

Avoiding distractions

Prioritization clarity

Saying “no” to noise

Could use meeting transcripts + task logs.

11. Sprint Speed
Baseball: Measures physical speed.
Exec analogue: Execution Speed / Cycle Time.

Metrics:
  
  Time-to-decision

Time-to-alignment

Time-to-resolution

Time-to-innovation milestone

Time between meeting → action → impact

Speed is one of the strongest predictors of team innovation success (per your findings).

12. wOBA — Weighted On-Base Average
Baseball: Weights events by run value.
Exec analogue: Weighted Outcome Impact (wOI).

Different executive actions produce different levels of value:
  
  Aligning org → high weight

Responding to Slack → small weight

Creating a prototype → high

Running a status meeting → low

Lets you separate high-value vs. low-value behavior.

13. Barrel Rate / Hard-Hit %
Baseball: Measures quality of contact.
Exec analogue: Quality of Strategic Contributions (QSC).

“Power” moves of executives:
  
  Strategic insight

Sponsorship

Breaking dependencies

Creating clarity

Setting direction

Weighted by demonstrated downstream impact.

14. Baserunning Runs (BsR)
Baseball: Smart advancement on the bases.
Exec analogue: Organizational Navigation Score (ONS).

Measures "smart movement":
  
  Picking the right partners

Connecting teams

Mentoring across groups

Understanding org politics effectively

Network reach across silos

Great fit with your structural hole work.

15. Expected Stats (xwOBA, xBA, xSLG)
Baseball: Expected outcomes based on contact quality.
Exec analogue: Expected Leadership Impact (xLI).

Based on leading indicators:
  
  Psychological safety

Innovation climate

Network position

Leader behavior ratings

Predicts future team success before it happens.

⭐ BONUS: SNA-Centric Sabermetric Analogues Just For You
Since your org is heavily network-data rich:
  
  16. Expected Influence Added (EIA) — like expected runs
Predicts influence growth based on position in the network.

17. Collaboration WAR (cWAR)
Composite based on:
  
  Betweenness

Cross-team reach

Brokerage quality

Innovation oscillation balance

18. Zone Coverage Efficiency (ZCE) — from defensive “zones”
Measures how broadly an executive “covers” the org:
  
  Breadth of influence

Depth of mentorship

Span of “innovation clusters”

⭐ Summary Table
Baseball Metric	Executive Analogue	What It Measures
WAR	PABR / VABR	Total value added
WPA	MPA	Value in key decisions
RE24	Expected Outcome Lift	Stage-specific impact
BABIP	Execution Efficiency	Skill vs luck
FIP	Leadership Independent Skill	Isolates pure talent
OPS+	Innovation+	Context-adjusted output
Havoc Ratio	Innovation Havoc	Bureaucracy disruption
Clutch	Clutch Leadership	Pressure performance
Defensive Runs	Risk Prevention	Avoiding failures
Plate Discipline	Decision Discipline	Smart prioritization
Sprint Speed	Cycle Time	Speed of execution
wOBA	wOI	Weighted impact
Barrel%	QSC	Quality of big moves
BsR	Org Navigation	Smart network movement
Expected stats	Expected Impact	Leading indicators
If you want, I can also create:
  ✅ A scoring formula for each
✅ An R package-style function to compute these
✅ A composite Executive Sabermetrics Dashboard
✅ A 4-quadrant executive profiling model
✅ Plots comparing leaders to benchmarks

Just tell me which direction you want to go.

You said:
  note. I have basic demographci charateristics such as job level, tenure, georgrapohy, org size, performance ratings, and attration rates. I also have network analytic charactersitcs including centrality metrics and exchanges to a varaity of employee types and orgazations. I aslo have employee senetimrent data on a valrty of employee attitudes that can be used. can you adjust your list with these 
ChatGPT said:
  Absolutely — now that I know exactly what variables you have (demographics, network analytics, sentiment, performance, org structure, attrition), I can refine the list to the metrics that you can actually compute, not just conceptual analogies.

Below is the optimized set of “Executive Sabermetrics” that map directly onto your available data streams.

⭐ Executive Sabermetrics (Fully Computable With Your Data)
Each metric includes:
  
  Source data you already have

What the metric tells you

How to compute it (conceptually)

Why leaders care

These are the most powerful, ordered by practical value and analytic feasibility.

1. PABR — Performance Added Beyond Replacement (WAR analogue)
Inputs:
  ✔ Performance ratings
✔ Innovation sentiment
✔ Network centrality
✔ Attrition rates
✔ Job level & org complexity

Why it works:
  Creates a unified Leader Value Score adjusted for role difficulty.

Compute:
  Standardize all outcome measures → weight them → subtract expected score for role/tenure level.

Interpret:
  “Compared to similar leaders, how much more value does this executive generate?”

2. Havoc Ratio for Innovation
(Your idea, now optimized for available data)

Inputs:
  ✔ Innovation sentiment
✔ Psychological safety
✔ Bureaucracy sentiment
✔ Cross-team interactions
✔ Novel connections formed

Definition:
  % of leader actions that increase innovation potential or break down barriers.

Compute components:
  
  Increases in PS → +1

Increases in innovation sentiment → +1

Cross-org ties formed → +1

Reductions in bureaucracy sentiment → +1

Risk-taking sentiment → +1
Divide by total possible signals.

3. Clutch Leadership Index (High-Leverage Performance)
Inputs:
  ✔ Centrality in critical meetings
✔ Influence on key decisions
✔ Performance around times of org change
✔ Sentiment shifts after leader interventions

Compute:
  Impact during “high leverage” periods (re-org, AI shift, product crisis).
Compare performance during vs outside those periods.

Why useful:
  Some leaders shine during turbulence.

4. Network Expected Influence Added (EIA)
Inputs:
  ✔ Degree, betweenness, closeness
✔ Exchanges with high-value employees
✔ Job level, tenure

Compute:
  Predict expected influence (centrality) for a leader with:
  
  their job level

their org size

their tenure
Then compute: Actual – Expected.

This gives you a “network value added” score.

5. Cross-Team Navigation Score (BsR analogue — Baserunning)
Inputs:
  ✔ Exchanges across org boundaries
✔ Geography
✔ Role hierarchy
✔ Edge diversity
✔ Cross-level ties (skip-levels)

Compute:
  Score for “smart movement” across the org network:
  
  % ties that cross orgs

% ties to senior leaders

% ties to specialized roles

Breadth of division/geo coverage

Weighted composite.

Why important:
  Innovative leaders navigate silos well.

6. Leadership Independent Contribution (LIC — FIP analogue)
Inputs:
  ✔ Sentiment about leader clarity, fairness, empowerment
✔ Team performance
✔ Team attrition
✔ Psychological safety

Goal:
  Isolates the effect attributable to leader behavior, not team luck/resources.

Compute:
  Predict outcomes from team characteristics → subtract from actual outcomes.

7. Decision Discipline Index (Plate Discipline analogue)
Inputs:
  ✔ Meeting transcripts (or proxy from network)
✔ Task completions
✔ Sentiment on prioritization, clarity
✔ Avoidance of “noise” meetings

Compute:
  
  % of connections to high-value partners

% of meeting time linked to strategic topics

Low rate of low-value meeting proliferation

High alignment / clarity sentiment

Indicates a leader’s “swing selection.”

8. Cycle Time Efficiency (Sprint Speed analogue)
Inputs:
  ✔ Meeting → decision → action timestamps
✔ Performance/innovation milestones
✔ Network velocity (new connections formed quickly)

Compute:
  Time required to move from:
  
  Idea → prototype

Problem → alignment

Request → decision

Decision → action

Shorter = better.

9. Weighted Influence Impact (wOI — wOBA analogue)
Inputs:
  ✔ Centrality metrics
✔ Who the leader interacts with (role, level, influence)
✔ Sentiment shifts in connected employees

Compute:
  Each connection type has a different “run value”:
  
  Influencing senior leaders = high weight

Influencing ICs = medium

Influencing peers = medium

No influence exchange = zero

Sum of impacts weighted by importance.

10. Psychological Safety Added (PSA) / Climate Runs Saved
Inputs:
  ✔ Team psychological safety
✔ Sentiment on trust, fairness, autonomy
✔ Attrition signals
✔ Innovation sentiment

Compute:
  How much negative outcome is prevented by improving climate.
Equivalent to “defensive runs saved.”

11. Expected Innovation Impact (xII — expected stats analogue)
Inputs:
  ✔ Innovation climate
✔ PS
✔ Diversity of network ties
✔ Centrality metrics
✔ Team performance

Compute:
  Predict innovation outcomes using leading indicators.
Leader’s xII vs actual identifies:
  
  Overperformers

Underperformers

Hidden innovation capacity

12. Org Complexity Adjusted Score (OPS+ analogue)
Inputs:
  ✔ Team size
✔ Org size
✔ Geography spread
✔ Role difficulty
✔ Band level

Compute:
  Observed performance / expected -> normalized to 100.

Allows comparing managers across wildly different contexts.

13. Structural Hole Exploitation Index (Brokerage advantage)
Inputs:
  ✔ Betweenness centrality
✔ Edge diversity
✔ Bridges created across orgs
✔ Sentiment change among bridged groups

Compute:
  A composite that measures:
  
  How well leaders connect disconnected teams

Whether these connections produce value

Whether those groups’ sentiment improves afterward

14. Attrition Prevention Above Expected (APAE)
Inputs:
  ✔ Team attrition
✔ Org complexity
✔ Tenure
✔ Job level
✔ Network exposure
✔ Climate sentiment

Compute:
  Predicted attrition (role/tenure/org) – actual attrition.
Equivalent to “defensive runs saved” for retention.

15. Situational Influence Added (SIA — WPA analogue)
Inputs:
  ✔ Decision importance (tagged by meeting type)
✔ Who was in the room
✔ Whether alignment was achieved
✔ Sentiment changes following decisions

Compute:
  Value added on high-impact decisions specifically.
Measures performance during “game-changing” moments.

⭐ EXECUTIVE SABERMETRIC SUITE (Optimized for Your Data)
Here is a consolidated table aligned to the data you have:
  
  Metric	Baseball Analogue	Uses Demographics	Uses SNA	Uses Sentiment	Uses Performance/Attrition	What It Measures
PABR	WAR	✔	✔	✔	✔	Total value added
Havoc Ratio	Havoc	✔	✔	✔	–	Innovation disruption
Clutch Leadership Index	Clutch	–	✔	✔	✔	Crisis performance
Expected Influence Added	xWAR	✔	✔	–	–	Network value beyond expected
Cross-Team Navigation Score	BsR	✔	✔	–	–	Smart movement across orgs
Leadership Independent Contribution	FIP	✔	–	✔	✔	Pure leader effect
Decision Discipline Index	Plate discipline	–	✔	✔	–	Prioritization clarity
Cycle Time Efficiency	Sprint speed	–	✔	–	✔	Speed to action
Weighted Influence Impact	wOBA	–	✔	✔	–	Quality of network influence
Climate Runs Saved	DRS	✔	–	✔	✔	Risk prevention via climate
Expected Innovation Impact	xwOBA	✔	✔	✔	✔	Predicted innovation
OPS+ for Execs	OPS+	✔	–	✔	✔	Adjusted performance
Structural Hole Exploitation	Defensive positioning	–	✔	✔	–	Brokerage value
Attrition Prevention Above Expected	DRS	✔	–	✔	✔	Retention value
Situational Influence Added	WPA	–	✔	✔	✔	Impact during key decisions
If you want next:
  I can produce:
  
  ✅ A scoring formula for each metric
✅ Suggested weights for a composite “Executive Sabermetric Scorecard”
✅ R code to compute all 15 metrics on your data
✅ A 1–2 page executive summary explaining the whole framework
Just tell me what direction you want to take next.

You said:
  For each of these, using R, can you mock up a dataset and produce syntax that would show how it would work? 2. Havoc Ratio for Innovation

(Your idea, now optimized for available data)

Inputs:
  ✔ Innovation sentiment
✔ Psychological safety
✔ Bureaucracy sentiment
✔ Cross-team interactions
✔ Novel connections formed

Definition:
  % of leader actions that increase innovation potential or break down barriers.

Compute components:
  
  Increases in PS → +1

Increases in innovation sentiment → +1

Cross-org ties formed → +1

Reductions in bureaucracy sentiment → +1

Risk-taking sentiment → +1
Divide by total possible signals.

3. Clutch Leadership Index (High-Leverage Performance)

Inputs:
  ✔ Centrality in critical meetings
✔ Influence on key decisions
✔ Performance around times of org change
✔ Sentiment shifts after leader interventions

Compute:
  Impact during “high leverage” periods (re-org, AI shift, product crisis).
Compare performance during vs outside those periods.

Why useful:
  Some leaders shine during turbulence.

4. Network Expected Influence Added (EIA)

Inputs:
  ✔ Degree, betweenness, closeness
✔ Exchanges with high-value employees
✔ Job level, tenure

Compute:
  Predict expected influence (centrality) for a leader with:
  
  their job level

their org size

their tenure
Then compute: Actual – Expected.

This gives you a “network value added” score.

5. Cross-Team Navigation Score (BsR analogue — Baserunning)

Inputs:
  ✔ Exchanges across org boundaries
✔ Geography
✔ Role hierarchy
✔ Edge diversity
✔ Cross-level ties (skip-levels)

Compute:
  Score for “smart movement” across the org network:
  
  % ties that cross orgs

% ties to senior leaders

% ties to specialized roles

Breadth of division/geo coverage

Weighted composite.

Why important:
  Innovative leaders navigate silos well.

6. Leadership Independent Contribution (LIC — FIP analogue)

Inputs:
  ✔ Sentiment about leader clarity, fairness, empowerment
✔ Team performance
✔ Team attrition
✔ Psychological safety

Goal:
  Isolates the effect attributable to leader behavior, not team luck/resources.

Compute:
  Predict outcomes from team characteristics → subtract from actual outcomes.

10. Psychological Safety Added (PSA) / Climate Runs Saved

Inputs:
  ✔ Team psychological safety
✔ Sentiment on trust, fairness, autonomy
✔ Attrition signals
✔ Innovation sentiment

Compute:
  How much negative outcome is prevented by improving climate.
Equivalent to “defensive runs saved.”

11. Expected Innovation Impact (xII — expected stats analogue)

Inputs:
  ✔ Innovation climate
✔ PS
✔ Diversity of network ties
✔ Centrality metrics
✔ Team performance

Compute:
  Predict innovation outcomes using leading indicators.
Leader’s xII vs actual identifies:
  
  Overperformers

Underperformers

Hidden innovation capacity

12. Org Complexity Adjusted Score (OPS+ analogue)

Inputs:
  ✔ Team size
✔ Org size
✔ Geography spread
✔ Role difficulty
✔ Band level

Compute:
  Observed performance / expected -> normalized to 100.

Allows comparing managers across wildly different contexts.

13. Structural Hole Exploitation Index (Brokerage advantage)

Inputs:
  ✔ Betweenness centrality
✔ Edge diversity
✔ Bridges created across orgs
✔ Sentiment change among bridged groups

Compute:
  A composite that measures:
  
  How well leaders connect disconnected teams

Whether these connections produce value

Whether those groups’ sentiment improves afterward

14. Attrition Prevention Above Expected (APAE)

Inputs:
  ✔ Team attrition
✔ Org complexity
✔ Tenure
✔ Job level
✔ Network exposure
✔ Climate sentiment

Compute:
  Predicted attrition (role/tenure/org) – actual attrition.
Equivalent to “defensive runs saved” for retention.
ChatGPT said:
  Below is fully runnable, self-contained R code for each metric you listed.
Every section includes:
  
  Mock dataset creation

Calculation syntax

Interpretation

You can paste each block directly into R and execute.

📦 Setup
library(dplyr)
library(tidyr)
library(purrr)
library(broom)
set.seed(123)
2️⃣ HAVOC RATIO FOR INNOVATION
Mock Data
leaders <- tibble(
  leader_id = 1:50,
  delta_ps = rnorm(50, mean = 0.1, sd = 0.3),              # Psychological safety change
  delta_innov = rnorm(50, mean = 0.15, sd = 0.25),         # Innovation sentiment change
  delta_bureau = rnorm(50, mean = -0.05, sd = 0.2),        # Bureaucracy (negative = good)
  cross_org_ties = rpois(50, lambda = 3),                  # New cross-team connections
  novel_connections = rpois(50, lambda = 2),               # Unique new partners
  risk_taking_sent = rnorm(50, 0.05, 0.2)                  # Risk sentiment change
)
Compute HAVOC Score
leaders <- leaders %>%
  mutate(
    signal_ps = delta_ps > 0,
    signal_innov = delta_innov > 0,
    signal_bureau = delta_bureau < 0,
    signal_cross = cross_org_ties > 0,
    signal_novel = novel_connections > 0,
    signal_risk = risk_taking_sent > 0,
    total_signals = 6,
    havoc_score = (signal_ps + signal_innov + signal_bureau +
                     signal_cross + signal_novel + signal_risk) / total_signals
  )
leaders %>% select(leader_id, havoc_score)
3️⃣ CLUTCH LEADERSHIP INDEX (HIGH-LEVERAGE PERFORMANCE)
High leverage = periods of re-org, AI shift, crisis, etc.

Mock Data
clutch <- tibble(
  leader_id = 1:50,
  performance_high = rnorm(50, 3.5, 0.7),   # performance during high-leverage period
  performance_low  = rnorm(50, 3.2, 0.5),   # performance in normal periods
  centrality_high = rnorm(50, 0.6, 0.15),
  sentiment_shift_high = rnorm(50, 0.1, 0.25)
)
Compute Clutch Score
clutch <- clutch %>%
  mutate(
    performance_diff = performance_high - performance_low,
    clutch_index = scale(performance_diff + centrality_high + sentiment_shift_high)
  )

clutch %>% select(leader_id, clutch_index)
4️⃣ EXPECTED INFLUENCE ADDED (EIA)
Mock Data
inf <- tibble(
  leader_id = 1:50,
  degree = rnorm(50, 20, 5),
  betweenness = rnorm(50, 0.15, 0.05),
  closeness = rnorm(50, 0.25, 0.06),
  job_level = sample(4:10, 50, replace = TRUE),
  tenure_months = sample(12:180, 50, replace = TRUE),
  org_size = sample(50:500, 50, replace = TRUE)
)
Predict Expected Influence Given Role/Context
model <- lm(degree ~ job_level + tenure_months + org_size, data = inf)

inf <- inf %>%
  mutate(
    expected_degree = predict(model),
    eia = degree - expected_degree
  )

inf %>% select(leader_id, eia)
5️⃣ CROSS-TEAM NAVIGATION SCORE (SMART MOVEMENT)
Mock Data
nav <- tibble(
  leader_id = 1:50,
  ties_cross_org = rpois(50, 5),
  ties_total = rpois(50, 15) + 5,
  ties_to_senior = rpois(50, 2),
  ties_to_specialists = rpois(50, 3),
  geo_span = sample(1:5, 50, replace = TRUE),       # number of countries/regions touched
  edge_diversity = runif(50, 0.2, 1.0)              # Shannon diversity index proxy
)
Compute Navigation Score
nav <- nav %>%
  mutate(
    pct_cross_org = ties_cross_org / ties_total,
    pct_senior = ties_to_senior / ties_total,
    pct_specialist = ties_to_specialists / ties_total,
    nav_score = scale(
      0.4*pct_cross_org +
        0.2*pct_senior +
        0.2*pct_specialist +
        0.1*geo_span +
        0.1*edge_diversity
    )
  )

nav %>% select(leader_id, nav_score)
6️⃣ LEADERSHIP INDEPENDENT CONTRIBUTION (LIC)
Remove team/context effects → isolate leader effect.

Mock Data
lic <- tibble(
  leader_id = 1:50,
  clarity = rnorm(50, 0.5, 0.3),
  fairness = rnorm(50, 0.4, 0.25),
  empowerment = rnorm(50, 0.45, 0.28),
  psych_safety = rnorm(50, 0.5, 0.25),
  team_perf = rnorm(50, 3.2, 0.4),
  team_complexity = rnorm(50, 1.5, 0.5),
  team_size = sample(5:50, 50, replace = TRUE)
)
Predict Team Performance From Team Factors Only
perf_model <- lm(team_perf ~ team_complexity + team_size, data = lic)

lic <- lic %>%
  mutate(
    expected_perf = predict(perf_model),
    leader_effect = team_perf - expected_perf,
    lic = scale(leader_effect + clarity + fairness + empowerment + psych_safety)
  )

lic %>% select(leader_id, lic)
🔟 PSYCHOLOGICAL SAFETY ADDED (PSA)
Equivalent to “defensive runs saved.”

Mock Data
psa <- tibble(
  leader_id = 1:50,
  psych_safety = rnorm(50, 0.5, 0.25),
  trust = rnorm(50, 0.5, 0.2),
  autonomy = rnorm(50, 0.5, 0.2),
  fairness = rnorm(50, 0.5, 0.2),
  attrition_rate = runif(50, 0.05, 0.25)
)
Predict Attrition From Context; subtract Actual
attr_model <- lm(attrition_rate ~ trust + fairness, data = psa)

psa <- psa %>%
  mutate(
    expected_attrition = predict(attr_model),
    psa = expected_attrition - attrition_rate   # reduction compared to expected
  )

psa %>% select(leader_id, psa)
1️⃣1️⃣ EXPECTED INNOVATION IMPACT (xII)
Predict innovation from leading indicators.

Mock Data
xii <- tibble(
  leader_id = 1:50,
  innov_climate = rnorm(50, 0.6, 0.2),
  psych_safety = rnorm(50, 0.5, 0.25),
  tie_diversity = runif(50, 0.2, 1.0),
  centrality = rnorm(50, 0.3, 0.1),
  team_perf = rnorm(50, 3.2, 0.4),
  actual_innov = rnorm(50, 0.6, 0.25)
)
Build Expected Innovation Model
innov_model <- lm(actual_innov ~ innov_climate + psych_safety +
                    tie_diversity + centrality + team_perf, data = xii)

xii <- xii %>%
  mutate(
    expected_innov = predict(innov_model),
    xii_residual = actual_innov - expected_innov
  )

xii %>% select(leader_id, xii_residual)
1️⃣2️⃣ ORG COMPLEXITY ADJUSTED SCORE (OPS+ analogue)
Normalize performance to 100 (like OPS+).

Mock Data
ops <- tibble(
  leader_id = 1:50,
  team_perf = rnorm(50, 3.3, 0.5),
  team_size = sample(5:50, 50, replace = TRUE),
  org_size = sample(50:500, 50, replace = TRUE),
  geography_count = sample(1:5, 50, replace = TRUE),
  role_difficulty = rnorm(50, 1.5, 0.4)
)
Predict Expected Performance
ops_model <- lm(team_perf ~ team_size + org_size + geography_count + role_difficulty, data = ops)

ops <- ops %>%
  mutate(
    expected_perf = predict(ops_model),
    ops_plus = 100 * (team_perf / expected_perf)
  )

ops %>% select(leader_id, ops_plus)
1️⃣3️⃣ STRUCTURAL HOLE EXPLOITATION INDEX
Mock Data
holes <- tibble(
  leader_id = 1:50,
  betweenness = rnorm(50, 0.15, 0.05),
  edge_diversity = runif(50, 0.3, 1.0),
  bridges_cross_org = rpois(50, 4),
  sentiment_change = rnorm(50, 0.05, 0.2)
)
Compute Composite Score
holes <- holes %>%
  mutate(
    hole_score = scale(
      0.4*betweenness +
        0.2*edge_diversity +
        0.2*bridges_cross_org +
        0.2*sentiment_change
    )
  )

holes %>% select(leader_id, hole_score)
1️⃣4️⃣ ATTRITION PREVENTION ABOVE EXPECTED (APAE)
Retention = defense.

Mock Data
apae <- tibble(
  leader_id = 1:50,
  attrition_rate = runif(50, 0.05, 0.25),
  job_level = sample(4:10, 50, replace = TRUE),
  tenure = sample(12:180, 50, replace = TRUE),
  org_complexity = rnorm(50, 1.5, 0.5),
  network_exposure = rnorm(50, 0.4, 0.1),
  climate_sentiment = rnorm(50, 0.6, 0.2)
)
Predict Expected Attrition Given Context
attr_model2 <- lm(attrition_rate ~ job_level + tenure + org_complexity +
                    network_exposure + climate_sentiment, data = apae)

apae <- apae %>%
  mutate(
    expected_attrition = predict(attr_model2),
    apae_score = expected_attrition - attrition_rate
  )

apae %>% select(leader_id, apae_score)
✅ If you want next:
  I can produce:
  
  ✔ A single combined dataset with all scores
✔ Functions (e.g., calculate_havoc()) for your hineycombs package
✔ A unified “Executive Sabermetrics Dashboard”
✔ ggplot visualizations for each metric
✔ Code to apply these to your real data
Just tell me the direction you’d like to take.

You said:
  note that all of these leaders are in differnet areas of a large organization. please adjust as needed. The area is denoted by OL3
ChatGPT said:
  Great note — when leaders come from different areas of a large organization, denoted by OL3, that changes the modeling in important ways:
  
  ✔ Performance expectations differ by organizational context
✔ Innovation climates vary by org
✔ Network structures differ across org units
✔ Attrition norms differ by org
✔ Resource levels and job demands vary by org
Therefore each sabermetric must do one or more of these adjustments:
  
  Control for OL3 (include as predictor in regression models)

Include OL3 random effects (mixed models)

Compute scores within OL3, then standardize across OL3

Use hierarchical centering (leader minus OL3 mean)

I will now revise EACH metric's R code to include OL3 appropriately.

You’ll get:

Updated mock data (with OL3)

Updated models that adjust for OL3

Updated score calculations

📦 Setup
library(dplyr)
library(tidyr)
library(purrr)
library(broom)
library(lme4)
set.seed(123)
🟦 Include OL3 in All Datasets
Every dataset below includes:

OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE)   # five organizational areas
2️⃣ HAVOC RATIO FOR INNOVATION (Adjusted for OL3)
Mock Data
leaders <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  delta_ps = rnorm(50, 0.1, 0.3),
  delta_innov = rnorm(50, 0.15, 0.25),
  delta_bureau = rnorm(50, -0.05, 0.2),
  cross_org_ties = rpois(50, 3),
  novel_connections = rpois(50, 2),
  risk_taking_sent = rnorm(50, 0.05, 0.2)
)
HAVOC Score (Same Formula; OL3 Affects Interpretation)
We calculate HAVOC unchanged, but we standardize within OL3 to account for org differences.

leaders <- leaders %>%
  mutate(
    signal_ps = delta_ps > 0,
    signal_innov = delta_innov > 0,
    signal_bureau = delta_bureau < 0,
    signal_cross = cross_org_ties > 0,
    signal_novel = novel_connections > 0,
    signal_risk = risk_taking_sent > 0,
    havoc_raw = (signal_ps + signal_innov + signal_bureau +
                 signal_cross + signal_novel + signal_risk) / 6
  ) %>%
  group_by(OL3) %>%
  mutate(havoc_score = scale(havoc_raw)[,1]) %>%
  ungroup()
3️⃣ CLUTCH LEADERSHIP INDEX (Adjusted for OL3)
Performance expectations shift by OL3 — use mixed-effects model.

Mock Data
clutch <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  performance_high = rnorm(50, 3.5, 0.7),
  performance_low  = rnorm(50, 3.2, 0.5),
  centrality_high = rnorm(50, 0.6, 0.15),
  sentiment_shift_high = rnorm(50, 0.1, 0.25)
)
Clutch Score (Mixed Model)
clutch <- clutch %>%
  mutate(perf_diff = performance_high - performance_low)

# Mixed model controls for OL3 differences
m_clutch <- lmer(perf_diff ~ centrality_high + sentiment_shift_high + (1 | OL3),
                 data = clutch)

clutch$clutch_index <- scale(residuals(m_clutch))[,1]
4️⃣ EXPECTED INFLUENCE ADDED (EIA) With OL3 Controls
Mock Data
inf <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  degree = rnorm(50, 20, 5),
  betweenness = rnorm(50, 0.15, 0.05),
  closeness = rnorm(50, 0.25, 0.06),
  job_level = sample(4:10, 50, TRUE),
  tenure_months = sample(12:180, 50, TRUE),
  org_size = sample(50:500, 50, TRUE)
)
EIA Using Mixed Model
m_inf <- lmer(degree ~ job_level + tenure_months + org_size + (1 | OL3), data = inf)

inf <- inf %>%
  mutate(
    expected_degree = predict(m_inf),
    eia = degree - expected_degree
  )
5️⃣ CROSS-TEAM NAVIGATION SCORE (Standardized by OL3)
Mock Data
nav <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  ties_cross_org = rpois(50, 5),
  ties_total = rpois(50, 15) + 5,
  ties_to_senior = rpois(50, 2),
  ties_to_specialists = rpois(50, 3),
  geo_span = sample(1:5, 50, TRUE),
  edge_diversity = runif(50, 0.2, 1.0)
)
Navigation Score
nav <- nav %>%
  mutate(
    pct_cross_org = ties_cross_org / ties_total,
    pct_senior = ties_to_senior / ties_total,
    pct_specialist = ties_to_specialists / ties_total,
    nav_raw = (0.4*pct_cross_org + 0.2*pct_senior +
               0.2*pct_specialist + 0.1*geo_span + 0.1*edge_diversity)
  ) %>%
  group_by(OL3) %>%
  mutate(nav_score = scale(nav_raw)[,1]) %>%
  ungroup()
6️⃣ LEADERSHIP INDEPENDENT CONTRIBUTION (LIC) Adapting for OL3
Mock Data
lic <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  clarity = rnorm(50, 0.5, 0.3),
  fairness = rnorm(50, 0.4, 0.25),
  empowerment = rnorm(50, 0.45, 0.28),
  psych_safety = rnorm(50, 0.5, 0.25),
  team_perf = rnorm(50, 3.2, 0.4),
  team_complexity = rnorm(50, 1.5, 0.5),
  team_size = sample(5:50, 50, TRUE)
)
LIC Mixed Model
m_perf <- lmer(team_perf ~ team_complexity + team_size + (1 | OL3), data = lic)

lic <- lic %>%
  mutate(
    expected_perf = predict(m_perf),
    leader_effect = team_perf - expected_perf,
    lic = scale(leader_effect + clarity + fairness + empowerment + psych_safety)[,1]
  )
1️⃣0️⃣ PSYCHOLOGICAL SAFETY ADDED (PSA) Adjusted for OL3
Mock Data
psa <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  psych_safety = rnorm(50, 0.5, 0.25),
  trust = rnorm(50, 0.5, 0.2),
  autonomy = rnorm(50, 0.5, 0.2),
  fairness = rnorm(50, 0.5, 0.2),
  attrition_rate = runif(50, 0.05, 0.25)
)
Attrition Mixed Model
m_attr <- lmer(attrition_rate ~ trust + fairness + (1 | OL3), data = psa)

psa <- psa %>%
  mutate(
    expected_attrition = predict(m_attr),
    psa_score = expected_attrition - attrition_rate
  )
1️⃣1️⃣ EXPECTED INNOVATION IMPACT (xII) Adjusted for OL3
Mock Data
xii <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  innov_climate = rnorm(50, 0.6, 0.2),
  psych_safety = rnorm(50, 0.5, 0.25),
  tie_diversity = runif(50, 0.2, 1.0),
  centrality = rnorm(50, 0.3, 0.1),
  team_perf = rnorm(50, 3.2, 0.4),
  actual_innov = rnorm(50, 0.6, 0.25)
)
Mixed Model for Innovation
m_innov <- lmer(actual_innov ~ innov_climate + psych_safety +
                  tie_diversity + centrality + team_perf + (1 | OL3),
                data = xii)

xii <- xii %>%
  mutate(
    expected_innov = predict(m_innov),
    xii_residual = actual_innov - expected_innov
  )
1️⃣2️⃣ ORG COMPLEXITY ADJUSTED SCORE (OPS+) WITH OL3
Mock Data
ops <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  team_perf = rnorm(50, 3.3, 0.5),
  team_size = sample(5:50, 50, TRUE),
  org_size = sample(50:500, 50, TRUE),
  geography_count = sample(1:5, 50, TRUE),
  role_difficulty = rnorm(50, 1.5, 0.4)
)
Mixed Model + OPS+ Formula
m_ops <- lmer(team_perf ~ team_size + org_size + geography_count +
                role_difficulty + (1 | OL3), data = ops)

ops <- ops %>%
  mutate(
    expected_perf = predict(m_ops),
    ops_plus = 100 * (team_perf / expected_perf)
  )
1️⃣3️⃣ STRUCTURAL HOLE EXPLOITATION (SHI) Standardized by OL3
Mock Data
holes <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  betweenness = rnorm(50, 0.15, 0.05),
  edge_diversity = runif(50, 0.3, 1.0),
  bridges_cross_org = rpois(50, 4),
  sentiment_change = rnorm(50, 0.05, 0.2)
)
Compute SHI (within OL3)
holes <- holes %>%
  mutate(
    shi_raw = (0.4*betweenness + 0.2*edge_diversity +
               0.2*bridges_cross_org + 0.2*sentiment_change)
  ) %>%
  group_by(OL3) %>%
  mutate(shi_score = scale(shi_raw)[,1]) %>%
  ungroup()
1️⃣4️⃣ APAE (Attrition Prevention Above Expected) With OL3
Mock Data
apae <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  attrition_rate = runif(50, 0.05, 0.25),
  job_level = sample(4:10, 50, TRUE),
  tenure = sample(12:180, 50, TRUE),
  org_complexity = rnorm(50, 1.5, 0.5),
  network_exposure = rnorm(50, 0.4, 0.1),
  climate_sentiment = rnorm(50, 0.6, 0.2)
)
Mixed Model
m_apae <- lmer(attrition_rate ~ job_level + tenure + org_complexity +
                 network_exposure + climate_sentiment + (1 | OL3),
               data = apae)

apae <- apae %>%
  mutate(
    expected_attrition = predict(m_apae),
    apae_score = expected_attrition - attrition_rate
  )
✅ Done
Every sabermetric metric now:

Controls for organizational area (OL3)

Uses mixed-effects models where appropriate

Standardizes within OL3 where comparisons shouldn’t cross org boundaries

Produces scores that fairly compare leaders in very different contexts

👉 If you want next:
I can create:

✔ A single combined sabermetrics dataset joining all metrics
✔ A set of functions (e.g., calculate_eia()) for your hineycombs R package
✔ Visualization templates (heatmaps, radar charts, leader benchmarking plots)
✔ A two-page “Executive Sabermetrics” explanation to share with senior leadership
Just tell me which one you want.

You said:
this is good, but can you provide a description of each variable used (e.g., "delta") and the premise of the model as shown previously? That is if iti is delta i will need to do more data engineering
ChatGPT said:
Absolutely — here is a clear, comprehensive description of every variable used across all models, along with the analytic premise for each sabermetric metric.
This is written assuming you will later engineer the necessary deltas, rates, and derived network attributes from your real data.

Below, I break it into two parts:

PART 1 — Glossary of All Variables (Clear Definitions)
Below is a complete variable dictionary for everything used in the R code.
I focus on how these variables should exist in your real organizational dataset, what they represent theoretically, and what data engineering steps may be needed.

🎯 A. Innovation & Sentiment Variables
delta_ps
Definition: Change in psychological safety for a leader’s team between two periods (e.g., Q1 → Q2).

Purpose: Used to evaluate whether a leader’s environment became safer for speaking up.

Data engineering:

Compute: ps_post - ps_pre at the team level.

Source: Employee sentiment surveys or pulse surveys.

delta_innov
Definition: Change in innovation sentiment (team belief that they innovate or can innovate).

Purpose: Part of Innovation Havoc score — improvement implies successful innovation behaviors.

Data engineering:

Compute: innovation_sent_post - innovation_sent_pre.

delta_bureau
Definition: Change in bureaucracy sentiment (bureaucracy decreasing is good).

Purpose: Lower bureaucracy → fewer barriers to innovation.

Data engineering:

Compute: bureau_post - bureau_pre

NOTE: Havoc uses delta_bureau < 0 as a positive signal.

risk_taking_sent
Definition: Change in risk-taking sentiment (team comfort with experimentation).

Purpose: Proxy for innovation readiness.

Engineering:

Could be delta-based (post - pre)

Or single-wave sentiment.

🎯 B. Network Variables
cross_org_ties
Definition: Number of new ties formed outside the leader’s organizational unit (OL3).

Purpose: A leader who creates cross-team collaboration increases innovation surface area.

Data engineering:

Need edge list with from/to nodes + OL3 for each node

Identify new cross-team ties relative to previous time period.

novel_connections
Definition: New unique connections the leader did not have in the previous time period.

Purpose: Measures network expansion, a key innovation behavior.

Engineering:

Compare adjacency lists across time windows.

degree, betweenness, closeness
Definition: Standard network centrality metrics for each leader.

Purpose: Used in Expected Influence Added (EIA).

Engineering:

Compute using igraph or tidygraph.

ties_cross_org, ties_total, ties_to_senior, ties_to_specialists
Definition: Counts of different kinds of network ties the leader maintains.

Purpose: Inputs to the Cross-Team Navigation score.

Engineering:

Need role metadata for each node in the graph (level, OL3, role type).

edge_diversity
Definition: A diversity score for partner organizations/types.

Purpose: Captures structural hole bridging.

Engineering:

Can compute Shannon Entropy of partner categories.

centrality_high
Definition: Leader’s centrality during high-leverage periods (reorgs, AI transitions).

Engineering:

Compute centrality on subgraphs filtered to “critical meeting types” or “crisis weeks.”

bridges_cross_org
Definition: Number of times the leader connects two otherwise disconnected org units.

Engineering:

Block-modeling or brokerage algorithms (Burt constraint, effective size).

🎯 C. Performance Variables
performance_high, performance_low
Definition: Leader performance (their team’s performance) during high vs low leverage periods.

Purpose: Clutch Leadership Index compares impact when stakes are high.

Engineering:

Tag time periods with “critical” or “normal” labels.

Compute moving averages or quarterly ratings.

team_perf
Definition: Overall performance rating of the leader’s team.

Purpose: Used in LIC, Expected Innovation Impact, OPS+.

Engineering:

From performance management system.

expected_perf
Definition: Model-predicted performance using team characteristics, NOT leader behaviors.

Purpose: Baseline for LIC metric.

team_complexity
Definition: Complexity of work the team performs (e.g., number of domains, cross-team dependencies).

Engineering:

Could be coded as:

of product lines owned
of dependent systems
of customers
Or composite.

role_difficulty
Definition: Difficulty of the leader’s role based on technical depth, scale, and ambiguity.

Engineering:

Could be mapped from job families, L6 vs L7 complexity, etc.

attrition_rate
Definition: Actual attrition rate of the leader’s team.

Engineering:

Rolling 6 months or 12 months.

expected_attrition
Definition: Predicted attrition from model that uses context but not leader behavior.

Purpose: APAE score = expected – actual (attrition prevented).

team_size, org_size, geography_count
Definition: Contextual features of the leader’s team.

Purpose: Used in OPS+ to adjust performance expected for a team of that complexity.

job_level, tenure, tenure_months
Definition: Demographics of the leader.

Purpose: Predict expected network centrality or attrition.

🎯 D. Innovation Impact Variables
innov_climate
Definition: Team perception of innovation climate (resources, time, psychological safety).

Purpose: Strong predictor of actual innovation.

actual_innov
Definition: Output measure of innovation (e.g., projects, prototypes, impact score).

Engineering:

Could be from your Innovation Sentiment Scale + objective outcomes.

expected_innov
Definition: Model prediction of innovation using leading indicators.

Purpose: Compare actual vs expected to find outperformers.

🎯 E. OL3 Variable
OL3
Definition: The organizational area the leader sits in (e.g., Cloud Infrastructure, Payments, Retail Experience).

Purpose:

Controls for differences in environment, culture, resource levels, and network topology.

Model Usage:

Random effect in mixed models

Standardization within OL3 when comparing leaders across orgs

PART 2 — Premise of Each Sabermetric Model (Conceptual Logic)
This explains why each model looks the way it does and how OL3 fits.

2️⃣ HAVOC RATIO FOR INNOVATION
Premise
Innovation happens when leaders increase enabling conditions and reduce barriers.
HAVOC captures how often a leader creates positive turbulence:

boosts psychological safety

boosts innovation sentiment

reduces bureaucracy

expands cross-team connections

encourages risk taking

OL3 Adjustment
Different parts of the org start from different baselines.
→ Standardize HAVOC within OL3 so leaders aren’t penalized for their org’s starting point.

3️⃣ CLUTCH LEADERSHIP INDEX
Premise
Some leaders perform exceptionally when stakes are highest (reorgs, AI pivots).
The model compares:

performance during high leverage periods vs low

adjusted for sentiment and centrality during crises

controlling for OL3 context

OL3 Adjustment
Crisis intensity varies across orgs → use OL3 random effects.

4️⃣ EXPECTED INFLUENCE ADDED (EIA)
Premise
A leader’s network influence is partly driven by:

job level

tenure

organization size
The EIA score shows:
How much influence the leader has beyond what their role predicts.

OL3 Adjustment
Network structures differ widely by org.
→ Add (1 | OL3) random effect.

5️⃣ CROSS-TEAM NAVIGATION SCORE
Premise
Innovative leaders navigate silos effectively.
The model rewards:

cross-org interactions

upward influence

specialist interactions

geographic breadth

diverse network categories

OL3 Adjustment
Some orgs naturally collaborate more → standardize within OL3.

6️⃣ LEADERSHIP INDEPENDENT CONTRIBUTION (LIC)
Premise
Team performance is influenced by:

team size

team complexity

org context (OL3)
To isolate leader effect, subtract expected performance based on these features.

OL3 Adjustment
Large orgs differ in complexity → use OL3 as random intercept.

🔟 PSYCHOLOGICAL SAFETY ADDED (PSA)
Premise
Low psychological safety = higher attrition and lower innovation.
This score quantifies how much attrition a leader prevented given expected rates.

OL3 Adjustment
Some orgs have higher baseline attrition → use mixed model.

1️⃣1️⃣ EXPECTED INNOVATION IMPACT (xII)
Premise
Innovation output can be predicted using:

innovation climate

psychological safety

centrality

tie diversity

performance
xII = difference between actual and expected innovation.

OL3 Adjustment
Different orgs have different innovation baselines → random effect.

1️⃣2️⃣ OPS+ (Org Performance Score plus)
Premise
Performance must be normalized for:

team size

org size

geography

difficulty
OPS+ = 100 = expected performance.

OL3 Adjustment
Some orgs have harder roles or more ambiguity → mixed model.

1️⃣3️⃣ STRUCTURAL HOLE EXPLOITATION (SHI)
Premise
A leader who connects groups that otherwise wouldn’t collaborate has high brokerage value.
Score combines:

betweenness

diversity of ties

cross-org bridges

sentiment impact

OL3 Adjustment
Brokerage opportunities differ by org → standardize within OL3.

1️⃣4️⃣ APAE (Attrition Prevention Above Expected)
Premise
Leader impact on retention is measured by:

expected attrition (role, tenure, climate)

minus actual attrition
Positive = leader retains talent beyond expectations.

OL3 Adjustment
Different orgs have different retention norms → mixed model.

✅ NEXT STEPS
I can now produce:

✔ A single combined sabermetrics table
✔ R functions for each metric (hineycombs-ready)
✔ Data engineering steps to compute all “delta” or network-derived variables
✔ Visualizations for each metric (e.g., ggplot comparisons)
Just tell me where you'd like to go next.

You said:
  can you add these as short # descriptions to the R code that you provided? also add the datasets that would be need to create and the engineering of these variables 
ChatGPT said:
  Absolutely — below is the fully annotated R code, now including:
  
  ✔ Short # descriptions for each variable
✔ Descriptions of the model premise
✔ Descriptions of the datasets needed
✔ Descriptions of data engineering steps required
✔ All code blocks updated to include OL3 adjustments
✔ All comments placed exactly where you would expect in a real script

You can paste this entire section into an R script and it will read like a fully documented analytic file.

✅ EXECUTIVE SABERMETRICS — FULLY COMMENTED R SCRIPT
------------------------------------------------------------
  📦 SETUP
------------------------------------------------------------
  library(dplyr)
library(tidyr)
library(purrr)
library(broom)
library(lme4)

set.seed(123)
============================================================
  2️⃣ HAVOC RATIO FOR INNOVATION (Adjusted for OL3)
============================================================
  # ------------------------------------------------------------
# DATA REQUIRED (REAL SYSTEM)
# ------------------------------------------------------------
# • Sentiment survey data by leader/team across multiple timepoints
# • Network edge file with OL3 (org area) for each node
# • Derived cross-team tie counts
# • Risk-taking sentiment scores or delta values
#
# ENGINEERING NEEDED
# • delta_ps        = PS_post - PS_pre
# • delta_innov     = innov_post - innov_pre
# • delta_bureau    = bureau_post - bureau_pre  (negative = good)
# • cross_org_ties  = count of new cross-OL3 ties formed in period
# • novel_connections = unique new partner nodes since last period
# • risk_taking_sent = risk_sent_post - risk_sent_pre
# ------------------------------------------------------------

leaders <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  
  # Δ psychological safety (post - pre)
  delta_ps = rnorm(50, 0.1, 0.3),
  
  # Δ innovation sentiment (post - pre)
  delta_innov = rnorm(50, 0.15, 0.25),
  
  # Δ bureaucracy (negative = improvement)
  delta_bureau = rnorm(50, -0.05, 0.2),
  
  # New cross-org ties created this period
  cross_org_ties = rpois(50, 3),
  
  # New unique partner connections
  novel_connections = rpois(50, 2),
  
  # Δ risk-taking sentiment (post - pre)
  risk_taking_sent = rnorm(50, 0.05, 0.2)
)

# ------------------------------------------------------------
# MODEL PREMISE:
# Havoc = proportion of positive innovation-enabling signals
# Signals standardized *within OL3* to control for org differences
# ------------------------------------------------------------

leaders <- leaders %>%
  mutate(
    signal_ps = delta_ps > 0,
    signal_innov = delta_innov > 0,
    signal_bureau = delta_bureau < 0,
    signal_cross = cross_org_ties > 0,
    signal_novel = novel_connections > 0,
    signal_risk = risk_taking_sent > 0,
    
    havoc_raw = (signal_ps + signal_innov + signal_bureau +
                   signal_cross + signal_novel + signal_risk) / 6
  ) %>%
  group_by(OL3) %>%
  mutate(havoc_score = scale(havoc_raw)[,1]) %>%
  ungroup()
============================================================
  3️⃣ CLUTCH LEADERSHIP INDEX (Adjusted for OL3)
============================================================
  # ------------------------------------------------------------
# DATA REQUIRED (REAL SYSTEM)
# ------------------------------------------------------------
# • Quarterly or period-based team performance
# • Tagging: high-leverage periods (reorg, AI pivot, crisis)
# • Network centrality during crisis periods
# • Sentiment shift following leader interventions
#
# ENGINEERING NEEDED
# • performance_high = team performance during high-stakes period
# • performance_low  = same metric during normal periods
# • centrality_high  = centrality in crisis meeting network
# • sentiment_shift_high = Δ sentiment around decision-making windows
# ------------------------------------------------------------

clutch <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  performance_high = rnorm(50, 3.5, 0.7),
  performance_low  = rnorm(50, 3.2, 0.5),
  centrality_high = rnorm(50, 0.6, 0.15),
  sentiment_shift_high = rnorm(50, 0.1, 0.25)
)

# MODEL PREMISE:
# Leaders who improve performance more during crises = “clutch”
clutch <- clutch %>%
  mutate(perf_diff = performance_high - performance_low)

# Mixed-effects model w/ OL3 random intercept
m_clutch <- lmer(perf_diff ~ centrality_high + sentiment_shift_high + (1 | OL3),
                 data = clutch)

clutch$clutch_index <- scale(residuals(m_clutch))[,1]
============================================================
  4️⃣ EXPECTED INFLUENCE ADDED (EIA)
============================================================
  # ------------------------------------------------------------
# DATA REQUIRED (REAL SYSTEM)
# ------------------------------------------------------------
# • Full network centrality metrics (degree, betweenness, closeness)
# • Demographic metadata: job_level, tenure_months
# • Team/org metadata: org_size, OL3
#
# ENGINEERING NEEDED
# • Compute centrality via igraph or tidygraph
# ------------------------------------------------------------

inf <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  
  # Observed network centrality
  degree = rnorm(50, 20, 5),
  betweenness = rnorm(50, 0.15, 0.05),
  closeness = rnorm(50, 0.25, 0.06),
  
  # Role predictors
  job_level = sample(4:10, 50, TRUE),
  tenure_months = sample(12:180, 50, TRUE),
  org_size = sample(50:500, 50, TRUE)
)

# MODEL PREMISE:
# Predict expected influence from job level, experience, and org context.
# Actual - expected = influence added beyond role.
m_inf <- lmer(degree ~ job_level + tenure_months + org_size + (1 | OL3), data = inf)

inf <- inf %>%
  mutate(
    expected_degree = predict(m_inf),
    eia = degree - expected_degree  # influence added beyond role expectations
  )
============================================================
  5️⃣ CROSS-TEAM NAVIGATION SCORE (BsR analogue)
============================================================
  # ------------------------------------------------------------
# DATA REQUIRED (REAL SYSTEM)
# ------------------------------------------------------------
# • Edge list with OL3, job level, specialty area, geo location
# • Classification of senior vs peer vs specialist nodes
#
# ENGINEERING NEEDED
# • ties_cross_org       = count(edge where partner_OL3 != leader_OL3)
# • ties_to_senior       = count(edge where partner_job_level > leader_job_level)
# • ties_to_specialists  = count(edge where partner_role_type == 'specialist')
# • geo_span             = number of partner countries/regions
# • edge_diversity       = Shannon entropy of partner categories
# ------------------------------------------------------------

nav <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  ties_cross_org = rpois(50, 5),
  ties_total = rpois(50, 15) + 5,
  ties_to_senior = rpois(50, 2),
  ties_to_specialists = rpois(50, 3),
  geo_span = sample(1:5, 50, TRUE),
  edge_diversity = runif(50, 0.2, 1.0)
)

# MODEL PREMISE:
# Strong navigators bridge silos, senior leaders, specialists, and geographies
nav <- nav %>%
  mutate(
    pct_cross_org = ties_cross_org / ties_total,
    pct_senior = ties_to_senior / ties_total,
    pct_specialist = ties_to_specialists / ties_total,
    
    nav_raw = (0.4*pct_cross_org +
                 0.2*pct_senior +
                 0.2*pct_specialist +
                 0.1*geo_span +
                 0.1*edge_diversity)
  ) %>%
  group_by(OL3) %>%
  mutate(nav_score = scale(nav_raw)[,1]) %>%
  ungroup()
============================================================
  6️⃣ LEADERSHIP INDEPENDENT CONTRIBUTION (LIC)
============================================================
  # ------------------------------------------------------------
# DATA REQUIRED (REAL SYSTEM)
# ------------------------------------------------------------
# • Team performance by leader
# • Leader behavior sentiment: clarity, fairness, empowerment
# • Psych safety
# • Team context: complexity, size
#
# ENGINEERING NEEDED
# • team_complexity = measure of domains, dependencies, scope
# ------------------------------------------------------------

lic <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  
  # Leader behaviors
  clarity = rnorm(50, 0.5, 0.3),
  fairness = rnorm(50, 0.4, 0.25),
  empowerment = rnorm(50, 0.45, 0.28),
  psych_safety = rnorm(50, 0.5, 0.25),
  
  # Team outcomes
  team_perf = rnorm(50, 3.2, 0.4),
  
  # Context features
  team_complexity = rnorm(50, 1.5, 0.5),
  team_size = sample(5:50, 50, TRUE)
)

# MODEL PREMISE:
# Predict team performance from team characteristics.
# Residual = leader effect beyond context.
m_perf <- lmer(team_perf ~ team_complexity + team_size + (1 | OL3), data = lic)

lic <- lic %>%
  mutate(
    expected_perf = predict(m_perf),
    leader_effect = team_perf - expected_perf,
    lic = scale(leader_effect + clarity + fairness + empowerment + psych_safety)[,1]
  )
============================================================
  🔟 PSYCHOLOGICAL SAFETY ADDED (PSA)
============================================================
  # ------------------------------------------------------------
# DATA REQUIRED (REAL SYSTEM)
# ------------------------------------------------------------
# • Attrition by leader/team
# • Psych safety + trust + fairness + autonomy
#
# ENGINEERING NEEDED
# • attrition_rate = rolling 6- or 12-month attrition for team
# ------------------------------------------------------------

psa <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  psych_safety = rnorm(50, 0.5, 0.25),
  trust = rnorm(50, 0.5, 0.2),
  autonomy = rnorm(50, 0.5, 0.2),
  fairness = rnorm(50, 0.5, 0.2),
  attrition_rate = runif(50, 0.05, 0.25)
)

# MODEL PREMISE:
# Team attrition predicted from trust + fairness + OL3 context.
# Reduction in attrition = “PS runs saved”.
m_attr <- lmer(attrition_rate ~ trust + fairness + (1 | OL3), data = psa)

psa <- psa %>%
  mutate(
    expected_attrition = predict(m_attr),
    psa_score = expected_attrition - attrition_rate
  )
============================================================
  1️⃣1️⃣ EXPECTED INNOVATION IMPACT (xII)
============================================================
  # ------------------------------------------------------------
# DATA REQUIRED (REAL SYSTEM)
# ------------------------------------------------------------
# • Innovation climate
# • Psych safety
# • Network tie diversity
# • Centrality
# • Team performance
# • Innovation output measure
#
# ENGINEERING NEEDED
# • actual_innov = measure of innovation output (objective or survey)
# ------------------------------------------------------------

xii <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  innov_climate = rnorm(50, 0.6, 0.2),
  psych_safety = rnorm(50, 0.5, 0.25),
  tie_diversity = runif(50, 0.2, 1.0),
  centrality = rnorm(50, 0.3, 0.1),
  team_perf = rnorm(50, 3.2, 0.4),
  actual_innov = rnorm(50, 0.6, 0.25)
)

# MODEL PREMISE:
# Predict innovation from leading indicators.
# xII = Actual – Expected
m_innov <- lmer(actual_innov ~ innov_climate + psych_safety +
                  tie_diversity + centrality + team_perf + (1 | OL3),
                data = xii)

xii <- xii %>%
  mutate(
    expected_innov = predict(m_innov),
    xii_residual = actual_innov - expected_innov
  )
============================================================
  1️⃣2️⃣ OPS+ (Org Performance Score Plus)
============================================================
  # ------------------------------------------------------------
# DATA REQUIRED (REAL SYSTEM)
# ------------------------------------------------------------
# • Team performance
# • Team size, org size
# • Geography spread
# • Role difficulty
#
# ENGINEERING NEEDED
# • Standardization of role difficulty across orgs
# ------------------------------------------------------------

ops <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  team_perf = rnorm(50, 3.3, 0.5),
  team_size = sample(5:50, 50, TRUE),
  org_size = sample(50:500, 50, TRUE),
  geography_count = sample(1:5, 50, TRUE),
  role_difficulty = rnorm(50, 1.5, 0.4)
)

# MODEL PREMISE:
# Performance must be normalized to team/org/geographic complexity.
m_ops <- lmer(team_perf ~ team_size + org_size + geography_count +
                role_difficulty + (1 | OL3), data = ops)

ops <- ops %>%
  mutate(
    expected_perf = predict(m_ops),
    ops_plus = 100 * (team_perf / expected_perf)  # baseline = 100
  )
============================================================
  1️⃣3️⃣ STRUCTURAL HOLE EXPLOITATION (SHI)
============================================================
  # ------------------------------------------------------------
# DATA REQUIRED (REAL SYSTEM)
# ------------------------------------------------------------
# • Betweenness centrality
# • Edge diversity
# • Count of cross-org bridges
# • Sentiment impact among bridged groups
# ------------------------------------------------------------

holes <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  betweenness = rnorm(50, 0.15, 0.05),
  edge_diversity = runif(50, 0.3, 1.0),
  bridges_cross_org = rpois(50, 4),
  sentiment_change = rnorm(50, 0.05, 0.2)
)

# MODEL PREMISE:
# Measures whether leaders connect otherwise disconnected groups
holes <- holes %>%
  mutate(
    shi_raw = (0.4*betweenness +
                 0.2*edge_diversity +
                 0.2*bridges_cross_org +
                 0.2*sentiment_change)
  ) %>%
  group_by(OL3) %>%
  mutate(shi_score = scale(shi_raw)[,1]) %>%
  ungroup()
============================================================
  1️⃣4️⃣ ATTRITION PREVENTION ABOVE EXPECTED (APAE)
============================================================
  # ------------------------------------------------------------
# DATA REQUIRED (REAL SYSTEM)
# ------------------------------------------------------------
# • Attrition rates
# • Job level, tenure, org complexity
# • Climate sentiment
# • Network exposure / connectivity
#
# ENGINEERING NEEDED
# • network_exposure = centrality weighted by volatility of neighbors
# ------------------------------------------------------------

apae <- tibble(
  leader_id = 1:50,
  OL3 = sample(paste0("ORG_", LETTERS[1:5]), 50, TRUE),
  attrition_rate = runif(50, 0.05, 0.25),
  job_level = sample(4:10, 50, TRUE),
  tenure = sample(12:180, 50, TRUE),
  org_complexity = rnorm(50, 1.5, 0.5),
  network_exposure = rnorm(50, 0.4, 0.1),
  climate_sentiment = rnorm(50, 0.6, 0.2)
)

# MODEL PREMISE:
# Compare expected attrition (role + org + climate) to actual.
m_apae <- lmer(attrition_rate ~ job_level + tenure + org_complexity +
                 network_exposure + climate_sentiment + (1 | OL3),
               data = apae)

apae <- apae %>%
  mutate(
    expected_attrition = predict(m_apae),
    apae_score = expected_attrition - attrition_rate   # positive = good
  )
✅ Done.
You now have:
  
  ✔ Every variable clearly defined
✔ Full data engineering instructions
✔ Model premise included in comments
✔ R code fully annotated for production use
✔ Models adjusted for OL3
👉 Next Options
I can produce:
  
  ⭐ A combined function library (e.g., calculate_havoc(), calculate_eia())
⭐ A unified “Executive Sabermetrics Table” that joins all scores
⭐ ggplot visualizations for each metric
⭐ A two-page brief explaining all metrics for senior leadership
Just tell me which direction you want.



No file chosenNo file chosen
ChatGPT can make mistakes. Check important info.
