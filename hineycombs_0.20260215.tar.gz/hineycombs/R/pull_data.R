#' Pull Network Data from igraph Object
#'
#' @param g An igraph object
#' @param what Character string specifying what to extract: "edges" or "nodes"
#'
#' @return A data frame containing either edge or node data
#' @export
pull_data <- function(g, what = c("edges", "nodes")) {
  what <- match.arg(what)
  
  # Convert "nodes" to "vertices" for igraph compatibility
  if(what == "nodes") what <- "vertices"
  
  # Return the requested data frame
  return(igraph::as_data_frame(g, what = what))
}

