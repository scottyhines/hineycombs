#' Calculate Mixing Matrix for Graph Attributes
#'
#' @description
#' Creates a mixing matrix for a given attribute in a graph, showing either connection counts
#' or edge weights between different attribute categories.
#'
#' @param graph An igraph object containing the network
#' @param number Numeric. The number of top categories to include in the matrix
#' @param attribute_name Character. The name of the vertex attribute to analyze
#' @param type Character. Either "connections" for count-based or "edges" for weight-based analysis
#' @param percentage Logical. If TRUE, converts values to percentages with raw counts in parentheses
#' @param exclude_diagonal Logical. If TRUE, sets diagonal elements to zero
#'
#' @return A data frame containing the mixing matrix
#'
#' @examples
#' \dontrun{
#' # For connections
#' run_mixing(graph, 10, "gender", type = "connections", percentage = TRUE)
#' # For weighted edges
#' run_mixing(graph, 10, "gender", type = "edges", percentage = TRUE)
#' }
#'
#' @import igraph
#' @import dplyr
#' @importFrom janitor tabyl
#'
#' @export
run_connectivity_mixing_matrix <- function(
    graph,
    number,
    attribute_name,
    type = c("connections", "edges"),
    percentage = FALSE,
    exclude_diagonal = FALSE,
    verbose = FALSE
) {
  # Input validation
  if (!inherits(graph, "igraph")) stop("graph must be an igraph object.")
  if (!(attribute_name %in% igraph::vertex_attr_names(graph))) {
    stop("Attribute not found in the graph")
  }
  
  type <- match.arg(type)
  
  # ---- attribute vector (do not mutate graph) ----
  cat_vec <- as.character(igraph::vertex_attr(graph, attribute_name))
  cat_vec[is.na(cat_vec)] <- "missing"
  vars <- factor(cat_vec)
  
  # ---- assortativity (optional print) ----
  vars_numeric <- as.numeric(vars)
  assortativity <- igraph::assortativity_nominal(graph, vars_numeric, directed = FALSE)
  if (verbose) message("Assortativity Coefficient: ", assortativity)
  
  # ---- top categories ----
  top_categories <- janitor::tabyl(cat_vec) |>
    dplyr::arrange(dplyr::desc(.data$n)) |>
    dplyr::slice(1:number) |>
    dplyr::pull(1) |>
    as.character()
  
  # keep stable ordering (alphabetical like your original)
  top_categories <- sort(top_categories)
  
  if (verbose) {
    message("Top Categories:")
    print(top_categories)
  }
  
  # ---- edge endpoints ----
  edge_ends <- igraph::ends(graph, igraph::E(graph), names = FALSE)
  
  # filter edges where both ends are in top categories
  keep <- vars[edge_ends[, 1]] %in% top_categories & vars[edge_ends[, 2]] %in% top_categories
  filtered_edges <- edge_ends[keep, , drop = FALSE]
  
  # ---- build mixing matrix ----
  filtered_vars_from <- factor(vars[filtered_edges[, 1]], levels = top_categories)
  filtered_vars_to   <- factor(vars[filtered_edges[, 2]], levels = top_categories)
  
  if (type == "connections") {
    mixing_matrix <- table(from = filtered_vars_from, to = filtered_vars_to)
  } else {
    # weights (default to 1 if missing)
    edge_weights <- if ("weight" %in% igraph::edge_attr_names(graph)) {
      igraph::E(graph)$weight
    } else {
      rep(1, igraph::ecount(graph))
    }
    filtered_weights <- edge_weights[keep]
    
    mixing_matrix <- matrix(
      0,
      nrow = length(top_categories),
      ncol = length(top_categories),
      dimnames = list(top_categories, top_categories)
    )
    
    for (i in seq_len(nrow(filtered_edges))) {
      from <- filtered_vars_from[i]
      to   <- filtered_vars_to[i]
      mixing_matrix[from, to] <- mixing_matrix[from, to] + filtered_weights[i]
    }
  }
  
  if (exclude_diagonal) diag(mixing_matrix) <- 0
  
  # ---- percentage formatting (row %) ----
  if (percentage) {
    row_totals <- rowSums(mixing_matrix)
    mixing_matrix_perc <- sweep(mixing_matrix, 1, row_totals, FUN = "/") * 100
    mixing_matrix_perc[is.na(mixing_matrix_perc)] <- 0
    
    formatted_matrix <- matrix(NA_character_, nrow = nrow(mixing_matrix), ncol = ncol(mixing_matrix))
    for (i in seq_len(nrow(mixing_matrix))) {
      for (j in seq_len(ncol(mixing_matrix))) {
        formatted_matrix[i, j] <- paste0(
          round(mixing_matrix_perc[i, j], 2),
          "% (", mixing_matrix[i, j], ")"
        )
      }
    }
    dimnames(formatted_matrix) <- dimnames(mixing_matrix)
    mixing_matrix_df <- as.data.frame.matrix(formatted_matrix, stringsAsFactors = FALSE)
  } else {
    mixing_matrix_df <- as.data.frame.matrix(mixing_matrix)
  }
  
  # return only (no printing)
  mixing_matrix_df
}
