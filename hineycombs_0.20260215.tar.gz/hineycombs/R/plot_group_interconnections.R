#' Plot Network Group Visualizations with Degree-Based Node Sizes
#'
#' @param g An igraph object representing the network
#' @param group_var Character. Name of the vertex attribute containing group memberships
#' @param selected_groups Character vector of length 2. Names of the two groups to visualize
#' @param non_group_alpha Numeric value between 0 and 1 for transparency of non-selected nodes (default = 0.2)
#' @param min_size Minimum vertex size (default = 3)
#' @param max_size Maximum vertex size (default = 15)
#'
#' @importFrom igraph V E vcount ecount vertex_attr as_edgelist subgraph.edges layout_with_mds degree
#' @importFrom scales rescale
#' @export
plot_group_interconnections <- function(g, group_var, selected_groups, non_group_alpha = 0.2,
                                        min_size = 3, max_size = 15) {
  
  # Set up plotting area for 4 plots (2x2 grid)
  par(mfrow=c(2,2))
  
  #Get group membership
  group_membership <- as.character(igraph::vertex_attr(g, group_var))
  group1_nodes <- which(group_membership == selected_groups[1])
  group2_nodes <- which(group_membership == selected_groups[2])
  selected_nodes <- c(group1_nodes, group2_nodes)
  
  #Set up colors with transparency for non-selected groups
  palette <- MetBrewer::met.brewer("Johnson", n = 2)
  transparent_color <- adjustcolor("gray70", alpha.f = non_group_alpha)
  
  # Initialize all nodes as transparent
  node_colors <- rep(transparent_color, igraph::vcount(g))
  # Color selected group nodes
  node_colors[group1_nodes] <- palette[1]
  node_colors[group2_nodes] <- palette[2]
  
  #Identify cross-group edges
  edges <- igraph::as_edgelist(g, names = FALSE)
  cross_edges <- which(
    (group_membership[edges[,1]] == selected_groups[1] & group_membership[edges[,2]] == selected_groups[2]) |
      (group_membership[edges[,1]] == selected_groups[2] & group_membership[edges[,2]] == selected_groups[1])
  )
  edge_colors <- rep("gray80", igraph::ecount(g))
  edge_colors[cross_edges] <- "orange"
  
  #Calculate layout once
  layout_mds <- igraph::layout_with_mds(g)
  
  # Calculate degree and scale vertex sizes
  degrees <- igraph::degree(g)
  if (length(unique(degrees)) == 1) {
    vertex_sizes <- rep(min_size, igraph::vcount(g))
  } else {
    vertex_sizes <- scales::rescale(degrees, to = c(min_size, max_size))
  }
  
  #Full network plot
  plot(g, layout = layout_mds,
       vertex.color = node_colors,
       vertex.size = vertex_sizes,
       edge.arrow.size = 0.01,
       edge.arrow.width = 0.01,
       vertex.label = NA,
       edge.color = "gray80",
       main = "Full Network (MDS)")
  legend("topright", legend = c(selected_groups, 
                                paste("Node size: Degree (", min(degrees), "-", max(degrees), ")")),
         col = c(palette, "orange"), pch = c(16, 16, 1),
         bty = "n", cex = 0.8)
  
  #Highlighted connections plot
  plot(g, layout = layout_mds,
       vertex.color = node_colors,
       vertex.size = vertex_sizes,
       edge.arrow.size = 0.01,
       edge.arrow.width = 0.01,
       vertex.label = NA,
       edge.color = edge_colors,
       edge.width = ifelse(edge_colors == "orange", 2, 1),
       main = "Highlighting Cross-Group")
  legend("topright", legend = c(selected_groups, 
                                paste("Node size: Degree (", min(degrees), "-", max(degrees), ")")),
         col = c(palette, "black"), pch = c(16, 16, 1),
         bty = "n", cex = 0.8)
  
  #Cross-group only plot
  if (length(cross_edges) > 0) {
    g_sub <- igraph::subgraph_from_edges(g, cross_edges, delete.vertices = FALSE)
    plot(g_sub, layout = layout_mds,
         vertex.color = node_colors,
         vertex.size = vertex_sizes,
         edge.arrow.size = 0.01,
         edge.arrow.width = 0.01,
         vertex.label = NA,
         edge.color = "orange",
         edge.width = 2,
         main = "Cross-Group Only")
    legend("topright", legend = c(selected_groups, 
                                  paste("Node size: Degree (", min(degrees), "-", max(degrees), ")")),
           col = c(palette, "black"), pch = c(16, 16, 1),
           bty = "n", cex = 0.8)
  }
  
  # Selected groups only plot
  # Create subgraph with only selected nodes
  g_selected <- igraph::induced_subgraph(g, selected_nodes)
  
  # Get the layout coordinates for only the selected nodes
  layout_selected <- layout_mds[selected_nodes,]
  
  # Update colors and sizes for selected nodes only
  node_colors_selected <- node_colors[selected_nodes]
  vertex_sizes_selected <- vertex_sizes[selected_nodes]
  
  # Plot selected groups only
  plot(g_selected, layout = layout_selected,
       vertex.color = node_colors_selected,
       vertex.size = vertex_sizes_selected,
       edge.arrow.size = 0.01,
       edge.arrow.width = 0.01,
       vertex.label = NA,
       edge.color = "gray80",
       main = "Selected Groups Only")
  legend("topright", legend = c(selected_groups, 
                                paste("Node size: Degree (", min(degrees), "-", max(degrees), ")")),
         col = c(palette, "black"), pch = c(16, 16, 1),
         bty = "n", cex = 0.8)
  
  # Reset par
  par(mfrow=c(1,1))
}
