#' Count attribute-based connections at the TEAM level (unique external alters)
#'
#' @description
#' Team-level version of calculate_specific_connections(). Avoids double counting
#' distinct external alters when multiple team members connect to the same person.
#'
#' - `_n` = DISTINCT alters (unique people) for the team in that category (deduped)
#' - `_f` = SUM of edge weights/frequencies across all team-member -> alter ties (volume)
#'
#' same_diff = TRUE:
#' For EACH attribute in attr_vars, defines a team "reference" value as the modal
#' (most common) value among team members, then counts alters that match that reference
#' ("same") vs those that don't ("diff").
#'
#' Adds UNDIRECTED TOTALS even for directed graphs:
#' - `*_total_*` treats ties as undirected and dedupes alters across incoming+outgoing.
#'
#' @param g igraph object with vertex `name` and `team_attr`
#' @param team_attr vertex attribute defining the team/unit (e.g., reports_to_supervisor_login)
#' @param attr_vars vertex attributes to summarize on alters
#' @param weight_var optional edge attribute name for weights (default weight=1)
#' @param same_diff if TRUE, returns same/diff columns per attr using team modal reference
#' @param include_internal if FALSE, removes ties where ego_team == alter_team
#' @param mode for directed graphs: "all","out","in"
#' @param debug if TRUE, prints name resolution and diagnostics
#'
#' @return data.frame, one row per team
#' @export
calculate_team_specific_connections <- function(
    g,
    team_attr,
    attr_vars,
    weight_var = NULL,
    same_diff = FALSE,
    include_internal = FALSE,
    mode = c("all","out","in"),
    debug = FALSE
){
  if (!inherits(g, "igraph")) stop("`g` must be an igraph object.")
  mode <- base::match.arg(mode)
  
  is_dir <- igraph::is_directed(g)
  nodes <- igraph::as_data_frame(g, what = "vertices")
  edges <- igraph::as_data_frame(g, what = "edges")
  
  if (!"name" %in% names(nodes)) stop("Vertices must have a `name` attribute.")
  
  # ---- Robust name resolver (case- & whitespace-insensitive) ----
  resolve_names <- function(requested, available) {
    req <- trimws(as.character(requested))
    av  <- as.character(available)
    av_trim <- trimws(av)
    
    resolved <- vapply(req, function(x) {
      # exact match first
      if (x %in% av) return(x)
      
      # exact match after trim
      idx1 <- which(av_trim == x)
      if (length(idx1) == 1) return(av[idx1])
      
      # case-insensitive match after trim
      idx2 <- which(tolower(av_trim) == tolower(x))
      if (length(idx2) == 1) return(av[idx2])
      
      NA_character_
    }, character(1))
    
    list(
      requested = req,
      resolved = resolved,
      missing = req[is.na(resolved)],
      map = stats::setNames(resolved, req)
    )
  }
  
  # Resolve team_attr and attr_vars against actual node column names
  team_res <- resolve_names(team_attr, names(nodes))
  if (is.na(team_res$resolved[1])) {
    stop("team_attr not found on vertices: ", team_attr,
         "\nAvailable vertex attrs: ", paste(names(nodes), collapse = ", "))
  }
  team_attr_actual <- team_res$resolved[1]
  
  attr_vars <- as.character(attr_vars)
  attr_res <- resolve_names(attr_vars, names(nodes))
  present_attrs <- unique(attr_res$resolved[!is.na(attr_res$resolved)])
  
  if (debug) {
    cat("\n[DEBUG] team_attr requested:", team_attr, "\n")
    cat("[DEBUG] team_attr resolved :", team_attr_actual, "\n")
    cat("[DEBUG] attr_vars requested:", paste(attr_vars, collapse = ", "), "\n")
    cat("[DEBUG] attr_vars resolved :", paste(present_attrs, collapse = ", "), "\n")
    if (length(attr_res$missing) > 0) {
      cat("[DEBUG] missing attrs     :", paste(attr_res$missing, collapse = ", "), "\n")
    }
    cat("[DEBUG] vertex columns     :", paste(names(nodes), collapse = " | "), "\n")
  }
  
  # If per-level mode, we need at least one attr
  if (!same_diff && length(present_attrs) == 0) {
    stop("No valid attr_vars found on vertices. Requested: ",
         paste(attr_vars, collapse = ", "))
  }
  
  # ---- weight handling ----
  if (is.null(weight_var) || !weight_var %in% names(edges)) {
    edges[["..weight_tmp.."]] <- 1
    wcol <- "..weight_tmp.."
  } else {
    wcol <- weight_var
  }
  
  v_name <- nodes$name
  v_team <- nodes[[team_attr_actual]]
  
  add_col <- function(df, col) {
    if (!col %in% names(df)) df[[col]] <- 0
    df
  }
  
  # ---- build long edge table ----
  make_long_edges <- function(direction = c("all","out","in")) {
    direction <- base::match.arg(direction)
    
    if (!is_dir) {
      df1 <- data.frame(ego = edges$from, alter = edges$to, weight = edges[[wcol]],
                        stringsAsFactors = FALSE)
      df2 <- data.frame(ego = edges$to, alter = edges$from, weight = edges[[wcol]],
                        stringsAsFactors = FALSE)
      df <- base::rbind(df1, df2)
      df$dir <- "all"
      return(df)
    }
    
    if (direction == "all") {
      df_out <- data.frame(ego = edges$from, alter = edges$to, weight = edges[[wcol]],
                           stringsAsFactors = FALSE)
      df_out$dir <- "outgoing"
      df_in <- data.frame(ego = edges$to, alter = edges$from, weight = edges[[wcol]],
                          stringsAsFactors = FALSE)
      df_in$dir <- "incoming"
      return(base::rbind(df_out, df_in))
    }
    
    if (direction == "out") {
      df <- data.frame(ego = edges$from, alter = edges$to, weight = edges[[wcol]],
                       stringsAsFactors = FALSE)
      df$dir <- "outgoing"
      return(df)
    }
    
    df <- data.frame(ego = edges$to, alter = edges$from, weight = edges[[wcol]],
                     stringsAsFactors = FALSE)
    df$dir <- "incoming"
    df
  }
  
  df_long <- make_long_edges(if (is_dir) mode else "all")
  
  # Attach ego_team and alter_team
  df_long$ego_team   <- v_team[match(df_long$ego, v_name)]
  df_long$alter_team <- v_team[match(df_long$alter, v_name)]
  
  # Optional: drop internal ties unless requested
  if (!include_internal) {
    df_long <- df_long[df_long$ego_team != df_long$alter_team, , drop = FALSE]
  }
  
  # Drop missing teams
  df_long <- df_long[!is.na(df_long$ego_team) & !is.na(df_long$alter_team), , drop = FALSE]
  if (nrow(df_long) == 0) {
    return(data.frame(team_value = character(0), stringsAsFactors = FALSE))
  }
  
  teams <- sort(unique(df_long$ego_team))
  out <- data.frame(team_value = teams, stringsAsFactors = FALSE)
  names(out)[1] <- team_attr_actual
  
  # Add team size
  team_sizes <- table(v_team[!is.na(v_team)])
  out$team_size <- as.numeric(team_sizes[match(out[[team_attr_actual]], names(team_sizes))])
  
  # ---- helper: mode ----
  mode1 <- function(x) {
    x <- x[!is.na(x)]
    if (length(x) == 0) return(NA_character_)
    tab <- sort(table(x), decreasing = TRUE)
    names(tab)[1]
  }
  
  # ---- build an UNDIRECTED "total" long table for directed graphs ----
  # total means: treat ties as undirected (dedupe alters across in+out)
  build_total_table <- function() {
    if (!is_dir) return(NULL)
    # df_long already includes both in and out if mode="all"; but if mode="in" or "out"
    # we still want total across BOTH directions; so use original edges to build total.
    df1 <- data.frame(ego = edges$from, alter = edges$to, weight = edges[[wcol]],
                      stringsAsFactors = FALSE)
    df2 <- data.frame(ego = edges$to, alter = edges$from, weight = edges[[wcol]],
                      stringsAsFactors = FALSE)
    df_tot <- base::rbind(df1, df2)
    df_tot$dir <- "total"
    
    df_tot$ego_team   <- v_team[match(df_tot$ego, v_name)]
    df_tot$alter_team <- v_team[match(df_tot$alter, v_name)]
    
    if (!include_internal) {
      df_tot <- df_tot[df_tot$ego_team != df_tot$alter_team, , drop = FALSE]
    }
    
    df_tot <- df_tot[!is.na(df_tot$ego_team) & !is.na(df_tot$alter_team), , drop = FALSE]
    df_tot
  }
  
  df_total <- build_total_table()
  
  # ==========================
  # same/diff mode (per attr)
  # ==========================
  if (same_diff) {
    
    if (length(present_attrs) == 0) {
      warning("None of attr_vars exist as vertex attributes; returning team list only.")
      return(out)
    }
    
    # Build team reference values using BASE R (no dplyr::across / tidyselect)
    team_ref <- data.frame(
      ego_team = teams,
      stringsAsFactors = FALSE
    )
    
    # Precompute node indices by team for speed
    idx_by_team <- split(seq_len(nrow(nodes)), nodes[[team_attr_actual]])
    
    for (attr in present_attrs) {
      ref_vec <- vapply(teams, function(t) {
        idx <- idx_by_team[[as.character(t)]]
        if (is.null(idx) || length(idx) == 0) return(NA_character_)
        mode1(as.character(nodes[[attr]][idx]))
      }, character(1))
      team_ref[[attr]] <- ref_vec
    }
    
    # ---------- directional (incoming/outgoing/all) ----------
    ref_idx_dir <- match(df_long$ego_team, team_ref$ego_team)
    
    for (attr in present_attrs) {
      
      team_ref_val <- as.character(team_ref[[attr]][ref_idx_dir])
      alter_val <- as.character(nodes[[attr]][match(df_long$alter, v_name)])
      
      keep <- !is.na(team_ref_val) & !is.na(alter_val)
      if (!any(keep)) next
      
      df_sd <- df_long[keep, , drop = FALSE]
      df_sd$same <- alter_val[keep] == team_ref_val[keep]
      
      # Deduplicate by (team, alter, same) to avoid counting same alter multiple times
      agg_temp <- dplyr::summarise(
        dplyr::group_by(df_sd, ego_team, dir, same, alter),
        f = sum(weight, na.rm = TRUE),
        .groups = "drop"
      )
      
      # Then aggregate to team level
      agg <- dplyr::summarise(
        dplyr::group_by(agg_temp, ego_team, dir, same),
        n = dplyr::n_distinct(alter),
        f = sum(f, na.rm = TRUE),
        .groups = "drop"
      )
      
      for (i in seq_len(nrow(agg))) {
        tm <- agg$ego_team[i]
        dir_lab <- agg$dir[i]
        tag <- if (isTRUE(agg$same[i])) "same" else "diff"
        
        base <- paste(attr, dir_lab, tag, sep = "_")
        ncol <- paste0(base, "_n")
        fcol <- paste0(base, "_f")
        
        out <- add_col(out, ncol)
        out <- add_col(out, fcol)
        
        ridx <- match(tm, out[[team_attr_actual]])
        out[[ncol]][ridx] <- agg$n[i]
        out[[fcol]][ridx] <- agg$f[i]
      }
      
      # ---------- TOTAL (undirected) ----------
      if (!is.null(df_total) && nrow(df_total) > 0) {
        ref_idx_tot <- match(df_total$ego_team, team_ref$ego_team)
        team_ref_val_tot <- as.character(team_ref[[attr]][ref_idx_tot])
        alter_val_tot <- as.character(nodes[[attr]][match(df_total$alter, v_name)])
        
        keep2 <- !is.na(team_ref_val_tot) & !is.na(alter_val_tot)
        if (any(keep2)) {
          df_sd_tot <- df_total[keep2, , drop = FALSE]
          df_sd_tot$same <- alter_val_tot[keep2] == team_ref_val_tot[keep2]
          
          # Deduplicate
          agg_tot_temp <- dplyr::summarise(
            dplyr::group_by(df_sd_tot, ego_team, dir, same, alter),
            f = sum(weight, na.rm = TRUE),
            .groups = "drop"
          )
          
          agg_tot <- dplyr::summarise(
            dplyr::group_by(agg_tot_temp, ego_team, dir, same),
            n = dplyr::n_distinct(alter),
            f = sum(f, na.rm = TRUE),
            .groups = "drop"
          )
          
          for (i in seq_len(nrow(agg_tot))) {
            tm <- agg_tot$ego_team[i]
            dir_lab <- agg_tot$dir[i]  # "total"
            tag <- if (isTRUE(agg_tot$same[i])) "same" else "diff"
            
            base <- paste(attr, dir_lab, tag, sep = "_")
            ncol <- paste0(base, "_n")
            fcol <- paste0(base, "_f")
            
            out <- add_col(out, ncol)
            out <- add_col(out, fcol)
            
            ridx <- match(tm, out[[team_attr_actual]])
            out[[ncol]][ridx] <- agg_tot$n[i]
            out[[fcol]][ridx] <- agg_tot$f[i]
          }
        }
      }
    }
    
    return(out)
  }
  
  # ==========================
  # per-level mode (same_diff = FALSE)
  # ==========================
  for (attr in present_attrs) {
    
    # directional (incoming/outgoing/all)
    df_attr <- df_long
    df_attr$alter_attr <- nodes[[attr]][match(df_attr$alter, v_name)]
    df_attr <- df_attr[!is.na(df_attr$alter_attr), , drop = FALSE]
    if (nrow(df_attr) > 0) {
      
      # Deduplicate by (team, alter, level)
      agg_temp <- dplyr::summarise(
        dplyr::group_by(df_attr, ego_team, dir, alter_attr, alter),
        f = sum(weight, na.rm = TRUE),
        .groups = "drop"
      )
      
      agg <- dplyr::summarise(
        dplyr::group_by(agg_temp, ego_team, dir, alter_attr),
        n = dplyr::n_distinct(alter),
        f = sum(f, na.rm = TRUE),
        .groups = "drop"
      )
      
      for (i in seq_len(nrow(agg))) {
        tm <- agg$ego_team[i]
        dir_lab <- agg$dir[i]
        lvl_safe <- base::make.names(as.character(agg$alter_attr[i]))
        
        base <- paste(attr, lvl_safe, dir_lab, sep = "_")
        ncol <- paste0(base, "_n")
        fcol <- paste0(base, "_f")
        
        out <- add_col(out, ncol)
        out <- add_col(out, fcol)
        
        ridx <- match(tm, out[[team_attr_actual]])
        out[[ncol]][ridx] <- agg$n[i]
        out[[fcol]][ridx] <- agg$f[i]
      }
    }
    
    # TOTAL (undirected)
    if (!is.null(df_total) && nrow(df_total) > 0) {
      df_attr_tot <- df_total
      df_attr_tot$alter_attr <- nodes[[attr]][match(df_attr_tot$alter, v_name)]
      df_attr_tot <- df_attr_tot[!is.na(df_attr_tot$alter_attr), , drop = FALSE]
      if (nrow(df_attr_tot) == 0) next
      
      # Deduplicate
      agg_tot_temp <- dplyr::summarise(
        dplyr::group_by(df_attr_tot, ego_team, dir, alter_attr, alter),
        f = sum(weight, na.rm = TRUE),
        .groups = "drop"
      )
      
      agg_tot <- dplyr::summarise(
        dplyr::group_by(agg_tot_temp, ego_team, dir, alter_attr),
        n = dplyr::n_distinct(alter),
        f = sum(f, na.rm = TRUE),
        .groups = "drop"
      )
      
      for (i in seq_len(nrow(agg_tot))) {
        tm <- agg_tot$ego_team[i]
        dir_lab <- agg_tot$dir[i]  # "total"
        lvl_safe <- base::make.names(as.character(agg_tot$alter_attr[i]))
        
        base <- paste(attr, lvl_safe, dir_lab, sep = "_")
        ncol <- paste0(base, "_n")
        fcol <- paste0(base, "_f")
        
        out <- add_col(out, ncol)
        out <- add_col(out, fcol)
        
        ridx <- match(tm, out[[team_attr_actual]])
        out[[ncol]][ridx] <- agg_tot$n[i]
        out[[fcol]][ridx] <- agg_tot$f[i]
      }
    }
  }
  
  out
}
