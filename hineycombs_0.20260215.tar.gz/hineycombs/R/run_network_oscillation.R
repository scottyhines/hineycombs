#' Calculate Oscillation Metrics for Multiple Variables
#'
#' @description
#' Calculates oscillation metrics (standard deviation, range, and peaks/valleys) 
#' for specified variables in a longitudinal dataset, including individual scores
#' and overall averages. These metrics are combined into a single oscillation score 
#' that quantifies the degree of fluctuation over time. Handles missing values appropriately.
#'
#' @details
#' The function calculates three key metrics:
#' \itemize{
#'   \item Standard Deviation: Measures overall variability
#'   \item Range: Difference between maximum and minimum values
#'   \item Peaks and Valleys: Count of local maxima and minima
#' }
#' 
#' The final oscillation score is calculated as:
#' (0.7 * Standard Deviation) + (0.3 * Peaks_Valleys)
#'
#' Averages are calculated for each metric across all IDs.
#'
#' @param data A data frame containing the longitudinal data
#' @param variables A character vector specifying the names of variables to analyze
#' @param id_col A character string specifying the name of the ID column (default: "name")
#'
#' @return A list containing two elements:
#'   \item{individual_scores}{Data frame with individual metrics for each ID}
#'   \item{averages}{Data frame with average metrics across all IDs}
#'
#' @examples
#' \dontrun{
#' # Create example data
#' data <- data.frame(
#'   name = rep(c("A", "B"), each = 5),
#'   time = rep(1:5, 2),
#'   var1 = rnorm(10),
#'   var2 = rnorm(10)
#' )
#' 
#' # Calculate oscillation metrics
#' results <- calculate_oscillation_metrics(data, 
#'                                        variables = c("var1", "var2"))
#' 
#' # Access individual scores
#' individual_results <- results$individual_scores
#' 
#' # Access averages
#' average_results <- results$averages
#' }
#'
#' @importFrom dplyr group_by summarise mutate across everything
#' @importFrom stats sd
#'
#' @export
calculate_oscillation_metrics <- function(data, variables, id_col = "name") {
  
  # Helper function for peaks and valleys with NA handling
  count_peaks_valleys <- function(scores) {
    # Remove NA values while maintaining order
    valid_indices <- which(!is.na(scores))
    if (length(valid_indices) < 3) return(NA_real_)
    
    clean_scores <- scores[valid_indices]
    n <- length(clean_scores)
    peaks_valleys <- 0
    
    for (i in 2:(n - 1)) {
      # Check for peaks
      is_peak <- clean_scores[i] > clean_scores[i - 1] && 
        clean_scores[i] > clean_scores[i + 1]
      
      # Check for valleys
      is_valley <- clean_scores[i] < clean_scores[i - 1] && 
        clean_scores[i] < clean_scores[i + 1]
      
      if (is_peak || is_valley) peaks_valleys <- peaks_valleys + 1
    }
    
    return(peaks_valleys)
  }
  
  # Check if ID column exists
  if (!id_col %in% colnames(data)) {
    stop(paste("ID column", id_col, "not found in the data"))
  }
  
  # Initialize empty list to store results
  results_list <- list()
  
  # Calculate metrics for each specified variable
  for (var in variables) {
    # Check if variable exists
    if (!var %in% colnames(data)) {
      stop(paste("Variable", var, "not found in the data"))
    }
    
    # Create dynamic column names
    sd_col <- paste0(var, "_SD")
    range_col <- paste0(var, "_Range")
    peaks_valleys_col <- paste0(var, "_Peaks_Valleys")
    oscillation_col <- paste0(var, "_Oscillation_Score")
    mean_col <- paste0(var, "_Mean")
    
    # Calculate metrics
    var_metrics <- data %>%
      dplyr::group_by(.data[[id_col]]) %>%
      dplyr::summarise(
        # Mean
        !!mean_col := mean(.data[[var]], na.rm = TRUE),
        
        # Standard Deviation
        !!sd_col := stats::sd(.data[[var]], na.rm = TRUE),
        
        # Range (with NA handling)
        !!range_col := if(all(is.na(.data[[var]]))) NA_real_ 
        else diff(range(.data[[var]], na.rm = TRUE)),
        
        # Peaks and Valleys
        !!peaks_valleys_col := count_peaks_valleys(.data[[var]]),
        
        .groups = "drop"
      ) %>%
      dplyr::mutate(
        # Combined Score (with NA handling)
        !!oscillation_col := ifelse(
          is.na(.data[[sd_col]]) | is.na(.data[[peaks_valleys_col]]),
          NA_real_,
          0.7 * .data[[sd_col]] + 0.3 * .data[[peaks_valleys_col]]
        )
      )
    
    results_list[[var]] <- var_metrics
  }
  
  # Combine all individual results
  individual_results <- Reduce(function(x, y) merge(x, y, by = id_col), results_list)
  
  # Calculate averages across all metrics (excluding ID column)
  average_results <- individual_results %>%
    dplyr::summarise(
      across(
        -all_of(id_col),
        ~ mean(., na.rm = TRUE)
      )
    ) %>%
    # Add a row identifier
    dplyr::mutate(
      !!id_col := "AVERAGE"
    ) %>%
    # Reorder columns to match individual results
    dplyr::select(names(individual_results))
  
  # Return both individual results and averages
  return(list(
    individual_scores = individual_results,
    averages = average_results
  ))
}
