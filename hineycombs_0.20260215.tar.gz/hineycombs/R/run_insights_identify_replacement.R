#' Create a Team-Wide “Replacement Map” for Bridge-Like Connection Patterns
#'
#' @description
#' Given a network where each vertex belongs to a team/group (via a vertex attribute),
#' this function finds, for every focal person, the most similar potential "replacement"
#' based on a *bridge signature* of their connections.
#'
#' The bridge signature is computed as a vector of proportions describing how a person's
#' ties distribute across all groups in the network (as defined by `group_attr`).
#' Similarity is computed using cosine similarity between these vectors.
#' 
#' The team_replacement_map() function assesses structural redundancy in organizational networks by identifying whether individuals have viable “replacements” who exhibit similar cross-group connection patterns. For each person, the function constructs a bridge signature—a normalized vector representing the proportion of that individual’s ties to each formal group (e.g., supervisor, department). It then uses cosine similarity to identify the most structurally similar colleague within the same team and across the broader organization. Rather than focusing on raw degree or centrality alone, this approach evaluates where connections go, capturing whether someone else connects to the same external groups in similar proportions. The output therefore indicates whether a structurally comparable actor exists and flags potential single points of failure.
#  Theoretically, this method is grounded in research on brokerage and structural holes (Ronald Burt), which shows that actors who span disconnected groups control information flow and often drive innovation and influence. However, brokerage can also create organizational vulnerability if concentrated in a single individual. By assessing structural similarity—an idea linked to role equivalence and centrality theory (Linton Freeman)—the function moves beyond identifying who is central to evaluating whether that structural role is distributed or redundant. In doing so, it provides a theoretically grounded diagnostic of resilience: teams with high internal similarity are structurally robust, whereas low similarity suggests dependence on unique brokers whose departure could fragment collaboration networks.
#'
#' The function returns *two* replacement candidates for each focal person:
#' \itemize{
#'   \item \strong{Same-team replacement}: best match among members of the focal person's own team
#'   \item \strong{Org-wide replacement}: best match among all other vertices in the network
#' }
#'
#' This is useful for assessing redundancy in bridging roles: if a key bridge node leaves,
#' does someone else in the team (or the org) have a similar external connection footprint?
#'
#' @param g An \code{igraph} graph object (directed or undirected).
#' @param group_attr Character scalar. Name of the vertex attribute defining team/group membership
#'   (e.g., \code{"reports_to_supervisor_login"}, \code{"department"}, \code{"org"}).
#' @param team_value Optional. If provided, restricts the focal set to vertices whose \code{group_attr}
#'   equals \code{team_value}. If \code{NULL} (default), computes results for all vertices.
#' @param mode Character scalar. Neighbor mode passed to \code{\link[igraph]{neighbors}}:
#'   \code{"all"} (default), \code{"out"}, or \code{"in"}.
#'   Use \code{"out"} for outgoing ties and \code{"in"} for incoming ties in directed networks.
#' @param min_similarity Numeric. Minimum cosine similarity threshold used to set the
#'   \code{*_exists} flags (default = 0.20). A higher value is stricter.
#'
#' @return A \code{data.frame} with one row per focal person and the following columns:
#' \itemize{
#'   \item \code{person_name}: Vertex name (or index coerced to character if \code{name} is missing)
#'   \item \code{team_value}: The person's group value from \code{group_attr}
#'   \item \code{same_team_replacement}: Best within-team replacement's name (or \code{NA})
#'   \item \code{same_team_similarity}: Cosine similarity to the within-team replacement
#'   \item \code{same_team_exists}: Logical; TRUE if \code{same_team_similarity >= min_similarity}
#'   \item \code{all_org_replacement}: Best org-wide replacement's name (or \code{NA})
#'   \item \code{all_org_similarity}: Cosine similarity to the org-wide replacement
#'   \item \code{all_org_exists}: Logical; TRUE if \code{all_org_similarity >= min_similarity}
#' }
#'
#' The output is sorted by ascending \code{same_team_similarity} to highlight lower redundancy cases first.
#'
#' @details
#' \strong{Bridge signature construction:}
#' For each node, the function counts neighbors by group membership (according to \code{group_attr}),
#' then normalizes counts to proportions (summing to 1). This representation focuses on
#' \emph{where} connections go, not simply how many.
#'
#' \strong{Similarity:}
#' Cosine similarity ranges from 0 to 1 when vectors are nonnegative. Higher values indicate
#' more similar distributions of ties across groups.
#'
#' \strong{Performance notes:}
#' Signatures are precomputed for all vertices once per function call for speed. For very large
#' networks, consider restricting with \code{team_value} or filtering the graph first.
#'
#' @examples
#' \dontrun{
#' library(igraph)
#'
#' # Example: compute replacement map for a single team
#' out_team <- team_replacement_map(
#'   g,
#'   group_attr = "reports_to_supervisor_login",
#'   team_value = "mgr_123",
#'   mode = "all",
#'   min_similarity = 0.25
#' )
#'
#' # Example: compute replacement map for all vertices
#' out_all <- team_replacement_map(
#'   g,
#'   group_attr = "reports_to_supervisor_login",
#'   team_value = NULL,
#'   mode = "out"
#' )
#' }
#'
#' @export
run_insights_identify_replacement <- function(
    g,
    group_attr = "reports_to_supervisor_login",
    team_value = NULL,
    mode = c("all","out","in"),
    min_similarity = 0.20
){
  mode <- match.arg(mode)
  
  grp <- igraph::vertex_attr(g, group_attr)
  if (is.null(grp)) stop("group_attr not found on vertices: ", group_attr)
  
  v_names <- igraph::V(g)$name
  if (is.null(v_names)) v_names <- as.character(seq_len(igraph::vcount(g)))
  
  groups <- sort(unique(grp))
  group_index <- stats::setNames(seq_along(groups), groups)
  
  # --- Neighbor getter ---
  nbrs_of <- function(v) igraph::neighbors(g, v, mode = mode)
  
  # --- Signature (proportion of ties to each group) ---
  signature <- function(v) {
    nbrs <- nbrs_of(v)
    if (length(nbrs) == 0) return(rep(0, length(groups)))
    nbrs <- as.integer(nbrs)
    nbr_groups <- grp[nbrs]
    tab <- base::table(nbr_groups)
    vec <- rep(0, length(groups))
    vec[group_index[names(tab)]] <- as.numeric(tab)
    if (sum(vec) > 0) vec <- vec / sum(vec)
    vec
  }
  
  cosine_sim <- function(a, b) {
    denom <- sqrt(sum(a*a)) * sqrt(sum(b*b))
    if (denom == 0) return(NA_real_)
    sum(a*b) / denom
  }
  
  # --- Determine focal nodes ---
  if (!is.null(team_value)) {
    focal <- which(grp == team_value)
    if (length(focal) == 0)
      stop("No vertices found for team_value = ", team_value)
  } else {
    focal <- seq_len(igraph::vcount(g))
  }
  
  # --- Precompute signatures ---
  cat("Computing bridge signatures for", igraph::vcount(g), "nodes...\n")
  sigs <- lapply(seq_len(igraph::vcount(g)), signature)
  
  cat("Finding replacements for", length(focal), "focal nodes...\n")
  pb <- txtProgressBar(min = 0, max = length(focal), style = 3)
  
  rows <- vector("list", length(focal))
  
  for (i in seq_along(focal)) {
    v <- focal[i]
    
    # SAME TEAM candidates
    cand_same <- setdiff(which(grp == grp[v]), v)
    
    sims_same <- if (length(cand_same) > 0)
      vapply(cand_same, function(cj) cosine_sim(sigs[[v]], sigs[[cj]]), numeric(1))
    else numeric(0)
    
    if (length(sims_same) > 0 && any(!is.na(sims_same))) {
      best_same <- cand_same[which.max(sims_same)]
      best_same_sim <- max(sims_same, na.rm = TRUE)
    } else {
      best_same <- NA_integer_
      best_same_sim <- NA_real_
    }
    
    # ALL ORG candidates
    cand_all <- setdiff(seq_len(igraph::vcount(g)), v)
    
    sims_all <- vapply(cand_all, function(cj) cosine_sim(sigs[[v]], sigs[[cj]]), numeric(1))
    
    if (length(sims_all) > 0 && any(!is.na(sims_all))) {
      best_all <- cand_all[which.max(sims_all)]
      best_all_sim <- max(sims_all, na.rm = TRUE)
    } else {
      best_all <- NA_integer_
      best_all_sim <- NA_real_
    }
    
    rows[[i]] <- data.frame(
      person_name = v_names[v],
      team_value = grp[v],
      
      same_team_replacement = if (!is.na(best_same)) v_names[best_same] else NA_character_,
      same_team_similarity = best_same_sim,
      same_team_exists = !is.na(best_same_sim) && best_same_sim >= min_similarity,
      
      all_org_replacement = if (!is.na(best_all)) v_names[best_all] else NA_character_,
      all_org_similarity = best_all_sim,
      all_org_exists = !is.na(best_all_sim) && best_all_sim >= min_similarity,
      
      stringsAsFactors = FALSE
    )
    
    setTxtProgressBar(pb, i)
  }
  
  close(pb)
  cat("\nReplacement analysis completed!\n")
  
  out <- do.call(rbind, rows)
  
  # Sort: lowest same-team similarity first (risk view)
  out <- out[order(out$same_team_similarity), ]
  rownames(out) <- NULL
  
  out
}