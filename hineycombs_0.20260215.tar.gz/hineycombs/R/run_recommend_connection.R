#' Add Recommended Cross-Community Connections to a Network Graph
#'
#' For each node in the graph, finds a recommended connection that is the farthest node 
#' outside their community (based on community detection), optionally filtered by a shared attribute. 
#' Ensures no node is recommended more than a specified number of times.
#'
#' @param g An `igraph` object representing the network.
#' @param attribute_filter Optional. A character string naming a vertex attribute to match on (e.g., "gender").
#' @param same_value Logical. If `TRUE`, only recommend nodes with the same attribute value. 
#'        If `FALSE`, nodes with different values are considered. Default is `TRUE`.
#' @param max_recommendations Integer. Maximum number of times any node can be recommended. Default is 2.
#' @param community_method Character. Community detection method: `"louvain"` (default) or `"walktrap"`.
#'
#' @return The modified `igraph` object with a new vertex attribute `recommended_connection`.
#'
#' @importFrom igraph V distances vertex_attr vcount cluster_louvain cluster_walktrap membership
#' @importFrom stats setNames
#' @export
run_recommend_connection <- function(g, attribute_filter = NULL, same_value = TRUE, max_recommendations = 2, community_method = "louvain") {
  # Convert to undirected graph
  g <- igraph::as.undirected(g, mode = "collapse")
  
  all_node_ids <- igraph::V(g)$name
  recommended_connections <- character(length(all_node_ids))
  recommendation_counts <- stats::setNames(rep(0, igraph::vcount(g)),
                                           igraph::V(g)$name)
  
  # Community detection
  comm <- if (community_method == "walktrap") {
    igraph::cluster_walktrap(g)
  }
  else {
    igraph::cluster_louvain(g)
  }
  comm_membership <- igraph::membership(comm)
  
  # Initialize progress bar
  pb <- txtProgressBar(min = 0, max = length(all_node_ids), style = 3)
  
  for (i in seq_along(all_node_ids)) {
    node_id <- all_node_ids[i]
    node_comm <- comm_membership[node_id]
    
    dist_vec <- igraph::distances(g, v = node_id, to = igraph::V(g),
                                  mode = "out")
    dist_vec <- as.numeric(dist_vec)
    names(dist_vec) <- igraph::V(g)$name
    
    dist_vec <- dist_vec[names(dist_vec) != node_id]
    
    other_comm_names <- igraph::V(g)$name[comm_membership != node_comm]
    dist_vec <- dist_vec[names(dist_vec) %in% other_comm_names]
    
    if (!is.null(attribute_filter)) {
      node_attr_vec <- igraph::vertex_attr(g, attribute_filter)
      node_attr_val <- node_attr_vec[which(igraph::V(g)$name == node_id)]
      
      candidate_names <- if (same_value) {
        igraph::V(g)$name[node_attr_vec == node_attr_val]
      }
      else {
        igraph::V(g)$name[node_attr_vec != node_attr_val]
      }
      dist_vec <- dist_vec[names(dist_vec) %in% candidate_names]
    }
    
    allowed <- names(recommendation_counts)[recommendation_counts < max_recommendations]
    dist_vec <- dist_vec[names(dist_vec) %in% allowed]
    
    if (length(dist_vec) == 0 || all(is.infinite(dist_vec))) {
      recommended_connections[i] <- NA
    }
    else {
      recommended_node <- names(which.max(dist_vec))
      recommended_connections[i] <- recommended_node
      recommendation_counts[recommended_node] <- recommendation_counts[recommended_node] + 1
    }
    
    # Update progress bar
    setTxtProgressBar(pb, i)
  }
  
  # Close progress bar
  close(pb)
  
  igraph::V(g)$recommended_connection <- recommended_connections
  
  return(g)
}