#' Identify a weighted network backbone via the Serrano disparity filter
#'
#' Implements the disparity filter backbone method from Serrano, Boguñá, & Vespignani (2009),
#' which retains edges that are unusually strong relative to each node's total strength.
#' This is especially useful for dense graphs where "everything connects to everything."
#'
#' @details
#' For each node i with degree k_i and incident weights w_ij, define strength s_i = sum_j w_ij.
#' Compute p_ij = w_ij / s_i. Under a null model where strength is uniformly distributed across
#' edges, the edge-level significance can be approximated as:
#'   alpha_ij = (1 - p_ij)^(k_i - 1)
#'
#' Edges are retained if alpha_ij < alpha by the specified rule:
#' - rule = "or": keep if significant for either endpoint (common choice)
#' - rule = "and": keep only if significant for both endpoints (stricter)
#'
#' Notes:
#' - Requires non-negative edge weights.
#' - For k_i <= 1, we treat alpha_ij as 0 (trivially retained if present).
#' - For directed graphs, endpoint evaluation uses tail/head based on `mode`.
#'
#' @param g An igraph object.
#' @param alpha Numeric in (0,1). Smaller => more aggressive pruning. Typical: 0.01–0.10.
#' @param weight_attr Character. Edge attribute name containing weights.
#' @param rule Character. "or" or "and" rule for endpoint significance.
#' @param mode Character. For directed graphs: "out", "in", or "all" for incident edges used per node.
#' @param keep_isolates Logical. If TRUE, keep all vertices even if they become isolated (default TRUE).
#' @param simplify Logical. If TRUE, simplify result (remove loops/multiple edges).
#' @param add_alpha_attrs Logical. If TRUE, add edge attributes `alpha_from`, `alpha_to`, `alpha_keep`.
#'
#' @return An igraph object containing the backbone subgraph.
#' @export
run_dense_backbone_serrano <- function(
    g,
    alpha = 0.05,
    weight_attr = "weight",
    rule = c("or", "and"),
    mode = c("out", "in", "all"),
    keep_isolates = TRUE,
    simplify = TRUE,
    add_alpha_attrs = FALSE
) {
  stopifnot(igraph::is_igraph(g))
  rule <- match.arg(rule)
  mode <- match.arg(mode)
  
  if (igraph::ecount(g) == 0) return(g)
  
  w <- igraph::edge_attr(g, weight_attr)
  if (is.null(w)) stop("Edge weight attribute not found: ", weight_attr)
  w <- as.numeric(w)
  if (any(w < 0, na.rm = TRUE)) stop("Serrano disparity backbone requires non-negative weights.")
  
  # For each edge, store alpha from each endpoint
  alpha_from <- rep(NA_real_, igraph::ecount(g))
  alpha_to   <- rep(NA_real_, igraph::ecount(g))
  
  ends_mat <- igraph::ends(g, igraph::E(g), names = FALSE)
  tail_ids <- ends_mat[, 1]
  head_ids <- ends_mat[, 2]
  
  compute_node_alpha <- function(eids) {
    ki <- length(eids)
    if (ki <= 1) return(setNames(rep(0, ki), eids))
    wi <- w[eids]
    si <- sum(wi, na.rm = TRUE)
    if (!is.finite(si) || si <= 0) return(setNames(rep(1, ki), eids))
    pij <- wi / si
    aij <- (1 - pij)^(ki - 1)
    setNames(aij, eids)
  }
  
  # Iterate vertices; compute alpha for incident edges at that vertex
  for (v in igraph::V(g)) {
    eids <- igraph::incident(g, v, mode = mode)
    if (length(eids) == 0) next
    
    a_map <- compute_node_alpha(eids)
    v_id <- as.integer(v)
    
    for (e in as.integer(names(a_map))) {
      a <- a_map[[as.character(e)]]
      
      if (igraph::is_directed(g)) {
        # store alpha on the appropriate endpoint slot
        if (tail_ids[e] == v_id) alpha_from[e] <- a
        if (head_ids[e] == v_id) alpha_to[e]   <- a
      } else {
        # undirected: fill whichever side matches v
        if (tail_ids[e] == v_id) alpha_from[e] <- a
        if (head_ids[e] == v_id) alpha_to[e]   <- a
      }
    }
  }
  
  keep <- if (rule == "or") {
    (alpha_from < alpha) | (alpha_to < alpha)
  } else {
    (alpha_from < alpha) & (alpha_to < alpha)
  }
  keep[is.na(keep)] <- FALSE
  
  gb <- igraph::subgraph.edges(g, igraph::E(g)[keep], delete.vertices = !keep_isolates)
  
  if (simplify) gb <- igraph::simplify(gb, remove.multiple = TRUE, remove.loops = TRUE)
  
  if (add_alpha_attrs && igraph::ecount(gb) > 0) {
    # Map kept edges back to original indices
    # subgraph.edges preserves edge sequence from original for those edges
    # so we can attach alphas corresponding to original eids.
    kept_eids <- as.integer(igraph::E(g)[keep])
    igraph::E(gb)$alpha_from <- alpha_from[kept_eids]
    igraph::E(gb)$alpha_to   <- alpha_to[kept_eids]
    igraph::E(gb)$alpha_keep <- TRUE
  }
  
  gb
}