# ============================================================
# Network Leader Utilities (igraph)
# - identify_flow_bottlenecks()
# - recommend_bridging_ties()
# - calculate_redundancy_balance()
# ============================================================

#' Identify flow bottlenecks in a collaboration network
#'
#' @description
#' Finds people (or teams, if aggregated) who are likely to be "flow bottlenecks":
#' high brokerage / gatekeeping positions with low redundancy and low local backup.
#'
#' Supports optional subsetting to a "project edge set" if you only want to analyze
#' flow along a subset of edges (e.g., edges that represent a specific workflow).
#'
#' @param g An igraph object (directed or undirected). Can be weighted (edge attr "weight").
#' @param project_edges Optional. One of:
#'   - NULL (use full graph)
#'   - numeric vector of edge IDs (as used by igraph E(g))
#'   - character scalar: name of a logical edge attribute (TRUE/FALSE) to filter edges
#'   - logical vector of length ecount(g) indicating which edges to keep
#' @param team_attr Optional. Vertex attribute name (string). If provided, returns a TEAM-level
#'   view by aggregating node metrics to team (mean/median/max).
#' @param directed_flow Logical. If TRUE, uses directed paths; if FALSE, uses undirected paths.
#' @param use_weights Logical. If TRUE and "weight" exists, uses it as edge weights.
#'   Note: for shortest paths, weights are treated as distances. If your weights are
#'   frequencies/strengths, consider setting use_weights=FALSE (or transform first).
#' @param verbose Logical. Print progress.
#'
#' @return A list with:
#'   - node_results: tibble of node-level bottleneck diagnostics
#'   - team_results: tibble of team-level summary (if team_attr provided), else NULL
#'   - graph_used: the graph actually analyzed (possibly subset by project_edges)
#'
#' @importFrom dplyr mutate group_by summarise arrange desc n
#' @importFrom tibble tibble
#' @importFrom igraph is_igraph vcount ecount vertex_attr_names edge_attr_names vertex_attr
#' @importFrom igraph E V subgraph.edges betweenness neighbors induced_subgraph edge_density
#' @importFrom igraph degree constraint is_directed
#' @importFrom stats sd
#'
#' @examples
#' \dontrun{
#' res <- run_insights_identify_bottlenecks(g)
#' head(res$node_results)
#' }
#' 
#' @export
run_insights_identify_bottlenecks <- function(
    g,
    project_edges = NULL,
    team_attr = NULL,
    directed_flow = TRUE,
    use_weights = FALSE,
    verbose = FALSE
) {
  # ---- checks ----
  if (!inherits(g, "igraph")) stop("g must be an igraph object.")
  if (!igraph::is_igraph(g)) stop("g must be a valid igraph object.")
  
  pkgs <- c("dplyr", "tibble", "rlang")
  missing <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing) > 0) stop("Missing packages: ", paste(missing, collapse = ", "))
  
  if (verbose) cat("Starting identify_flow_bottlenecks()...\n")
  
  # ---- subset edges if requested ----
  g2 <- g
  if (!is.null(project_edges)) {
    if (verbose) cat("Applying project_edges filter...\n")
    e_keep <- NULL
    
    if (is.numeric(project_edges)) {
      # edge IDs
      e_keep <- rep(FALSE, igraph::ecount(g2))
      e_keep[project_edges] <- TRUE
    } else if (is.logical(project_edges)) {
      if (length(project_edges) != igraph::ecount(g2)) {
        stop("If project_edges is logical, it must have length ecount(g).")
      }
      e_keep <- project_edges
    } else if (is.character(project_edges) && length(project_edges) == 1) {
      # edge attribute name
      if (!project_edges %in% igraph::edge_attr_names(g2)) {
        stop("project_edges character provided, but no such edge attribute: ", project_edges)
      }
      e_attr <- igraph::edge_attr(g2, project_edges)
      if (!is.logical(e_attr)) stop("Edge attribute '", project_edges, "' must be logical TRUE/FALSE.")
      e_keep <- e_attr
    } else {
      stop("project_edges must be NULL, numeric edge IDs, logical vector, or a character edge-attr name.")
    }
    
    g2 <- igraph::subgraph.edges(g2, eids = igraph::E(g2)[which(e_keep)], delete.vertices = TRUE)
    if (igraph::ecount(g2) == 0) stop("After filtering, graph has 0 edges.")
  }
  
  # ---- weights ----
  w <- NULL
  if (use_weights && "weight" %in% igraph::edge_attr_names(g2)) {
    w <- igraph::E(g2)$weight
  }
  
  # ---- helper: safe z ----
  zscore <- function(x) {
    s <- stats::sd(x, na.rm = TRUE)
    if (is.na(s) || s == 0) return(rep(0, length(x)))
    (x - mean(x, na.rm = TRUE)) / s
  }
  
  # ---- compute bottleneck diagnostics ----
  if (verbose) cat("Computing core metrics...\n")
  
  btw <- igraph::betweenness(
    g2,
    directed = directed_flow && igraph::is_directed(g2),
    weights  = w,
    normalized = TRUE
  )
  
  # local backup: local edge density in ego network (minus ego)
  local_backup <- vapply(igraph::V(g2), function(v) {
    nb <- igraph::neighbors(g2, v, mode = if (igraph::is_directed(g2) && directed_flow) "all" else "all")
    if (length(nb) < 2) return(0)
    sub <- igraph::induced_subgraph(g2, vids = nb)
    igraph::edge_density(sub, loops = FALSE)
  }, numeric(1))
  
  # redundancy / constraint: Burt's constraint (higher = more constrained, less brokerage freedom)
  # igraph's constraint is for unweighted ties unless weights are set as edge weights in graph;
  # here we compute unweighted constraint for robustness.
  constr <- tryCatch({
    igraph::constraint(g2)
  }, error = function(e) rep(NA_real_, igraph::vcount(g2)))
  
  deg_all <- igraph::degree(g2, mode = if (igraph::is_directed(g2) && directed_flow) "all" else "all")
  deg_in  <- if (igraph::is_directed(g2)) igraph::degree(g2, mode = "in") else deg_all
  deg_out <- if (igraph::is_directed(g2)) igraph::degree(g2, mode = "out") else deg_all
  
  # Bottleneck score:
  # - high betweenness (more gatekeeping)
  # - high constraint (fewer alternate routes controlled by ego's neighbors) -> bottleneck risk up
  # - low local backup (neighbors not connected) -> bottleneck risk up
  bottleneck_score <- 0.50 * zscore(btw) + 0.30 * zscore(constr) + 0.20 * zscore(-local_backup)
  
  node_names <- igraph::V(g2)$name
  if (is.null(node_names)) node_names <- as.character(seq_len(igraph::vcount(g2)))
  
  node_tbl <- tibble::tibble(
    node_id = seq_len(igraph::vcount(g2)),
    node    = node_names,
    degree_all = as.numeric(deg_all),
    degree_in  = as.numeric(deg_in),
    degree_out = as.numeric(deg_out),
    betweenness_norm = as.numeric(btw),
    constraint = as.numeric(constr),
    local_backup_density = as.numeric(local_backup),
    bottleneck_score = as.numeric(bottleneck_score)
  ) |>
    dplyr::arrange(dplyr::desc(.data$bottleneck_score))
  
  # ---- optional: team aggregation ----
  team_tbl <- NULL
  if (!is.null(team_attr)) {
    if (!team_attr %in% igraph::vertex_attr_names(g2)) {
      stop("team_attr '", team_attr, "' not found in vertex attributes.")
    }
    teams <- igraph::vertex_attr(g2, team_attr)
    node_tbl <- dplyr::mutate(node_tbl, team = as.character(teams))
    
    team_tbl <- node_tbl |>
      dplyr::group_by(.data$team) |>
      dplyr::summarise(
        n_nodes = dplyr::n(),
        bottleneck_mean = mean(.data$bottleneck_score, na.rm = TRUE),
        bottleneck_max  = max(.data$bottleneck_score, na.rm = TRUE),
        btw_mean        = mean(.data$betweenness_norm, na.rm = TRUE),
        constr_mean     = mean(.data$constraint, na.rm = TRUE),
        backup_mean     = mean(.data$local_backup_density, na.rm = TRUE),
        .groups = "drop"
      ) |>
      dplyr::arrange(dplyr::desc(.data$bottleneck_mean))
  }
  
  if (verbose) cat("Done.\n")
  
  list(
    node_results = node_tbl,
    team_results = team_tbl,
    graph_used   = g2
  )
}