#' Calculate redundancy / exploration balance for individuals or teams
#'
#' @description
#' Computes network redundancy vs exploration diagnostics based on:
#' - local clustering (triadic closure) proxy: local transitivity
#' - Burt constraint (redundancy/high closure)
#' - effective size (non-redundant contacts)
#'
#' Optionally aggregates to team-level summaries.
#'
#' @param g An igraph object.
#' @param team_attr Optional vertex attribute name to aggregate to teams.
#' @param directed_flow Logical. If TRUE and graph is directed, uses "all" neighbors for ego calculations.
#' @param verbose Logical.
#'
#' @return A list with:
#'   - node_results: tibble of individual-level redundancy/exploration metrics
#'   - team_results: tibble of team-level summaries (if team_attr provided)
#'
#' @examples
#' \dontrun{
#' rb <- run_insights_redundancy_balance(g, team_attr = "team")
#' rb$team_results
#' }
#' 
#' @export
run_insights_redundancy_balance <- function(
    g,
    team_attr = NULL,
    directed_flow = TRUE,
    verbose = FALSE
) {
  
  if (!inherits(g, "igraph")) stop("g must be an igraph object.")
  
  if (verbose) cat("Starting run_insights_redundancy_balance()...\n")
  
  # ---- copy graph & remove weights (unweighted interpretation) ----
  g2 <- g
  if ("weight" %in% igraph::edge_attr_names(g2)) {
    g2 <- igraph::delete_edge_attr(g2, "weight")
  }
  
  # ---- undirected/simple for Burt-style structural holes metrics ----
  g_burt <- g2
  if (igraph::is_directed(g_burt)) {
    if (verbose) cat("Converting directed graph to undirected for Burt metrics...\n")
    g_burt <- igraph::as.undirected(g_burt, mode = "collapse")
  }
  g_burt <- igraph::simplify(g_burt, remove.multiple = TRUE, remove.loops = TRUE)
  
  # ---- node names ----
  v_names <- igraph::V(g2)$name
  if (is.null(v_names)) v_names <- as.character(seq_len(igraph::vcount(g2)))
  
  # ---- effective size: robust across igraph versions ----
  calc_effective_size <- function(gr) {
    ig_exports <- tryCatch(getNamespaceExports("igraph"), error = function(e) character(0))
    
    # Prefer exported functions if present
    if ("effective_size" %in% ig_exports) {
      return(igraph::effective_size(gr))
    }
    if ("effective.size" %in% ig_exports) {
      return(igraph::effective.size(gr))
    }
    
    # If it exists but isn't exported (rare), try internal
    if (exists("effective_size", envir = asNamespace("igraph"), inherits = FALSE)) {
      return(igraph:::effective_size(gr))
    }
    if (exists("effective.size", envir = asNamespace("igraph"), inherits = FALSE)) {
      return(igraph:::effective.size(gr))
    }
    
    # Fallback: compute effective size from adjacency (Burt formulation)
    # e_i = sum_{j in N(i)} (1 - sum_q p_iq * p_jq), where p_iq = a_iq / deg_i
    A <- igraph::as_adjacency_matrix(gr, sparse = FALSE)
    A <- as.matrix(A)
    diag(A) <- 0
    deg <- rowSums(A)
    
    # Row-normalized tie proportions P (handle isolates)
    P <- matrix(0, nrow = nrow(A), ncol = ncol(A))
    nz <- deg > 0
    P[nz, ] <- A[nz, , drop = FALSE] / deg[nz]
    
    # redundancy_ij = sum_q p_iq * p_jq  -> matrix R = P %*% t(P)
    R <- P %*% t(P)
    
    # effective size: sum_j a_ij * (1 - redundancy_ij)
    eff <- rowSums(A * (1 - R))
    as.numeric(eff)
  }
  
  # ---- compute metrics ----
  if (verbose) cat("Computing local transitivity...\n")
  loc_trans <- igraph::transitivity(g_burt, type = "local", isolates = "zero")
  
  if (verbose) cat("Computing Burt constraint...\n")
  constr <- igraph::constraint(g_burt)
  
  if (verbose) cat("Computing effective size...\n")
  effsz <- calc_effective_size(g_burt)
  
  # Degree (from original structure; unweighted either way)
  deg_all <- igraph::degree(g2, mode = "all")
  
  # ---- safe z ----
  safe_z <- function(x) {
    if (all(is.na(x))) return(rep(NA_real_, length(x)))
    s <- stats::sd(x, na.rm = TRUE)
    if (is.na(s) || s == 0) return(rep(0, length(x)))
    (x - mean(x, na.rm = TRUE)) / s
  }
  
  # ---- composites ----
  exploration_score <-
    0.5 * safe_z(effsz) +
    0.3 * safe_z(-constr) +
    0.2 * safe_z(-loc_trans)
  
  closure_score <-
    0.5 * safe_z(constr) +
    0.5 * safe_z(loc_trans)
  
  balance <- exploration_score - closure_score
  
  # ---- node results ----
  node_tbl <- tibble::tibble(
    node_id = seq_len(igraph::vcount(g2)),
    node = v_names,
    degree_all = as.numeric(deg_all),
    local_transitivity = as.numeric(loc_trans),
    constraint = as.numeric(constr),
    effective_size = as.numeric(effsz),
    exploration_score = as.numeric(exploration_score),
    closure_score = as.numeric(closure_score),
    balance = as.numeric(balance)
  ) |>
    dplyr::arrange(dplyr::desc(.data$balance))
  
  # ---- team results (optional) ----
  team_tbl <- NULL
  if (!is.null(team_attr)) {
    if (!team_attr %in% igraph::vertex_attr_names(g2)) {
      stop("team_attr '", team_attr, "' not found in vertex attributes.")
    }
    teams <- as.character(igraph::vertex_attr(g2, team_attr))
    node_tbl <- dplyr::mutate(node_tbl, team = teams)
    
    team_tbl <- node_tbl |>
      dplyr::group_by(.data$team) |>
      dplyr::summarise(
        n_nodes = dplyr::n(),
        exploration_mean = mean(.data$exploration_score, na.rm = TRUE),
        closure_mean = mean(.data$closure_score, na.rm = TRUE),
        balance_mean = mean(.data$balance, na.rm = TRUE),
        constraint_mean = mean(.data$constraint, na.rm = TRUE),
        transitivity_mean = mean(.data$local_transitivity, na.rm = TRUE),
        effsize_mean = mean(.data$effective_size, na.rm = TRUE),
        .groups = "drop"
      ) |>
      dplyr::mutate(effsize_mean = ifelse(is.nan(.data$effsize_mean), NA_real_, .data$effsize_mean)) |>
      dplyr::arrange(dplyr::desc(.data$balance_mean))
  }
  
  if (verbose) cat("Done.\n")
  
  list(node_results = node_tbl, team_results = team_tbl)
}