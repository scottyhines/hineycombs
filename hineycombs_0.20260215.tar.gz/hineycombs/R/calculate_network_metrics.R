#' Calculate network-level metrics and assign a network archetype
#'
#' @param g igraph object
#' @param assortivity_vars optional vertex attributes for assortativity
#' @param intensive_calc logical; compute diameter/APL/betweenness centralization/small-world
#' @param archetype_method "absolute" uses fixed thresholds; "zscore" uses z-scores vs reference_df
#' @param reference_df data.frame of metrics from many networks (required if archetype_method="zscore")
#' @param return_description if TRUE, include a brief text explanation of the archetype decision
#'
#' @return data.frame with metrics + archetype fields
#' @export
calculate_network_metrics <- function(
    g,
    assortivity_vars = NULL,
    intensive_calc = FALSE,
    archetype_method = c("absolute", "zscore"),
    reference_df = NULL,
    return_description = TRUE
) {
  metrics <- list()
  cat("Starting network metrics calculation...\n")
  
  g_unweighted <- igraph::delete_edge_attr(g, "weight")
  
  metrics$vcount <- igraph::vcount(g_unweighted)
  metrics$ecount <- igraph::ecount(g_unweighted)
  metrics$density <- igraph::edge_density(g_unweighted)
  
  if (intensive_calc) {
    metrics$diameter <- tryCatch(
      igraph::diameter(g_unweighted, directed = FALSE, unconnected = TRUE),
      error = function(e) NA_real_
    )
    metrics$average_path_length <- tryCatch(
      igraph::mean_distance(g_unweighted, directed = FALSE, unconnected = TRUE),
      error = function(e) NA_real_
    )
    metrics$centralization_betweenness <- tryCatch(
      igraph::centr_betw(g_unweighted, directed = FALSE)$centralization,
      error = function(e) NA_real_
    )
    metrics$small_world <- tryCatch(
      qgraph::smallworldIndex(g_unweighted)$index,
      error = function(e) NA_real_
    )
  } else {
    metrics$diameter <- NA_real_
    metrics$average_path_length <- NA_real_
    metrics$centralization_betweenness <- NA_real_
    metrics$small_world <- NA_real_
  }
  
  metrics$modularity <- tryCatch({
    g_undirected <- igraph::as_undirected(g_unweighted, mode = "collapse")
    comm <- igraph::cluster_fast_greedy(g_undirected)
    igraph::modularity(comm)
  }, error = function(e) NA_real_)
  
  metrics$transitivity <- tryCatch(
    igraph::transitivity(g_unweighted, type = "global"),
    error = function(e) NA_real_
  )
  
  metrics$centralization_degree <- tryCatch(
    igraph::centr_degree(g_unweighted, mode = "total")$centralization,
    error = function(e) NA_real_
  )
  
  # NOTE: your current code stores mean harmonic closeness here (not centralization)
  metrics$centralization_closeness <- tryCatch({
    harmonic_values <- igraph::harmonic_centrality(g_unweighted, mode = "all")
    mean(harmonic_values)
  }, error = function(e) NA_real_)
  
  metrics$centralization_eigen <- tryCatch(
    igraph::centr_eigen(g_unweighted, directed = FALSE)$centralization,
    error = function(e) NA_real_
  )
  
  # components
  comp <- igraph::components(g_unweighted)
  metrics$number_of_components <- comp$no
  metrics$max_component_size <- max(comp$csize)
  
  # assortativity
  if (!is.null(assortivity_vars)) {
    for (var in assortivity_vars) {
      if (var %in% igraph::vertex_attr_names(g_unweighted)) {
        metrics[[paste0("assortativity_", var)]] <- tryCatch(
          igraph::assortativity_nominal(g_unweighted, types = igraph::vertex_attr(g_unweighted, var)),
          error = function(e) NA_real_
        )
      } else {
        metrics[[paste0("assortativity_", var)]] <- NA_real_
      }
    }
  }
  
  out <- as.data.frame(metrics)
  
  # ============================================================
  # Archetype assignment (absolute or z-score)
  # ============================================================
  archetype_method <- match.arg(archetype_method)
  
  # helper: z-score vs reference
  z_from_ref <- function(x, ref_vec) {
    if (is.null(ref_vec) || all(is.na(ref_vec))) return(NA_real_)
    s <- stats::sd(ref_vec, na.rm = TRUE)
    m <- mean(ref_vec, na.rm = TRUE)
    if (!is.finite(s) || s == 0) return(NA_real_)
    (x - m) / s
  }
  
  # choose which values to use for rule checks
  if (archetype_method == "zscore") {
    if (is.null(reference_df)) {
      stop("reference_df is required when archetype_method = 'zscore'.")
    }
    # compute z versions of the metrics used in rules
    z <- list(
      team_size = z_from_ref(out$vcount, reference_df$vcount),
      density = z_from_ref(out$density, reference_df$density),
      modularity = z_from_ref(out$modularity, reference_df$modularity),
      transitivity = z_from_ref(out$transitivity, reference_df$transitivity),
      diameter = z_from_ref(out$diameter, reference_df$diameter),
      small_world = z_from_ref(out$small_world, reference_df$small_world),
      components = z_from_ref(out$number_of_components, reference_df$number_of_components),
      c_betw = z_from_ref(out$centralization_betweenness, reference_df$centralization_betweenness),
      c_deg = z_from_ref(out$centralization_degree, reference_df$centralization_degree),
      c_eig = z_from_ref(out$centralization_eigen, reference_df$centralization_eigen)
    )
    # rule thresholds in z space (simple: +/-1, etc.)
    get <- z
    # note: use out$vcount as team_size proxy here; swap in real team_size if you have it elsewhere
  } else {
    # absolute mode uses raw metrics directly
    get <- list(
      team_size = out$vcount,
      density = out$density,
      modularity = out$modularity,
      transitivity = out$transitivity,
      diameter = out$diameter,
      small_world = out$small_world,
      components = out$number_of_components,
      c_betw = out$centralization_betweenness,
      c_deg = out$centralization_degree,
      c_eig = out$centralization_eigen
    )
  }
  
  notes <- c()
  
  score_fragmented_giant <- (
    (get$team_size > 1000) * 5 +
      (get$density < 0.01) * 1 +
      (get$modularity > 0.80) * 1 +
      (get$diameter > 300) * 1 +
      (get$small_world < 10) * 1 +
      (get$components > 10) * 1
  )
  
  score_tight_knit <- (
    (get$density > 0.30) * 2 +
      (get$transitivity > 0.40) * 2 +
      (get$modularity < 0.50) * 1 +
      (get$components == 1) * 1 +
      (get$c_deg > 0.15) * 1
  )
  
  score_hub_spoke <- (
    (get$c_betw > 0.08) * 2 +
      (get$c_deg > 0.35) * 2 +
      (get$transitivity < 0.50) * 1 +
      (get$c_eig > 0.30) * 1 +
      (get$components == 1) * 1
  )
  
  score_distributed <- (
    (get$density >= 0.01 & get$density <= 0.20) * 1 +
      (get$c_betw < 0.15) * 2 +
      (get$c_deg < 0.25) * 2 +
      (get$modularity >= 0.40) * 1 +
      (get$components >= 2 & get$components <= 10) * 1
  )
  
  score_sparse <- (
    (get$density < 0.02) * 2 +
      (get$modularity > 0.60) * 2 +
      (get$transitivity < 0.35) * 1 +
      (get$components >= 3) * 2
  )
  
  score_balanced <- (
    (get$density >= 0.02 & get$density <= 0.25) * 1 +
      (get$transitivity >= 0.15 & get$transitivity <= 0.50) * 1 +
      (get$modularity >= 0.45 & get$modularity <= 0.85) * 1 +
      (get$components <= 5) * 1 +
      (get$c_betw >= 0.01 & get$c_betw <= 0.15) * 1
  )
  
  score_emerging <- (
    (get$team_size < 50) * 3 +
      (get$density > 0.20) * 1 +
      (get$components <= 2) * 1 +
      (get$transitivity > 0.30) * 1
  )
  
  score_broker_heavy <- (
    (get$c_betw > 0.05) * 2 +
      (get$transitivity < 0.40) * 1 +
      (get$modularity > 0.55) * 2 +
      (get$c_deg < 0.40) * 1
  )
  
  archetype <- dplyr::case_when(
    score_fragmented_giant >= 8 ~ "Fragmented Giant",
    score_hub_spoke >= 5 ~ "Hub-and-Spoke Network",
    score_tight_knit >= 5 ~ "Tight-Knit Collaborator",
    score_broker_heavy >= 4 ~ "Broker-Heavy Team",
    score_sparse >= 5 ~ "Sparse Network",
    score_distributed >= 4 ~ "Distributed Connector",
    score_balanced >= 3 ~ "Balanced Integrator",
    score_emerging >= 4 ~ "Emerging Network",
    TRUE ~ "Mixed Pattern"
  )
  
  archetype_secondary <- dplyr::case_when(
    archetype == "Tight-Knit Collaborator" & score_emerging >= 4 ~ "Also Emerging",
    archetype == "Hub-and-Spoke Network" & score_broker_heavy >= 4 ~ "Also Broker-Heavy",
    archetype == "Distributed Connector" & score_sparse >= 5 ~ "Also Sparse",
    TRUE ~ NA_character_
  )
  
  if (return_description) {
    notes <- c(
      paste0("Method: ", archetype_method),
      paste0("Scores — FragmentedGiant=", score_fragmented_giant,
             ", HubSpoke=", score_hub_spoke,
             ", TightKnit=", score_tight_knit,
             ", BrokerHeavy=", score_broker_heavy,
             ", Sparse=", score_sparse,
             ", Distributed=", score_distributed,
             ", Balanced=", score_balanced,
             ", Emerging=", score_emerging),
      paste0("Primary archetype: ", archetype,
             if (!is.na(archetype_secondary)) paste0(" (", archetype_secondary, ")") else "")
    )
  }
  
  out$archetype_method <- archetype_method
  out$archetype <- archetype
  out$archetype_secondary <- archetype_secondary
  out$archetype_notes <- if (return_description) paste(notes, collapse = " | ") else NA_character_
  
  out
}
