---
title: "Hineycombs Package Showcase"
author: "Network Analysis Toolkit"
date: "2026-01-29"
output: 
  html_document:
    toc: true
    toc_float: true
    theme: flatly
    code_folding: show
---



# Introduction

The `hineycombs` package provides a comprehensive toolkit for network analysis and exploratory data analysis. This showcase demonstrates key functions across different categories:

- Network creation and data extraction
- Network metrics and centrality measures
- Community detection and visualization
- Diffusion and influence modeling
- Link prediction and recommendations


``` r
library(hineycombs)
library(igraph)
library(dplyr)
```

---

# 1. Creating Networks

## 1.1 Synthetic Network Creation

The `create_network()` function generates reproducible synthetic networks with rich attributes.


``` r
# Create a synthetic organizational network
set.seed(123)
g <- create_network(
  n = 100,           # 100 nodes
  p = 0.15,          # 15% edge probability
  directed = TRUE,   # Directed network
  seed = 123
)

# Inspect the network
cat("Network size:", vcount(g), "nodes,", ecount(g), "edges\n")
```

```
## Network size: 100 nodes, 1477 edges
```

``` r
cat("Vertex attributes:", paste(vertex_attr_names(g), collapse = ", "), "\n")
```

```
## Vertex attributes: name, group, gender, region, performance, job_level, team, psych_safety, risk_taking, innovation, collaboration_quality
```

``` r
cat("Edge attributes:", paste(edge_attr_names(g), collapse = ", "), "\n")
```

```
## Edge attributes: weight
```

## 1.2 Using Classic Networks


``` r
# Load the famous Zachary Karate Club network
g_zachary <- make_graph("Zachary")
V(g_zachary)$name <- paste0("Member_", 1:vcount(g_zachary))

# Add some attributes for demonstration
V(g_zachary)$group <- sample(c("A", "B", "C"), vcount(g_zachary), replace = TRUE)
V(g_zachary)$performance <- sample(1:5, vcount(g_zachary), replace = TRUE)

cat("Zachary network:", vcount(g_zachary), "nodes,", ecount(g_zachary), "edges\n")
```

```
## Zachary network: 34 nodes, 78 edges
```

---

# 2. Data Extraction

## 2.1 Pull Network Data

The `pull_data()` function extracts node and edge data into data frames.


``` r
# Extract node data
nodes_df <- pull_data(g, what = "nodes")
head(nodes_df, 5)
```

```
##            name group gender region performance job_level    team psych_safety
## Node001 Node001     B      F  South           4    Senior   Delta    0.8028512
## Node002 Node002     A      M  North           2     Entry   Gamma    0.4691629
## Node003 Node003     A      M   West           3     Entry   Gamma    0.8892941
## Node004 Node004     D      M  North           3     Entry   Alpha    0.9562933
## Node005 Node005     B      F   West           3    Senior Epsilon    0.7421722
##         risk_taking innovation collaboration_quality
## Node001   0.0000000  0.2707666             0.6414526
## Node002   0.2840749  0.2558703             0.3372268
## Node003   0.0000000  0.2945434             0.6411510
## Node004   0.0000000  0.3157780             0.6420368
## Node005   0.0000000  0.1475413             0.4394266
```

``` r
# Extract edge data
edges_df <- pull_data(g, what = "edges")
head(edges_df, 5)
```

```
##      from      to weight
## 1 Node007 Node001     10
## 2 Node019 Node001      2
## 3 Node021 Node001      3
## 4 Node022 Node001      6
## 5 Node025 Node001      6
```

---

# 3. Network Metrics

## 3.1 Network-Level Metrics

Calculate comprehensive network-level statistics.


``` r
# Calculate network metrics
net_metrics <- calculate_network_metrics(
  g, 
  assortivity_vars = c("group", "gender"),
  intensive_calc = FALSE  # Set TRUE for diameter calculations (slower)
)
```

```
## Starting network metrics calculation...
## [1] "Calculated: vcount"
## [1] "Calculated: ecount"
## [1] "Calculated: density"
## [1] "Skipped intensive calculations (diameter, average path length, betweenness centralization, small world index)"
## [1] "Calculated: modularity"
## [1] "Calculated: transitivity"
## [1] "Calculated: degree centralization"
## [1] "Calculated: closeness centralization"
## [1] "Calculated: eigenvector centralization"
```

```
## [1] "Calculated: assortativity for group"
```

```
## [1] "Calculated: assortativity for gender"
## [1] "Calculated: number of components and max component size"
## [1] "Network metrics calculation completed."
```

``` r
# View key metrics
net_metrics %>%
  select(vcount, ecount, density, transitivity, 
         centralization_degree, number_of_components) %>%
  glimpse()
```

```
## Rows: 1
## Columns: 6
## $ vcount                <dbl> 100
## $ ecount                <dbl> 1477
## $ density               <dbl> 0.1491919
## $ transitivity          <dbl> 0.274524
## $ centralization_degree <dbl> 0.06356494
## $ number_of_components  <dbl> 1
```

## 3.2 Node-Level Centrality Metrics

Calculate various centrality measures for each node.


``` r
# Add centrality metrics to the graph
g <- calculate_centrality_metrics(g, include_advanced_metrics = FALSE)
```

```
## Starting basic network metrics calculation...
## Degree metrics completed at: 11:44:37 
## Node Betweenness completed at: 11:44:37 
## Closeness completed at: 11:44:37 
## Harmonic closeness completed at: 11:44:37 
## Coreness (k-core) completed at: 11:44:37 
## Strength completed at: 11:44:37 
## PageRank completed at: 11:44:37 
## Leverage completed at: 11:44:37 
## Eigenvector centrality completed at: 11:44:37 
## Effective size completed at: 11:44:37 
## Constraint completed at: 11:44:37 
## Local transitivity completed at: 11:44:37 
## Diversity completed at: 11:44:37 
## Reach 1 completed at: 11:44:37 
## Reach 2 completed at: 11:44:37 
## Reach 3 completed at: 11:44:37 
## Indemand completed at: 11:44:37 
## Chatty completed at: 11:44:37 
## Engagements completed at: 11:44:37 
## Starting network archetypes classification (basic)...
## Network archetypes completed at: 11:44:37 
## 
## All calculations completed at: 11:44:37
```

``` r
# Extract and view top nodes by betweenness
nodes_with_centrality <- pull_data(g, what = "nodes")

# Show available columns
cat("Available centrality columns:\n")
```

```
## Available centrality columns:
```

``` r
print(names(nodes_with_centrality))
```

```
##  [1] "name"                           "group"                         
##  [3] "gender"                         "region"                        
##  [5] "performance"                    "job_level"                     
##  [7] "team"                           "psych_safety"                  
##  [9] "risk_taking"                    "innovation"                    
## [11] "collaboration_quality"          "degree"                        
## [13] "degree_s"                       "indegree"                      
## [15] "indegree_s"                     "outdegree"                     
## [17] "outdegree_s"                    "betweenness"                   
## [19] "betweenness_s"                  "closeness"                     
## [21] "closeness_s"                    "harmonic_closeness"            
## [23] "harmonic_closeness_s"           "coreness"                      
## [25] "coreness_s"                     "strength"                      
## [27] "strength_s"                     "pagerank"                      
## [29] "pagerank_s"                     "leverage"                      
## [31] "leverage_s"                     "evcent"                        
## [33] "evcent_s"                       "effsize"                       
## [35] "effsize_s"                      "constraint"                    
## [37] "constraint_s"                   "transitivity"                  
## [39] "transitivity_s"                 "diversity"                     
## [41] "diversity_s"                    "reach_1"                       
## [43] "reach_1_s"                      "reach_2"                       
## [45] "reach_2_s"                      "reach_3"                       
## [47] "reach_3_s"                      "indemand"                      
## [49] "indemand_s"                     "chatty"                        
## [51] "chatty_s"                       "engagements"                   
## [53] "engagements_s"                  "network_connector"             
## [55] "network_gatekeeper"             "network_specialist"            
## [57] "network_influencer"             "network_lurker"                
## [59] "network_bridges"                "network_hub"                   
## [61] "network_broadcaster"            "network_magnet"                
## [63] "network_reciprocator"           "network_structural_hole_broker"
## [65] "network_opportunity_broker"     "network_clique_insider"        
## [67] "network_core_insider"           "network_peripheral"            
## [69] "network_reach_amplifier"        "network_boundary_spanner"      
## [71] "network_archetype_count"        "network_archetype_primary"
```

``` r
# Select key columns (adjust based on what's available)
top_betweenness <- nodes_with_centrality %>%
  arrange(desc(betweenness)) %>%
  select(name, group, betweenness, degree, closeness, pagerank) %>%
  head(10)

print(top_betweenness)
```

```
##            name group betweenness degree closeness    pagerank
## Node022 Node022     A    885.2031     38 0.3256579 0.014637665
## Node019 Node019     A    760.0520     31 0.3132911 0.008917373
## Node059 Node059     B    742.3520     33 0.3367347 0.010446325
## Node017 Node017     A    640.3877     35 0.3498233 0.010431312
## Node049 Node049     A    547.7747     29 0.3256579 0.012815892
## Node057 Node057     A    537.0653     38 0.3162939 0.012631555
## Node002 Node002     A    520.8330     37 0.3193548 0.010569162
## Node032 Node032     C    498.2610     23 0.3289037 0.008859281
## Node018 Node018     B    497.7347     37 0.3142857 0.011451261
## Node062 Node062     B    472.4446     35 0.3055556 0.009712116
```

---

# 4. Visualization

## 4.1 Basic Network Plot


``` r
# Plot network with group-based coloring
plot_network(
  g, 
  group_var = "group",
  min_size = 3,
  max_size = 12,
  show_labels = FALSE
)
title("Synthetic Network Colored by Group")
```

![plot of chunk plot-network](figure/plot-network-1.png)

## 4.2 Community Detection

Detect and visualize communities using multiple algorithms.


``` r
# Detect communities using multiple algorithms
plot_communities(
  g_zachary,
  algorithms = c("walktrap", "louvain", "fastgreedy"),
  min_size = 3,
  max_size = 15
)
```

```
## Running walktrap algorithm...
## walktrap modularity: 0.353221564760026
```

![plot of chunk plot-communities](figure/plot-communities-1.png)

```
## Running fastgreedy algorithm...
## fastgreedy modularity: 0.380670611439842
```

![plot of chunk plot-communities](figure/plot-communities-2.png)

```
##         Node walktrap fastgreedy
## 1   Member_1        1          1
## 2   Member_2        1          3
## 3   Member_3        2          3
## 4   Member_4        1          3
## 5   Member_5        5          1
## 6   Member_6        5          1
## 7   Member_7        5          1
## 8   Member_8        1          3
## 9   Member_9        2          2
## 10 Member_10        2          3
## 11 Member_11        5          1
## 12 Member_12        1          1
## 13 Member_13        1          3
## 14 Member_14        2          3
## 15 Member_15        3          2
## 16 Member_16        3          2
## 17 Member_17        5          1
## 18 Member_18        1          3
## 19 Member_19        3          2
## 20 Member_20        1          1
## 21 Member_21        3          2
## 22 Member_22        1          3
## 23 Member_23        3          2
## 24 Member_24        4          2
## 25 Member_25        4          2
## 26 Member_26        4          2
## 27 Member_27        3          2
## 28 Member_28        4          2
## 29 Member_29        2          2
## 30 Member_30        3          2
## 31 Member_31        2          2
## 32 Member_32        2          2
## 33 Member_33        3          2
## 34 Member_34        3          2
```

---

# 5. Connection Analysis

## 5.1 Specific Connections by Attribute

Count connections based on node attributes.


``` r
# Count connections by group
group_connections <- calculate_specific_connections(
  g,
  attr_vars = "group",
  weight_var = "weight",
  same_diff = FALSE,
  return_graph = FALSE
)

# View connections for first few nodes
group_connections %>%
  select(name, starts_with("group_")) %>%
  head(5)
```

```
##            name group_A_incoming_n group_A_incoming_f group_B_incoming_n
## Node001 Node001                  4                 21                  5
## Node002 Node002                 11                 46                  5
## Node003 Node003                  8                 45                  2
## Node004 Node004                  7                 45                  8
## Node005 Node005                  8                 40                  9
##         group_B_incoming_f group_C_incoming_n group_C_incoming_f
## Node001                 24                  1                  2
## Node002                 35                  1                  2
## Node003                  6                  3                 22
## Node004                 47                  5                 24
## Node005                 66                  6                 28
##         group_D_incoming_n group_D_incoming_f group_A_outgoing_n
## Node001                  1                  5                  6
## Node002                  0                  0                  5
## Node003                  1                  8                  3
## Node004                  0                  0                  7
## Node005                  2                  5                  6
##         group_A_outgoing_f group_B_outgoing_n group_B_outgoing_f
## Node001                 35                  7                 35
## Node002                 24                  5                 39
## Node003                 12                  6                 45
## Node004                 42                  8                 44
## Node005                 17                  1                  9
##         group_C_outgoing_n group_C_outgoing_f group_D_outgoing_n
## Node001                  1                 10                  1
## Node002                  7                 30                  3
## Node003                  1                  1                  2
## Node004                  2                 17                  3
## Node005                  2                 18                  0
##         group_D_outgoing_f group_A_total_n group_A_total_f group_B_total_n
## Node001                  7               9              56              12
## Node002                 15              13              70               8
## Node003                  3              11              57               8
## Node004                 10              13              87              15
## Node005                  0              13              57              10
##         group_B_total_f group_C_total_n group_C_total_f group_D_total_n
## Node001              59               2              12               2
## Node002              74               8              32               3
## Node003              51               4              23               3
## Node004              91               7              41               3
## Node005              75               8              46               2
##         group_D_total_f
## Node001              12
## Node002              15
## Node003              11
## Node004              10
## Node005               5
```

## 5.2 Same vs Different Connections


``` r
# Count same vs different group connections
same_diff <- calculate_specific_connections(
  g,
  attr_vars = "group",
  weight_var = "weight",
  same_diff = TRUE,
  return_graph = FALSE
)

# Summary statistics
same_diff %>%
  select(name, group, contains("same"), contains("diff")) %>%
  head(5)
```

```
##            name group group_incoming_same_n group_incoming_same_f
## Node001 Node001     B                     5                    24
## Node002 Node002     A                    11                    46
## Node003 Node003     A                     8                    45
## Node004 Node004     D                     0                     0
## Node005 Node005     B                     9                    66
##         group_outgoing_same_n group_outgoing_same_f group_incoming_diff_n
## Node001                     7                    35                     6
## Node002                     5                    24                     6
## Node003                     3                    12                     6
## Node004                     3                    10                    20
## Node005                     1                     9                    16
##         group_incoming_diff_f group_outgoing_diff_n group_outgoing_diff_f
## Node001                    28                     8                    52
## Node002                    37                    15                    84
## Node003                    36                     9                    49
## Node004                   116                    17                   103
## Node005                    73                     8                    35
```

---

# 6. Neighbor Analysis

## 6.1 Detailed Neighbor Information


``` r
# Get detailed neighbor information for group A nodes
neighbor_info <- run_neighbors(
  graph = g,
  attribute_name = "group",
  group_value = "A",
  attribute_to_analyze = "gender"
)

# View neighbor summary
head(neighbor_info, 10)
```

```
## # A tibble: 2 × 13
##   Attribute incoming_n incoming_weight incoming_n_percent incoming_weight_perc…¹
##   <chr>          <int>           <int>              <dbl>                  <dbl>
## 1 F                138             768              0.375                  0.377
## 2 M                230            1269              0.625                  0.623
## # ℹ abbreviated name: ¹​incoming_weight_percent
## # ℹ 8 more variables: outgoing_n <int>, outgoing_weight <int>,
## #   outgoing_n_percent <dbl>, outgoing_weight_percent <dbl>, all_n <dbl>,
## #   all_weight <dbl>, all_n_percent <dbl>, all_weight_percent <dbl>
```

---

# 7. Community Structure

## 7.1 K-Core Decomposition


``` r
# Find k-core structure
kcore_result <- run_kcore(g_zachary)

# View k-core distribution
table(kcore_result$coreness)
```

```
## 
##  1  2  3  4 
##  1 11 12 10
```

``` r
# Top nodes by coreness
kcore_result %>%
  arrange(desc(coreness)) %>%
  head(10)
```

```
##           node coreness max_core      name
## Member_1     1        4     TRUE  Member_1
## Member_2     2        4     TRUE  Member_2
## Member_3     3        4     TRUE  Member_3
## Member_4     4        4     TRUE  Member_4
## Member_8     8        4     TRUE  Member_8
## Member_9     9        4     TRUE  Member_9
## Member_14   14        4     TRUE Member_14
## Member_31   31        4     TRUE Member_31
## Member_33   33        4     TRUE Member_33
## Member_34   34        4     TRUE Member_34
```

## 7.2 Clique Analysis


``` r
# Find cliques in the network
clique_result <- run_cliques(g_zachary)

cat("Number of nodes analyzed:", nrow(clique_result), "\n")
```

```
## Number of nodes analyzed: 34
```

``` r
cat("Nodes in largest clique:", sum(clique_result$in_largest_clique), "\n\n")
```

```
## Nodes in largest clique: 6
```

``` r
# View top nodes by clique membership
clique_result %>%
  arrange(desc(clique_count)) %>%
  head(10)
```

```
##    node clique_count in_largest_clique      name
## 1     1           43              TRUE  Member_1
## 2    34           34             FALSE Member_34
## 3     2           30              TRUE  Member_2
## 4     3           30              TRUE  Member_3
## 5    33           27             FALSE Member_33
## 6     4           25              TRUE  Member_4
## 7    14           16              TRUE Member_14
## 8     8           15              TRUE  Member_8
## 9     9           11             FALSE  Member_9
## 10   24           10             FALSE Member_24
```

---

# 8. Influence and Diffusion

## 8.1 DeGroot Opinion Dynamics

Simulate opinion convergence using the DeGroot model.


``` r
# Run DeGroot model on multiple attributes
degroot_result <- run_degroot(
  g,
  attribute_names = c("psych_safety", "innovation"),
  self_weight = 0.3,
  max_iter = 100,
  tol = 1e-6
)

# View convergence summary
degroot_result$attribute_summary
```

```
##      attribute initial_mean mean_final_opinion sd_final_opinion
## 1 psych_safety    0.6695575          0.6728560     1.563139e-07
## 2   innovation    0.3215536          0.3219465     2.400414e-07
##   shift_from_initial_mean iterations_to_converge
## 1            0.0032985269                     17
## 2            0.0003928785                     16
```

``` r
# View final opinions for top nodes
degroot_result$node_level %>%
  filter(attribute == "innovation") %>%
  arrange(desc(final_opinion)) %>%
  head(10)
```

```
##       node  attribute final_opinion
## 1  Node012 innovation     0.3219470
## 2  Node053 innovation     0.3219470
## 3  Node099 innovation     0.3219470
## 4  Node031 innovation     0.3219470
## 5  Node079 innovation     0.3219470
## 6  Node057 innovation     0.3219469
## 7  Node006 innovation     0.3219469
## 8  Node064 innovation     0.3219469
## 9  Node019 innovation     0.3219469
## 10 Node001 innovation     0.3219468
```

## 8.2 Network Oscillation Metrics

Calculate oscillation metrics for longitudinal data.


``` r
# Create synthetic longitudinal data
set.seed(456)
longitudinal_data <- data.frame(
  name = rep(paste0("Node", sprintf("%03d", 1:20)), each = 10),
  time = rep(1:10, 20),
  metric1 = rnorm(200, mean = 0.5, sd = 0.2),
  metric2 = rnorm(200, mean = 0.6, sd = 0.15)
)

# Calculate oscillation metrics
oscillation_result <- calculate_oscillation_metrics(
  longitudinal_data,
  variables = c("metric1", "metric2"),
  id_col = "name"
)

# View individual scores
head(oscillation_result$individual_scores, 5)
```

```
##      name metric1_Mean metric1_SD metric1_Range metric1_Peaks_Valleys
## 1 Node001    0.5034719  0.1795984     0.4792489                     5
## 2 Node002    0.6897366  0.2482794     0.7441678                     7
## 3 Node003    0.4458373  0.2057049     0.6403697                     6
## 4 Node004    0.4579472  0.1913288     0.7629136                     7
## 5 Node005    0.5503900  0.1644107     0.6508554                     6
##   metric1_Oscillation_Score metric2_Mean metric2_SD metric2_Range
## 1                  1.625719    0.6014479 0.09075660     0.3187240
## 2                  2.273796    0.6862211 0.08746044     0.2894565
## 3                  1.943993    0.5918930 0.16870867     0.4692508
## 4                  2.233930    0.6480724 0.15782972     0.4811881
## 5                  1.915088    0.5866981 0.17752854     0.5530278
##   metric2_Peaks_Valleys metric2_Oscillation_Score
## 1                     6                  1.863530
## 2                     5                  1.561222
## 3                     5                  1.618096
## 4                     6                  1.910481
## 5                     5                  1.624270
```

``` r
# View averages
oscillation_result$averages
```

```
##      name metric1_Mean metric1_SD metric1_Range metric1_Peaks_Valleys
## 1 AVERAGE    0.5003866  0.1937453     0.6059354                   5.8
##   metric1_Oscillation_Score metric2_Mean metric2_SD metric2_Range
## 1                  1.875622    0.6175463  0.1335947     0.4201892
##   metric2_Peaks_Valleys metric2_Oscillation_Score
## 1                  5.55                  1.758516
```

---

# 9. Link Prediction

## 9.1 Predict Missing Links


``` r
# Predict potential new connections
link_predictions <- run_link_prediction(
  g_zachary,
  group_var = "group",
  top_n = 20
)

# View top predictions
head(link_predictions, 10)
```

```
##         from        to score from_group to_group
## 1  Member_15 Member_16     1          C        C
## 2  Member_15 Member_19     1          C        A
## 3  Member_15 Member_21     1          C        B
## 4  Member_15 Member_23     1          C        B
## 5  Member_16 Member_19     1          C        A
## 6  Member_16 Member_21     1          C        B
## 7  Member_16 Member_23     1          C        B
## 8  Member_18 Member_22     1          A        A
## 9  Member_19 Member_21     1          A        B
## 10 Member_19 Member_23     1          A        B
```

## 9.2 Connection Recommendations


``` r
# Add cross-community connection recommendations
g_zachary_rec <- add_recommendations_to_graph(
  g_zachary,
  attribute_filter = "group",
  same_value = FALSE,  # Recommend different groups
  max_recommendations = 2,
  community_method = "louvain"
)

# View recommendations
rec_df <- pull_data(g_zachary_rec, what = "nodes")
rec_df %>%
  select(name, group, recommended_connection) %>%
  filter(!is.na(recommended_connection)) %>%
  head(10)
```

```
##                name group recommended_connection
## Member_1   Member_1     C              Member_19
## Member_2   Member_2     B              Member_15
## Member_3   Member_3     A              Member_27
## Member_4   Member_4     A              Member_15
## Member_5   Member_5     B              Member_16
## Member_6   Member_6     C              Member_19
## Member_7   Member_7     A              Member_16
## Member_8   Member_8     B              Member_17
## Member_9   Member_9     C              Member_17
## Member_10 Member_10     B               Member_6
```

---

# 10. Advanced Analysis

## 10.1 Mixing Matrix

Analyze homophily and mixing patterns.


``` r
# Create mixing matrix for group attribute
mixing_result <- run_mixing_matrix(
  g, 
  number = 5,  # Top 5 categories
  attribute_name = "group"
)
```

```
## [1] "Assortativity Coefficient: 0.00178258109344312"
## [1] "Top Categories:"
## [1] "A" "B" "C" "D"
## [1] "Mixing Matrix:"
##     A   B   C  D
## A 235 191 111 50
## B 186 168  85 41
## C 132  90  52 19
## D  50  41  18  8
```

``` r
print(mixing_result)
```

```
##     A   B   C  D
## A 235 191 111 50
## B 186 168  85 41
## C 132  90  52 19
## D  50  41  18  8
```

## 10.2 Node Removal Impact

Assess network robustness by simulating node removal.


``` r
# Identify high-degree nodes to remove
node_degrees <- data.frame(
  name = V(g_zachary)$name,
  degree = degree(g_zachary)
) %>%
  arrange(desc(degree))

# Remove top 20% of nodes by degree
nodes_to_remove <- head(node_degrees$name, ceiling(0.2 * vcount(g_zachary)))

# Analyze impact of removing high-degree nodes
removal_impact <- run_node_removal_impact(
  g_zachary,
  nodes_to_remove = nodes_to_remove
)

# View impact summary
removal_impact$changes %>%
  filter(metric %in% c("density", "clustering_coefficient", "diameter", 
                       "num_components", "avg_path_length")) %>%
  select(metric, Before, After, absolute_change, percent_change)
```

```
## # A tibble: 5 × 5
##   metric                 Before   After absolute_change percent_change
##   <chr>                   <dbl>   <dbl>           <dbl>          <dbl>
## 1 density                 0.139  0.0370         -0.102           -73.4
## 2 diameter                5      4              -1               -20  
## 3 avg_path_length         2.41   1.69           -0.716           -29.7
## 4 clustering_coefficient  0.256  0.188          -0.0682          -26.7
## 5 num_components          1     17              16              1600
```

## 10.3 Best Friend Analysis

Find the strongest connection for each node.


``` r
# Find best friend (strongest connection) for each node
g_with_best_friends <- run_find_best_friend(g)

# Extract and view results
best_friends <- pull_data(g_with_best_friends, what = "nodes") %>%
  select(name, group, best_friend, friend_weight) %>%
  arrange(desc(friend_weight))

head(best_friends, 10)
```

```
##            name group best_friend friend_weight
## Node001 Node001     B     Node022            10
## Node002 Node002     A     Node022            10
## Node004 Node004     D     Node023            10
## Node005 Node005     B     Node088            10
## Node006 Node006     B     Node004            10
## Node007 Node007     A     Node001            10
## Node008 Node008     A     Node015            10
## Node009 Node009     B     Node034            10
## Node010 Node010     A     Node022            10
## Node011 Node011     B     Node020            10
```

---

# 11. Diagnostic Tools

## 11.1 Check Edge-Node Mismatches


``` r
# Check for data quality issues
mismatch_check <- check_edge_node_mismatches(
  edges = edges_df,
  nodes = nodes_df
)

cat("Edges with missing 'from' nodes:", nrow(mismatch_check$missing_from), "\n")
```

```
## Edges with missing 'from' nodes:
```

``` r
cat("Edges with missing 'to' nodes:", nrow(mismatch_check$missing_to), "\n")
```

```
## Edges with missing 'to' nodes:
```

``` r
cat("Orphan nodes (no connections):", nrow(mismatch_check$orphan_nodes), "\n")
```

```
## Orphan nodes (no connections):
```

---

# Summary

The `hineycombs` package provides a rich set of tools for:

1. **Network Creation**: Generate synthetic networks with realistic attributes
2. **Metrics & Centrality**: Calculate comprehensive network and node-level metrics
3. **Visualization**: Plot networks with customizable layouts and community detection
4. **Connection Analysis**: Analyze patterns of connections based on attributes
5. **Diffusion Models**: Simulate opinion dynamics and information spread
6. **Link Prediction**: Identify potential new connections and recommendations
7. **Diagnostics**: Check data quality and network robustness

This toolkit is ideal for organizational network analysis, social network research, and exploratory network data analysis.

---

# Session Info


``` r
sessionInfo()
```

```
## R version 4.5.1 (2025-06-13)
## Platform: aarch64-apple-darwin20
## Running under: macOS Tahoe 26.2
## 
## Matrix products: default
## BLAS:   /Library/Frameworks/R.framework/Versions/4.5-arm64/Resources/lib/libRblas.0.dylib 
## LAPACK: /Library/Frameworks/R.framework/Versions/4.5-arm64/Resources/lib/libRlapack.dylib;  LAPACK version 3.12.1
## 
## locale:
## [1] en_US.UTF-8/en_US.UTF-8/en_US.UTF-8/C/en_US.UTF-8/en_US.UTF-8
## 
## time zone: America/Los_Angeles
## tzcode source: internal
## 
## attached base packages:
## [1] stats     graphics  grDevices utils     datasets  methods   base     
## 
## other attached packages:
## [1] dplyr_1.1.4           igraph_2.1.4          hineycombs_0.20260129
## 
## loaded via a namespace (and not attached):
##  [1] stringdist_0.9.15   gtable_0.3.6        xfun_0.53          
##  [4] ggplot2_4.0.0       htmlwidgets_1.6.4   psych_2.5.6        
##  [7] lattice_0.22-7      influenceR_0.1.5    quadprog_1.5-8     
## [10] vctrs_0.6.5         tools_4.5.1         generics_0.1.4     
## [13] stats4_4.5.1        signnet_1.0.5       parallel_4.5.1     
## [16] tibble_3.3.0        cluster_2.1.8.1     pkgconfig_2.0.3    
## [19] blockmodeling_1.1.8 qgraph_1.9.8        Matrix_1.7-3       
## [22] data.table_1.17.8   checkmate_2.3.3     RColorBrewer_1.1-3 
## [25] S7_0.2.0            lifecycle_1.0.4     compiler_4.5.1     
## [28] farver_2.1.2        stringr_1.5.2       mnormt_2.1.1       
## [31] centiserve_1.0.0    janitor_2.2.1       snakecase_0.11.1   
## [34] htmltools_0.5.8.1   glasso_1.11         fdrtool_1.2.18     
## [37] yaml_2.3.10         htmlTable_2.4.3     Formula_1.2-5      
## [40] tidyr_1.3.1         pillar_1.11.1       Hmisc_5.2-3        
## [43] abind_1.4-8         rpart_4.1.24        nlme_3.1-168       
## [46] lavaan_0.6-20       gtools_3.9.5        tidyselect_1.2.1   
## [49] digest_0.6.37       stringi_1.8.7       purrr_1.1.0        
## [52] reshape2_1.4.4      fastmap_1.2.0       grid_4.5.1         
## [55] colorspace_2.1-2    cli_3.6.5           magrittr_2.0.4     
## [58] base64enc_0.1-3     utf8_1.2.6          pbivnorm_0.6.0     
## [61] withr_3.0.2         foreign_0.8-90      corpcor_1.6.10     
## [64] scales_1.4.0        backports_1.5.0     lubridate_1.9.4    
## [67] timechange_0.3.0    rmarkdown_2.30      jpeg_0.1-11        
## [70] nnet_7.3-20         gridExtra_2.3       png_0.1-8          
## [73] pbapply_1.7-4       evaluate_1.0.5      knitr_1.50         
## [76] rlang_1.1.6         Rcpp_1.1.0          glue_1.8.0         
## [79] rstudioapi_0.17.1   MetBrewer_0.2.0     R6_2.6.1           
## [82] plyr_1.8.9
```
