#' Compute team power rankings across an organization
#'
#' @description
#' Produces an SP+-style power ranking for every team/group in a network.
#' Each team is scored on three pillars:
#'
#' \itemize{
#'   \item \strong{Influence} — outward reach and connectivity
#'         (connectivity quality, eigenvector centrality, PageRank, 1-hop reach)
#'   \item \strong{Resilience} — structural robustness and cohesion
#'         (embeddedness, coreness, transitivity, density, inverse centralization)
#'   \item \strong{Agility} — brokerage and innovation positioning
#'         (brokerage capacity, structural autonomy, information access, innovation potential)
#' }
#'
#' The overall Power Rating = Influence + Resilience + Agility.
#' Each pillar is the mean of its z-scored components, scaled by 10.
#'
#' The function reads centrality metrics directly from vertex attributes on the
#' graph. If the required attributes are missing (e.g. \code{connectivity_quality_s}),
#' it will run \code{calculate_centrality_metrics(g)} automatically.
#'
#' @param g An igraph object. The full organizational graph (directed or undirected).
#'   Should ideally already have centrality metrics computed via
#'   \code{calculate_centrality_metrics()}, but the function will compute them
#'   if they are missing.
#' @param group_attr Character. Name of a vertex attribute that assigns each node
#'   to a team/group. Every unique non-NA value defines one team.
#'   Examples: \code{"group"}, \code{"department"}, \code{"organization_level_02_leader"}.
#' @param team_membership Optional named list as an alternative to \code{group_attr}.
#'   Each element is a character vector of vertex names belonging to that team.
#'   If provided, \code{group_attr} is ignored.
#' @param influence_cols Character vector. Vertex attribute names for the Influence pillar.
#'   Defaults to \code{c("connectivity_quality_s", "evcent_s", "pagerank_s", "reach_1")}.
#' @param resilience_cols Character vector. Vertex attribute names for the Resilience pillar.
#'   Defaults to \code{c("network_embeddedness_s", "coreness_s", "transitivity_s")}.
#'   Team-level density and inverse centralization are always appended automatically.
#' @param agility_cols Character vector. Vertex attribute names for the Agility pillar.
#'   Defaults to \code{c("brokerage_capacity_s", "structural_autonomy_s",
#'   "information_access_s", "innovation_potential_s")}.
#' @param verbose Logical. Print progress messages.
#'
#' @return A data.frame sorted by descending \code{power_rating}, with columns:
#'   \code{rank}, \code{team}, \code{team_size}, \code{power_rating},
#'   \code{influence}, \code{influence_rank}, \code{resilience}, \code{resilience_rank},
#'   \code{agility}, \code{agility_rank}, \code{density}, \code{centralization},
#'   \code{transitivity_graph}, \code{components}, plus the team-mean of every
#'   input metric column.
#'
#' @importFrom igraph is_igraph vcount V induced_subgraph edge_density
#' @importFrom igraph centr_degree transitivity components vertex_attr_names vertex_attr
#' @importFrom dplyr arrange desc
#' @importFrom stats sd setNames
#'
#' @examples
#' \dontrun{
#' # Typical usage: graph with a "group" vertex attribute
#' g <- create_network(edges, nodes)
#' g <- calculate_centrality_metrics(g)
#' pr <- run_insights_power_rankings(g, group_attr = "group")
#' head(pr)
#'
#' # Works without pre-computed metrics (will compute them automatically)
#' pr <- run_insights_power_rankings(g, group_attr = "department")
#'
#' # Using explicit team membership instead of a vertex attribute
#' teams <- list(
#'   "Team Alpha" = c("Alice", "Bob", "Carol"),
#'   "Team Beta"  = c("Dave", "Eve", "Frank")
#' )
#' pr <- run_insights_power_rankings(g, team_membership = teams)
#' }
#'
#' @export
run_insights_power_rankings <- function(
    g,
    group_attr       = NULL,
    team_membership  = NULL,
    influence_cols   = c("connectivity_quality_s", "evcent_s", "pagerank_s", "reach_1"),
    resilience_cols  = c("network_embeddedness_s", "coreness_s", "transitivity_s"),
    agility_cols     = c("brokerage_capacity_s", "structural_autonomy_s",
                         "information_access_s", "innovation_potential_s"),
    verbose          = FALSE
) {
  # ── Validation ──────────────────────────────────────────────────────────────
  if (!igraph::is_igraph(g)) stop("g must be an igraph object.")
  if (is.null(group_attr) && is.null(team_membership)) {
    stop("Provide either group_attr (vertex attribute name) or team_membership (named list).")
  }

  # ── Auto-compute centrality metrics if missing ────────────────────────────
  all_needed <- unique(c(influence_cols, resilience_cols, agility_cols))
  v_attrs <- igraph::vertex_attr_names(g)
  missing_attrs <- setdiff(all_needed, v_attrs)

  if (length(missing_attrs) > 0) {
    if (verbose) cat("Missing vertex attributes:", paste(missing_attrs, collapse = ", "), "\n")
    if (verbose) cat("Running calculate_centrality_metrics()...\n")
    g <- calculate_centrality_metrics(g, include_advanced_metrics = FALSE)
    v_attrs <- igraph::vertex_attr_names(g)
  }

  # ── Build team membership map ─────────────────────────────────────────────
  vnames <- igraph::V(g)$name
  if (is.null(vnames)) vnames <- as.character(seq_len(igraph::vcount(g)))

  if (!is.null(team_membership)) {
    if (!is.list(team_membership) || is.null(names(team_membership))) {
      stop("team_membership must be a named list of character vectors.")
    }
    teams <- team_membership
  } else {
    if (!group_attr %in% v_attrs) {
      stop("group_attr '", group_attr, "' not found in vertex attributes. Available: ",
           paste(head(v_attrs, 15), collapse = ", "))
    }
    grp_vals <- igraph::vertex_attr(g, group_attr)
    unique_teams <- unique(grp_vals[!is.na(grp_vals) & nchar(trimws(grp_vals)) > 0])
    teams <- stats::setNames(
      lapply(unique_teams, function(t) vnames[!is.na(grp_vals) & grp_vals == t]),
      unique_teams
    )
  }

  if (length(teams) < 2) {
    warning("Fewer than 2 teams found. Rankings require at least 2 teams for meaningful comparison.")
  }
  if (verbose) cat("Found", length(teams), "teams\n")

  # ── Identify available metric columns ─────────────────────────────────────
  inf_ok <- influence_cols[influence_cols %in% v_attrs]
  res_ok <- resilience_cols[resilience_cols %in% v_attrs]
  agi_ok <- agility_cols[agility_cols %in% v_attrs]
  all_metric_cols <- unique(c(inf_ok, res_ok, agi_ok))

  if (length(all_metric_cols) == 0) {
    stop("None of the requested metric columns found as vertex attributes. Available: ",
         paste(head(v_attrs, 20), collapse = ", "))
  }
  if (verbose) {
    cat("  Influence cols:", length(inf_ok), "/", length(influence_cols), "\n")
    cat("  Resilience cols:", length(res_ok), "/", length(resilience_cols), "\n")
    cat("  Agility cols:", length(agi_ok), "/", length(agility_cols), "\n")
  }

  # ── Helper: safe z-score ──────────────────────────────────────────────────
  safe_z <- function(x) {
    mu <- mean(x, na.rm = TRUE)
    s  <- stats::sd(x, na.rm = TRUE)
    if (is.na(s) || s == 0) return(rep(0, length(x)))
    (x - mu) / s
  }

  # ── Build one row per team ────────────────────────────────────────────────
  build_row <- function(team_name, members) {
    vids <- which(vnames %in% members)
    if (length(vids) == 0) return(NULL)

    # Team-mean of each metric from vertex attributes
    means <- vapply(all_metric_cols, function(col) {
      vals <- igraph::vertex_attr(g, col)[vids]
      mean(as.numeric(vals), na.rm = TRUE)
    }, numeric(1))
    names(means) <- paste0("mean_", all_metric_cols)

    # Subgraph stats
    g_sub <- igraph::induced_subgraph(g, vids = vids)
    n     <- igraph::vcount(g_sub)

    dens  <- if (n > 1) igraph::edge_density(g_sub) else NA_real_
    cent  <- if (n > 1) igraph::centr_degree(g_sub)$centralization else NA_real_
    tran  <- if (n > 1) igraph::transitivity(g_sub, type = "global") else NA_real_
    ncomp <- igraph::components(g_sub)$no

    c(team = team_name, team_size = length(vids),
      density = round(dens, 4), centralization = round(cent, 4),
      transitivity_graph = round(tran, 4), components = ncomp,
      means)
  }

  if (verbose) cat("Computing team metrics...\n")
  rows <- lapply(names(teams), function(tn) build_row(tn, teams[[tn]]))
  rows <- rows[!vapply(rows, is.null, logical(1))]

  if (length(rows) == 0) stop("No valid teams could be built.")

  result <- as.data.frame(do.call(rbind, rows), stringsAsFactors = FALSE)
  # Convert numeric columns
  num_cols <- setdiff(colnames(result), "team")
  for (col in num_cols) result[[col]] <- as.numeric(result[[col]])

  # ── Compute pillar scores ─────────────────────────────────────────────────
  mean_inf <- paste0("mean_", inf_ok)
  mean_res <- paste0("mean_", res_ok)
  mean_agi <- paste0("mean_", agi_ok)

  # Influence
  if (length(mean_inf) > 0) {
    inf_mat <- sapply(mean_inf, function(c) safe_z(result[[c]]))
    result$influence <- round(rowMeans(inf_mat, na.rm = TRUE) * 10, 1)
  } else {
    result$influence <- 0
  }

  # Resilience (node metrics + team-level density + inverse centralization)
  if (length(mean_res) > 0) {
    res_mat <- sapply(mean_res, function(c) safe_z(result[[c]]))
    if ("density" %in% colnames(result)) {
      res_mat <- cbind(res_mat, safe_z(result$density))
    }
    if ("centralization" %in% colnames(result)) {
      res_mat <- cbind(res_mat, safe_z(-result$centralization))
    }
    result$resilience <- round(rowMeans(res_mat, na.rm = TRUE) * 10, 1)
  } else {
    result$resilience <- 0
  }

  # Agility
  if (length(mean_agi) > 0) {
    agi_mat <- sapply(mean_agi, function(c) safe_z(result[[c]]))
    result$agility <- round(rowMeans(agi_mat, na.rm = TRUE) * 10, 1)
  } else {
    result$agility <- 0
  }

  # ── Overall rating and ranks ──────────────────────────────────────────────
  result$power_rating <- round(result$influence + result$resilience + result$agility, 1)
  result <- dplyr::arrange(result, dplyr::desc(.data$power_rating))
  result$rank <- seq_len(nrow(result))

  result$influence_rank  <- rank(-result$influence, ties.method = "min")
  result$resilience_rank <- rank(-result$resilience, ties.method = "min")
  result$agility_rank    <- rank(-result$agility, ties.method = "min")

  # ── Reorder columns for readability ───────────────────────────────────────
  front <- c("rank", "team", "team_size", "power_rating",
             "influence", "influence_rank",
             "resilience", "resilience_rank",
             "agility", "agility_rank",
             "density", "centralization", "transitivity_graph", "components")
  rest <- setdiff(colnames(result), front)
  result <- result[, c(front, rest), drop = FALSE]

  if (verbose) cat("Done. #1:", result$team[1], "(", result$power_rating[1], ")\n")

  result
}
