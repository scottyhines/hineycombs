#' Calculate network stability over time
#'
#' @description
#' Analyzes how a network changes over time by comparing snapshots at different
#' time points. Measures stability, turnover, and structural persistence.
#'
#' Practical uses:
#' \itemize{
#'   \item Track relationship stability (which connections persist?)
#'   \item Measure organizational churn (how much turnover?)
#'   \item Identify stable vs volatile network regions
#'   \item Assess impact of interventions or changes
#'   \item Predict future network structure
#' }
#'
#' @param graph_list List of igraph objects representing network at different time points.
#'   Must be in chronological order. All graphs must have \code{name} vertex attribute.
#' @param time_labels Optional character vector of time period labels (e.g., "Q1 2024").
#'   If NULL, uses "T1", "T2", etc.
#' @param weight_var Optional edge attribute name for weights.
#' @param node_stability Logical. Calculate node-level stability metrics? Default TRUE.
#' @param structural_stability Logical. Calculate structural metrics over time? Default TRUE.
#'
#' @return A list containing:
#' \describe{
#'   \item{overall_stability}{Summary stability metrics across all time points}
#'   \item{pairwise_stability}{Stability between consecutive time points}
#'   \item{node_stability}{Node-level persistence and volatility}
#'   \item{edge_stability}{Edge formation, persistence, and dissolution}
#'   \item{structural_trends}{Changes in network structure over time}
#'   \item{interpretation}{Plain English interpretation}
#' }
#'
#' @details
#' Stability metrics:
#'
#' \strong{Jaccard Similarity (0-1):} Proportion of nodes/edges that remain the same.
#' 1 = identical networks, 0 = completely different.
#'
#' \strong{Node Stability:} Proportion of nodes present in both time points.
#' Measures roster turnover.
#'
#' \strong{Edge Stability:} Proportion of edges that persist between time points.
#' Measures relationship stability.
#'
#' \strong{Structural Stability:} How much do network properties (density, centralization,
#' clustering) change over time?
#'
#' \strong{Tie Formation Rate:} New edges / possible new edges
#'
#' \strong{Tie Dissolution Rate:} Lost edges / existing edges
#'
#' \strong{Tie Persistence Rate:} Continuing edges / existing edges
#'
#' Node-level metrics:
#' \itemize{
#'   \item Persistence: How many time points does each node appear in?
#'   \item Volatility: How much does each node's degree change?
#'   \item Stability score: Composite measure of node consistency
#' }
#'
#' @examples
#' \dontrun{
#' # Compare quarterly networks
#' graphs <- list(g_q1, g_q2, g_q3, g_q4)
#' stability <- calculate_temporal_stability(
#'   graphs,
#'   time_labels = c("Q1", "Q2", "Q3", "Q4")
#' )
#' print(stability$interpretation)
#'
#' # Identify stable vs volatile nodes
#' print(stability$node_stability)
#' }
#'
#' @importFrom igraph vcount ecount V E intersection union
#' @importFrom dplyr group_by summarise arrange desc
#' @importFrom tibble tibble
#'
#' @export
calculate_temporal_stability <- function(graph_list,
                                        time_labels = NULL,
                                        weight_var = NULL,
                                        node_stability = TRUE,
                                        structural_stability = TRUE) {
  
  if (!is.list(graph_list) || length(graph_list) < 2) {
    stop("graph_list must be a list of at least 2 igraph objects.")
  }
  
  if (!all(sapply(graph_list, inherits, "igraph"))) {
    stop("All elements in graph_list must be igraph objects.")
  }
  
  n_timepoints <- length(graph_list)
  
  if (is.null(time_labels)) {
    time_labels <- paste0("T", 1:n_timepoints)
  } else if (length(time_labels) != n_timepoints) {
    stop("time_labels must have same length as graph_list.")
  }
  
  cat("Analyzing temporal stability across", n_timepoints, "time points...\n")
  
  # === PAIRWISE STABILITY ===
  
  cat("Calculating pairwise stability...\n")
  
  pairwise_results <- list()
  
  for (i in 1:(n_timepoints - 1)) {
    g1 <- graph_list[[i]]
    g2 <- graph_list[[i + 1]]
    
    pairwise_results[[i]] <- calculate_pairwise_stability(
      g1, g2, time_labels[i], time_labels[i + 1], weight_var
    )
  }
  
  pairwise_stability <- do.call(rbind, pairwise_results)
  
  # === OVERALL STABILITY ===
  
  overall_stability <- list(
    avg_node_jaccard = mean(pairwise_stability$node_jaccard),
    avg_edge_jaccard = mean(pairwise_stability$edge_jaccard),
    avg_formation_rate = mean(pairwise_stability$formation_rate),
    avg_dissolution_rate = mean(pairwise_stability$dissolution_rate),
    avg_persistence_rate = mean(pairwise_stability$persistence_rate),
    total_unique_nodes = length(unique(unlist(lapply(graph_list, function(g) igraph::V(g)$name)))),
    avg_nodes_per_period = mean(sapply(graph_list, igraph::vcount)),
    avg_edges_per_period = mean(sapply(graph_list, igraph::ecount))
  )
  
  # === NODE-LEVEL STABILITY ===
  
  node_stability_df <- NULL
  if (node_stability) {
    cat("Calculating node-level stability...\n")
    node_stability_df <- calculate_node_level_stability(graph_list, time_labels)
  }
  
  # === EDGE STABILITY ===
  
  edge_stability_df <- calculate_edge_level_stability(graph_list, time_labels)
  
  # === STRUCTURAL TRENDS ===
  
  structural_trends <- NULL
  if (structural_stability) {
    cat("Calculating structural trends...\n")
    structural_trends <- calculate_structural_trends(graph_list, time_labels)
  }
  
  # === INTERPRETATION ===
  
  interpretation <- interpret_temporal_stability(
    overall_stability, pairwise_stability, node_stability_df, structural_trends
  )
  
  output <- list(
    overall_stability = overall_stability,
    pairwise_stability = pairwise_stability,
    node_stability = node_stability_df,
    edge_stability = edge_stability_df,
    structural_trends = structural_trends,
    interpretation = interpretation,
    n_timepoints = n_timepoints,
    time_labels = time_labels
  )
  
  class(output) <- c("temporal_stability", "list")
  return(output)
}

# Helper: Calculate pairwise stability
calculate_pairwise_stability <- function(g1, g2, label1, label2, weight_var) {
  
  # Node stability
  nodes1 <- igraph::V(g1)$name
  nodes2 <- igraph::V(g2)$name
  
  nodes_both <- intersect(nodes1, nodes2)
  nodes_union <- union(nodes1, nodes2)
  
  node_jaccard <- length(nodes_both) / length(nodes_union)
  nodes_added <- length(setdiff(nodes2, nodes1))
  nodes_lost <- length(setdiff(nodes1, nodes2))
  nodes_stable <- length(nodes_both)
  
  # Edge stability (only among stable nodes)
  g1_stable <- igraph::induced_subgraph(g1, nodes_both)
  g2_stable <- igraph::induced_subgraph(g2, nodes_both)
  
  edges1 <- igraph::as_data_frame(g1_stable, what = "edges")
  edges2 <- igraph::as_data_frame(g2_stable, what = "edges")
  
  # Create edge identifiers
  edges1$edge_id <- paste(pmin(edges1$from, edges1$to), 
                          pmax(edges1$from, edges1$to), sep = "-")
  edges2$edge_id <- paste(pmin(edges2$from, edges2$to), 
                          pmax(edges2$from, edges2$to), sep = "-")
  
  edges_both <- intersect(edges1$edge_id, edges2$edge_id)
  edges_union <- union(edges1$edge_id, edges2$edge_id)
  
  edge_jaccard <- if (length(edges_union) > 0) {
    length(edges_both) / length(edges_union)
  } else {
    0
  }
  
  edges_added <- length(setdiff(edges2$edge_id, edges1$edge_id))
  edges_lost <- length(setdiff(edges1$edge_id, edges2$edge_id))
  edges_stable <- length(edges_both)
  
  # Rates
  formation_rate <- if (nrow(edges1) > 0) edges_added / nrow(edges1) else 0
  dissolution_rate <- if (nrow(edges1) > 0) edges_lost / nrow(edges1) else 0
  persistence_rate <- if (nrow(edges1) > 0) edges_stable / nrow(edges1) else 0
  
  tibble::tibble(
    from_period = label1,
    to_period = label2,
    node_jaccard = node_jaccard,
    edge_jaccard = edge_jaccard,
    nodes_stable = nodes_stable,
    nodes_added = nodes_added,
    nodes_lost = nodes_lost,
    edges_stable = edges_stable,
    edges_added = edges_added,
    edges_lost = edges_lost,
    formation_rate = formation_rate,
    dissolution_rate = dissolution_rate,
    persistence_rate = persistence_rate
  )
}

# Helper: Node-level stability
calculate_node_level_stability <- function(graph_list, time_labels) {
  
  all_nodes <- unique(unlist(lapply(graph_list, function(g) igraph::V(g)$name)))
  n_timepoints <- length(graph_list)
  
  node_stats <- lapply(all_nodes, function(node) {
    # Count appearances
    appearances <- sum(sapply(graph_list, function(g) node %in% igraph::V(g)$name))
    
    # Track degree over time
    degrees <- sapply(graph_list, function(g) {
      if (node %in% igraph::V(g)$name) {
        igraph::degree(g, v = node)
      } else {
        NA
      }
    })
    
    # Volatility (coefficient of variation of degree)
    valid_degrees <- degrees[!is.na(degrees)]
    volatility <- if (length(valid_degrees) > 1 && mean(valid_degrees) > 0) {
      sd(valid_degrees) / mean(valid_degrees)
    } else {
      0
    }
    
    tibble::tibble(
      node = node,
      appearances = appearances,
      persistence_rate = appearances / n_timepoints,
      avg_degree = mean(valid_degrees, na.rm = TRUE),
      degree_volatility = volatility,
      first_seen = time_labels[which(!is.na(degrees))[1]],
      last_seen = time_labels[max(which(!is.na(degrees)))]
    )
  })
  
  result <- do.call(rbind, node_stats)
  dplyr::arrange(result, dplyr::desc(persistence_rate), dplyr::desc(avg_degree))
}

# Helper: Edge-level stability
calculate_edge_level_stability <- function(graph_list, time_labels) {
  
  # Track all unique edges across time
  all_edges <- list()
  
  for (i in seq_along(graph_list)) {
    edges <- igraph::as_data_frame(graph_list[[i]], what = "edges")
    edges$edge_id <- paste(pmin(edges$from, edges$to), 
                           pmax(edges$from, edges$to), sep = "-")
    edges$timepoint <- time_labels[i]
    all_edges[[i]] <- edges[, c("edge_id", "timepoint")]
  }
  
  all_edges_df <- do.call(rbind, all_edges)
  
  # Count appearances per edge
  edge_counts <- table(all_edges_df$edge_id)
  
  tibble::tibble(
    n_appearances = as.numeric(names(table(edge_counts))),
    n_edges = as.numeric(table(edge_counts)),
    pct_edges = as.numeric(table(edge_counts)) / sum(table(edge_counts))
  )
}

# Helper: Structural trends
calculate_structural_trends <- function(graph_list, time_labels) {
  
  trends <- lapply(seq_along(graph_list), function(i) {
    g <- graph_list[[i]]
    
    tibble::tibble(
      timepoint = time_labels[i],
      n_nodes = igraph::vcount(g),
      n_edges = igraph::ecount(g),
      density = igraph::edge_density(g),
      avg_degree = mean(igraph::degree(g)),
      clustering = igraph::transitivity(g, type = "global"),
      n_components = igraph::components(g)$no,
      diameter = tryCatch(igraph::diameter(g), error = function(e) NA)
    )
  })
  
  do.call(rbind, trends)
}

# Helper: Interpret stability
interpret_temporal_stability <- function(overall, pairwise, node_stability, structural) {
  
  interp <- character()
  
  # Overall assessment
  avg_edge_jac <- overall$avg_edge_jaccard
  
  if (avg_edge_jac > 0.7) {
    interp <- c(interp, "=== HIGHLY STABLE NETWORK ===")
    interp <- c(interp, "Network structure is very consistent over time")
  } else if (avg_edge_jac > 0.4) {
    interp <- c(interp, "=== MODERATELY STABLE NETWORK ===")
    interp <- c(interp, "Network shows reasonable stability with some changes")
  } else {
    interp <- c(interp, "=== VOLATILE NETWORK ===")
    interp <- c(interp, "Network structure changes significantly over time")
  }
  
  interp <- c(interp, "")
  interp <- c(interp, sprintf("Average node stability (Jaccard): %.3f", overall$avg_node_jaccard))
  interp <- c(interp, sprintf("Average edge stability (Jaccard): %.3f", overall$avg_edge_jaccard))
  interp <- c(interp, sprintf("Average tie formation rate: %.1f%%", overall$avg_formation_rate * 100))
  interp <- c(interp, sprintf("Average tie dissolution rate: %.1f%%", overall$avg_dissolution_rate * 100))
  interp <- c(interp, sprintf("Average tie persistence rate: %.1f%%", overall$avg_persistence_rate * 100))
  
  interp <- c(interp, "")
  
  # Turnover
  if (overall$avg_node_jaccard < 0.8) {
    interp <- c(interp, "⚠ HIGH ROSTER TURNOVER:")
    interp <- c(interp, sprintf("  • %.1f%% of nodes change between periods on average",
                                (1 - overall$avg_node_jaccard) * 100))
  }
  
  if (overall$avg_dissolution_rate > 0.3) {
    interp <- c(interp, "⚠ HIGH RELATIONSHIP CHURN:")
    interp <- c(interp, sprintf("  • %.1f%% of relationships dissolve each period",
                                overall$avg_dissolution_rate * 100))
  }
  
  # Node stability
  if (!is.null(node_stability)) {
    always_present <- sum(node_stability$persistence_rate == 1)
    never_stable <- sum(node_stability$persistence_rate < 0.5)
    
    interp <- c(interp, "")
    interp <- c(interp, sprintf("Node persistence: %d always present, %d transient",
                                always_present, never_stable))
    
    high_volatility <- sum(node_stability$degree_volatility > 1, na.rm = TRUE)
    if (high_volatility > 0) {
      interp <- c(interp, sprintf("  • %d nodes show high degree volatility", high_volatility))
    }
  }
  
  # Structural trends
  if (!is.null(structural)) {
    density_change <- (structural$density[nrow(structural)] - structural$density[1]) / 
                      structural$density[1]
    
    if (abs(density_change) > 0.2) {
      direction <- if (density_change > 0) "increased" else "decreased"
      interp <- c(interp, "")
      interp <- c(interp, sprintf("⚠ STRUCTURAL CHANGE: Density %s by %.1f%%",
                                  direction, abs(density_change) * 100))
    }
  }
  
  interp <- c(interp, "")
  interp <- c(interp, "=== RECOMMENDATIONS ===")
  
  if (overall$avg_edge_jaccard < 0.5) {
    interp <- c(interp, "• High instability - investigate causes of relationship churn")
    interp <- c(interp, "• Consider interventions to stabilize key relationships")
  }
  
  if (overall$avg_dissolution_rate > 0.4) {
    interp <- c(interp, "• Focus on relationship maintenance and retention")
  }
  
  if (overall$avg_formation_rate < 0.1) {
    interp <- c(interp, "• Low new tie formation - encourage networking")
  }
  
  if (overall$avg_edge_jaccard > 0.7) {
    interp <- c(interp, "• Network is stable - good for consistency")
    interp <- c(interp, "• Monitor for stagnation - may need fresh connections")
  }
  
  interp
}

# Print method
#' @export
print.temporal_stability <- function(x, ...) {
  cat("=== Temporal Network Stability Analysis ===\n\n")
  cat("Time points analyzed:", x$n_timepoints, "\n")
  cat("Periods:", paste(x$time_labels, collapse = " → "), "\n\n")
  
  cat(paste(x$interpretation, collapse = "\n"))
  
  cat("\n\n=== Pairwise Stability ===\n")
  print(x$pairwise_stability[, c("from_period", "to_period", "node_jaccard", 
                                 "edge_jaccard", "formation_rate", "dissolution_rate")])
  
  if (!is.null(x$structural_trends)) {
    cat("\n=== Structural Trends ===\n")
    print(x$structural_trends)
  }
  
  if (!is.null(x$node_stability)) {
    cat("\n=== Most Stable Nodes (Top 10) ===\n")
    print(head(x$node_stability[, c("node", "persistence_rate", "avg_degree", 
                                    "degree_volatility")], 10))
  }
  
  invisible(x)
}
