# ============================================================
# ERGM Runner with Optional GOF + Plain-English Interpretation
# ============================================================

#' Run Exponential Random Graph Model (ERGM) Analysis with Enhanced Interpretation
#'
#' @description
#' Fits an Exponential Random Graph Model (ERGM) to understand the social processes
#' driving tie formation in your network. This function provides comprehensive testing
#' of structural effects, homophily patterns, categorical main effects, and continuous
#' attribute similarity, with automatic plain-English interpretation of results.
#'
#' ERGMs are statistical models that explain network structure as a function of
#' endogenous network processes (e.g., reciprocity, transitivity) and exogenous
#' node attributes (e.g., homophily, attribute-based popularity). Unlike traditional
#' regression, ERGMs account for the dependencies between ties in a network.
#'
#' @param g An igraph object representing the network to analyze
#' @param node_attributes Character vector of categorical vertex attribute names to test
#'   for homophily using nodematch(). Tests whether nodes with the same attribute value
#'   are more likely to connect. Example: c("department", "gender")
#' @param node_mix Character vector of categorical vertex attribute names to test for
#'   mixing patterns using nodemix(). Tests specific combinations of attribute values
#'   (e.g., Male-Female ties, Sales-Engineering ties). More flexible than nodematch.
#'   Example: c("gender", "department")
#' @param node_covariates Character vector of continuous vertex attribute names to test
#'   for main effects using nodecov(). Tests whether higher values of an attribute
#'   increase overall tie propensity. Example: c("seniority", "performance_rating")
#' @param continuous_attributes Character vector of continuous vertex attribute names to
#'   test for similarity using absdiff(). Tests whether nodes with similar values are
#'   more likely to connect. Example: c("age", "tenure", "performance_score")
#' @param structural_terms Character vector of structural effects to include. Options:
#'   \itemize{
#'     \item \code{"edges"} - Baseline density (always included automatically)
#'     \item \code{"mutual"} - Reciprocity (directed networks only)
#'     \item \code{"triangles"} - Simple triangle count (undirected; gwesp usually preferred)
#'     \item \code{"gwesp"} - Geometrically weighted edgewise shared partners (triadic closure)
#'     \item \code{"gwdegree"} - Geometrically weighted degree (hubs/degree heterogeneity)
#'     \item \code{"popularity"} - Preferential attachment by in-degree (directed only)
#'     \item \code{"activity"} - Sender effects by out-degree (directed only)
#'     \item \code{"transitivity"} - Alias for gwesp (kept for compatibility)
#'   }
#'   Default: c("mutual", "gwesp", "gwdegree") for directed networks,
#'   c("gwesp", "gwdegree") for undirected networks
#' @param edge_covariates Named list mapping model covariate names to igraph edge attribute
#'   names. Creates dyadic covariate matrices for edgecov() terms. The edge attribute
#'   values are used as weights in the model. Example:
#'   list(interaction_strength = "weight", collaboration_frequency = "frequency")
#' @param node_factors Character vector of categorical vertex attributes to test for
#'   main effects (differential tie propensity by category). Uses nodefactor() for
#'   undirected networks, nodeofactor()/nodeifactor() for directed networks.
#'   Example: c("job_level", "department")
#' @param node_factor_base Named list specifying reference categories for node_factors.
#'   Example: list(gender = "Female", department = "Sales")
#' @param directed_factor_mode For directed networks with node_factors, controls which
#'   effects to test: "sender" (nodeofactor), "receiver" (nodeifactor), or "both".
#'   Default: "both"
#' @param gwesp_decay Decay parameter for GWESP term. Controls diminishing returns of
#'   additional shared partners. Default: 0.5 (typical range: 0.25-1.0)
#' @param gwdegree_decay Decay parameter for GWDEGREE term. Controls diminishing returns
#'   of additional connections. Default: 0.5 (typical range: 0.25-1.0)
#' @param gwdegree_fixed Logical. If FALSE (default), ERGM estimates the decay parameter
#'   (more stable). If TRUE, fixes decay at gwdegree_decay value.
#' @param gwesp_fixed Logical. If TRUE (default), fixes GWESP decay at gwesp_decay value.
#'   Usually safe to fix for stability.
#' @param scale_continuous Logical. If TRUE (default), continuous attributes are z-scored
#'   before analysis and absdiff() uses the scaled version (attr_z). Recommended for
#'   interpretability and numerical stability.
#' @param control_mcmc List of MCMC control parameters passed to ergm::control.ergm().
#'   Default: list(MCMC.burnin = 10000, MCMC.samplesize = 10000, MCMC.interval = 1000)
#' @param seed Random seed for reproducibility. Default: 12345
#' @param verbose Logical. Print detailed fitting progress and interpretations? Default: TRUE
#' @param run_gof Logical. If TRUE, compute ergm::gof() diagnostics (can be slow). Default: FALSE
#'
#' @return A list with the following components:
#' \describe{
#'   \item{model}{The fitted ergm model object}
#'   \item{summary}{Summary of the fitted model (from summary.ergm)}
#'   \item{coefficients}{Data frame of coefficients with estimates, standard errors,
#'     z-values, p-values, and significance flags}
#'   \item{interpretation}{Character vector with plain-English interpretations of
#'     significant effects (one element per interpretation)}
#'   \item{gof}{Goodness-of-fit object from ergm::gof() (or NULL if not run / failed)}
#'   \item{gof_interpretation}{Character vector with interpretations of GOF statistics
#'     (one element per GOF component), or NULL}
#'   \item{formula}{The ERGM formula used in the model}
#'   \item{network}{The network object (converted from igraph to network format)}
#'   \item{is_directed}{Logical indicating if the network is directed}
#' }
#'
#' @examples
#' \dontrun{
#' library(igraph)
#' library(hineycombs)
#'
#' # Create example network
#' g <- create_network(n = 100, p = 0.08, directed = FALSE)
#'
#' # Basic ERGM with structural terms and homophily
#' results <- run_insights_ergm_analysis(
#'   g,
#'   node_attributes = c("team", "gender"),
#'   continuous_attributes = c("psych_safety"),
#'   structural_terms = c("gwesp", "gwdegree")
#' )
#'
#' # View interpretations
#' cat(results$interpretation, sep = "\n")
#'
#' # Check goodness of fit
#' plot(results$gof)
#' cat(results$gof_interpretation, sep = "\n")
#'
#' # Advanced: Include mixing patterns and node covariates
#' results2 <- run_insights_ergm_analysis(
#'   g,
#'   node_attributes = c("team"),           # Homophily
#'   node_mix = c("gender"),                # Specific gender combinations
#'   node_covariates = c("psych_safety"),   # Main effect of psych safety
#'   continuous_attributes = c("innovation"), # Similarity on innovation
#'   structural_terms = c("gwesp", "gwdegree")
#' )
#'
#' # Full model with all features
#' results3 <- run_insights_ergm_analysis(
#'   g,
#'   node_attributes = c("team"),
#'   node_mix = c("job_level"),
#'   node_covariates = c("psych_safety", "risk_taking"),
#'   node_factors = c("gender"),
#'   node_factor_base = list(gender = "F"),
#'   continuous_attributes = c("innovation"),
#'   edge_covariates = list(strength = "weight"),
#'   structural_terms = c("gwesp", "gwdegree")
#' )
#'
#' # Extract coefficients for further analysis
#' coef_table <- results3$coefficients
#' significant_effects <- coef_table[coef_table$significant, ]
#' }
#'
#' @seealso
#' \code{\link[ergm]{ergm}} for the underlying ERGM fitting function
#' \code{\link[ergm]{gof}} for goodness-of-fit diagnostics
#'
#' @importFrom ergm ergm gof control.ergm
#' @importFrom intergraph asNetwork
#' @importFrom network set.vertex.attribute get.vertex.attribute
#' @importFrom igraph is_directed vcount vertex_attr vertex_attr_names edge_attr edge_attr_names as_edgelist
#' @importFrom stats as.formula
#'
#' @export
run_stats_ergm_analysis <- function(
    g,
    node_attributes = NULL,
    node_mix = NULL,
    node_covariates = NULL,
    continuous_attributes = NULL,
    structural_terms = NULL,
    edge_covariates = NULL,
    node_factors = NULL,
    node_factor_base = list(),
    directed_factor_mode = c("both", "sender", "receiver"),
    gwesp_decay = 0.5,
    gwdegree_decay = 0.5,
    gwdegree_fixed = FALSE,
    gwesp_fixed = TRUE,
    scale_continuous = TRUE,
    control_mcmc = list(
      MCMC.burnin = 10000,
      MCMC.samplesize = 10000,
      MCMC.interval = 1000
    ),
    seed = 12345,
    verbose = TRUE,
    run_gof = FALSE
) {
  # ---- Package checks ----
  if (!requireNamespace("ergm", quietly = TRUE)) {
    stop("Package 'ergm' is required. Install with: install.packages('ergm')")
  }
  if (!requireNamespace("intergraph", quietly = TRUE)) {
    stop("Package 'intergraph' is required. Install with: install.packages('intergraph')")
  }
  if (!requireNamespace("igraph", quietly = TRUE)) {
    stop("Package 'igraph' is required. Install with: install.packages('igraph')")
  }
  if (!requireNamespace("network", quietly = TRUE)) {
    stop("Package 'network' is required. Install with: install.packages('network')")
  }
  
  if (!inherits(g, "igraph")) stop("`g` must be an igraph object.")
  
  directed_factor_mode <- base::match.arg(directed_factor_mode)
  
  if (verbose) {
    cat("=== ERGM Analysis ===\n")
    cat("Preparing network for ERGM modeling...\n\n")
  }
  
  net <- intergraph::asNetwork(g)
  is_directed <- igraph::is_directed(g)
  
  # ---- Default structural terms ----
  if (is.null(structural_terms)) {
    structural_terms <- if (is_directed) c("mutual", "gwesp", "gwdegree") else c("gwesp", "gwdegree")
    if (verbose) {
      cat(
        "Using default structural terms for ",
        if (is_directed) "directed" else "undirected",
        " network: ",
        paste(structural_terms, collapse = ", "),
        "\n",
        sep = ""
      )
    }
  }
  
  # ---- Validate / clean structural terms ----
  valid_terms <- c("edges", "mutual", "transitivity", "triangles", "gwesp", "gwdegree", "popularity", "activity")
  invalid <- setdiff(structural_terms, valid_terms)
  if (length(invalid) > 0) {
    warning("Invalid structural terms ignored: ", paste(invalid, collapse = ", "))
    structural_terms <- intersect(structural_terms, valid_terms)
  }
  
  # ---- Handle transitivity alias ----
  if ("transitivity" %in% structural_terms) {
    if (!("gwesp" %in% structural_terms)) {
      structural_terms[structural_terms == "transitivity"] <- "gwesp"
    } else {
      structural_terms <- structural_terms[structural_terms != "transitivity"]
      if (verbose) cat("Note: 'transitivity' skipped because 'gwesp' is already included.\n")
    }
  }
  
  # ---- Scale continuous attributes (create *_z on the network object) ----
  if (!is.null(continuous_attributes) && isTRUE(scale_continuous)) {
    for (attr in continuous_attributes) {
      if (attr %in% igraph::vertex_attr_names(g)) {
        vals <- igraph::vertex_attr(g, attr)
        if (is.numeric(vals) && length(unique(vals[!is.na(vals)])) > 1) {
          zname <- paste0(attr, "_z")
          zvals <- as.numeric(scale(vals))
          network::set.vertex.attribute(net, zname, zvals)
        }
      }
    }
  }
  
  # ---- Edge covariates as edgecov() matrices ----
  edgecov_env <- new.env(parent = parent.frame())
  edgecov_terms <- character(0)
  
  if (!is.null(edge_covariates)) {
    if (!is.list(edge_covariates) || is.null(names(edge_covariates)) || any(names(edge_covariates) == "")) {
      stop("edge_covariates must be a *named* list, e.g., list(weight = 'weight').")
    }
    
    n <- igraph::vcount(g)
    edgelist <- igraph::as_edgelist(g, names = FALSE)
    
    for (model_name in names(edge_covariates)) {
      edge_attr <- edge_covariates[[model_name]]
      if (!(edge_attr %in% igraph::edge_attr_names(g))) {
        warning("Edge attribute '", edge_attr, "' not found in graph; skipping edge covariate '", model_name, "'.")
        next
      }
      
      w <- igraph::edge_attr(g, edge_attr)
      if (!is.numeric(w)) {
        warning("Edge attribute '", edge_attr, "' is not numeric; skipping edge covariate '", model_name, "'.")
        next
      }
      
      mat <- matrix(0, nrow = n, ncol = n)
      for (i in seq_len(nrow(edgelist))) {
        a <- edgelist[i, 1]
        b <- edgelist[i, 2]
        mat[a, b] <- w[i]
        if (!is_directed) mat[b, a] <- w[i]
      }
      
      obj_name <- paste0(model_name, "_matrix")
      assign(obj_name, mat, envir = edgecov_env)
      edgecov_terms <- c(edgecov_terms, paste0("edgecov(", obj_name, ")"))
      
      if (verbose) cat("Including edge covariate: ", model_name, " from E(g)$", edge_attr, "\n", sep = "")
    }
  }
  
  # ---- Build formula ----
  formula_parts <- c("net ~ edges")
  add_term <- function(x) formula_parts <<- c(formula_parts, x)
  
  if (verbose) {
    cat("\n=== Structural Effects Being Tested ===\n")
    cat("• Edges: Baseline network density (always included)\n")
  }
  
  for (term in structural_terms) {
    if (term == "edges") next
    
    if (term == "mutual") {
      if (is_directed) {
        add_term("mutual")
        if (verbose) {
          cat("• Mutual: Testing RECIPROCITY - Do people reciprocate connections?\n")
          cat("  Example: If Alice emails Bob, does Bob email Alice back?\n")
        }
      } else if (verbose) {
        cat("• Mutual: SKIPPED (only for directed networks)\n")
      }
      
    } else if (term == "triangles") {
      if (!is_directed) {
        add_term("triangles")
        if (verbose) {
          cat("• Triangles: Testing CLUSTERING - Do people form tight-knit groups?\n")
          cat("  Example: Do your connections also connect with each other?\n")
        }
      } else if (verbose) {
        cat("• Triangles: SKIPPED (typically use 'gwesp' for directed networks)\n")
      }
      
    } else if (term == "gwesp") {
      add_term(paste0("gwesp(", gwesp_decay, ", fixed=", if (gwesp_fixed) "TRUE" else "FALSE", ")"))
      if (verbose) {
        cat("• GWESP: Testing SHARED PARTNERS - Do people connect through mutual contacts?\n")
        cat("  Example: Are you more likely to connect with someone if you share many mutual friends?\n")
        cat("  (This is a more sophisticated version of triangle counting)\n")
      }
      
    } else if (term == "gwdegree") {
      if (is_directed) {
        add_term(paste0("gwidegree(", gwdegree_decay, ", fixed=", if (gwdegree_fixed) "TRUE" else "FALSE", ")"))
        add_term(paste0("gwodegree(", gwdegree_decay, ", fixed=", if (gwdegree_fixed) "TRUE" else "FALSE", ")"))
      } else {
        add_term(paste0("gwdegree(", gwdegree_decay, ", fixed=", if (gwdegree_fixed) "TRUE" else "FALSE", ")"))
      }
      if (verbose) {
        cat("• GWDegree: Testing DEGREE DISTRIBUTION - Are there 'hubs' or is it evenly distributed?\n")
        cat("  Example: Do a few people have many connections while most have few?\n")
        if (!gwdegree_fixed) cat("  Note: decay will be estimated (fixed=FALSE) for stability.\n")
      }
      
    } else if (term == "popularity") {
      if (is_directed) {
        add_term("idegree(1.5)")
        if (verbose) cat("• Popularity: Testing PREFERENTIAL ATTACHMENT (directed) - do high-indegree nodes attract ties?\n")
      } else if (verbose) {
        cat("• Popularity: SKIPPED (directed-only; use 'gwdegree' for undirected)\n")
      }
      
    } else if (term == "activity") {
      if (is_directed) {
        add_term("odegree(1.5)")
        if (verbose) cat("• Activity: Testing SENDER EFFECTS (directed) - are some nodes more active at sending ties?\n")
      } else if (verbose) {
        cat("• Activity: SKIPPED (directed-only; use 'gwdegree' for undirected)\n")
      }
    }
  }
  
  # ---- Homophily: nodematch() for categorical attributes ----
  if (!is.null(node_attributes)) {
    if (verbose) {
      cat("\n=== Homophily Testing ===\n")
      cat("Testing if people connect with others who share the same attributes:\n")
    }
    
    for (attr in node_attributes) {
      if (!(attr %in% igraph::vertex_attr_names(g))) {
        warning("Attribute '", attr, "' not found in graph - skipping")
        next
      }
      vals <- igraph::vertex_attr(g, attr)
      uniq <- unique(vals[!is.na(vals)])
      if (length(uniq) <= 1) {
        warning("Attribute '", attr, "' has no variation - skipping")
        next
      }
      
      add_term(paste0("nodematch('", attr, "')"))
      
      if (verbose) {
        cat("• ", attr, ": Do people with the same ", attr, " connect more?\n", sep = "")
        cat("  Groups: ", paste(head(uniq, 5), collapse = ", "), if (length(uniq) > 5) "..." else "", "\n", sep = "")
      }
    }
  }
  
  # ---- Mixing patterns: nodemix() for categorical attributes ----
  if (!is.null(node_mix)) {
    if (verbose) {
      cat("\n=== Mixing Pattern Testing ===\n")
      cat("Testing specific combinations of attribute values (more flexible than homophily):\n")
    }
    
    for (attr in node_mix) {
      if (!(attr %in% igraph::vertex_attr_names(g))) {
        warning("Attribute '", attr, "' not found in graph - skipping")
        next
      }
      vals <- igraph::vertex_attr(g, attr)
      uniq <- unique(vals[!is.na(vals)])
      if (length(uniq) <= 1) {
        warning("Attribute '", attr, "' has no variation - skipping")
        next
      }
      
      add_term(paste0("nodemix('", attr, "')"))
      
      if (verbose) {
        cat("• ", attr, ": Testing all pairwise combinations of ", attr, " values\n", sep = "")
        cat("  Groups: ", paste(head(uniq, 5), collapse = ", "), if (length(uniq) > 5) "..." else "", "\n", sep = "")
        cat("  (Estimates specific tie probabilities for each group pair)\n")
      }
    }
  }
  
  # ---- Node covariates: nodecov() for continuous attributes ----
  if (!is.null(node_covariates)) {
    if (verbose) {
      cat("\n=== Node Covariate Effects (Main Effects) ===\n")
      cat("Testing if higher attribute values increase overall tie propensity:\n")
    }
    
    for (attr in node_covariates) {
      if (!(attr %in% igraph::vertex_attr_names(g))) {
        warning("Attribute '", attr, "' not found in graph - skipping")
        next
      }
      
      vals <- igraph::vertex_attr(g, attr)
      if (!is.numeric(vals) || length(unique(vals[!is.na(vals)])) <= 1) {
        warning("Attribute '", attr, "' is not numeric or has no variation - skipping")
        next
      }
      
      used_attr <- attr
      if (scale_continuous) {
        zname <- paste0(attr, "_z")
        if (!is.null(network::get.vertex.attribute(net, zname))) {
          used_attr <- zname
        }
      }
      
      add_term(paste0("nodecov('", used_attr, "')"))
      
      if (verbose) {
        cat("• ", attr, ": Do nodes with higher ", attr, " have more ties overall?\n", sep = "")
        cat("  Range: ", round(min(vals, na.rm = TRUE), 2), " to ", round(max(vals, na.rm = TRUE), 2), "\n", sep = "")
        if (used_attr != attr) cat("  Using scaled version: ", used_attr, "\n", sep = "")
        cat("  (Positive coefficient = higher values have more ties)\n")
      }
    }
  }
  
  # ---- Categorical main effects (propensity) via nodefactor/nodeofactor/nodeifactor ----
  if (!is.null(node_factors)) {
    if (verbose) {
      cat("\n=== Categorical Main Effects (Propensity) ===\n")
      cat("Testing if some categories have higher overall tie propensity:\n")
    }
    
    for (attr in node_factors) {
      if (!(attr %in% igraph::vertex_attr_names(g))) {
        warning("Attribute '", attr, "' not found in graph - skipping")
        next
      }
      
      vals <- igraph::vertex_attr(g, attr)
      uniq <- unique(vals[!is.na(vals)])
      if (length(uniq) <= 1) {
        warning("Attribute '", attr, "' has no variation - skipping")
        next
      }
      
      base_level <- NULL
      if (!is.null(node_factor_base[[attr]])) {
        base_level <- node_factor_base[[attr]]
      }
      
      if (!is_directed) {
        if (is.null(base_level)) {
          add_term(paste0("nodefactor('", attr, "')"))
        } else {
          add_term(paste0("nodefactor('", attr, "', base='", base_level, "')"))
        }
        
        if (verbose) {
          cat("• ", attr, ": Do some ", attr, " categories have MORE ties overall? (nodefactor)\n", sep = "")
          if (!is.null(base_level)) cat("  Reference (base) = ", base_level, "\n", sep = "")
        }
        
      } else {
        if (directed_factor_mode %in% c("sender", "both")) {
          if (is.null(base_level)) {
            add_term(paste0("nodeofactor('", attr, "')"))
          } else {
            add_term(paste0("nodeofactor('", attr, "', base='", base_level, "')"))
          }
          if (verbose) cat("• ", attr, ": Sender activity by category (nodeofactor)\n", sep = "")
        }
        
        if (directed_factor_mode %in% c("receiver", "both")) {
          if (is.null(base_level)) {
            add_term(paste0("nodeifactor('", attr, "')"))
          } else {
            add_term(paste0("nodeifactor('", attr, "', base='", base_level, "')"))
          }
          if (verbose) cat("• ", attr, ": Receiver popularity by category (nodeifactor)\n", sep = "")
        }
        
        if (!is.null(base_level) && verbose) {
          cat("  Reference (base) = ", base_level, "\n", sep = "")
        }
      }
    }
  }
  
  # ---- Similarity testing: absdiff() for continuous attributes ----
  if (!is.null(continuous_attributes)) {
    if (verbose) {
      cat("\n=== Similarity Testing (Continuous Attributes) ===\n")
      cat("Testing if people with similar values connect more:\n")
    }
    
    for (attr in continuous_attributes) {
      if (!(attr %in% igraph::vertex_attr_names(g))) {
        warning("Attribute '", attr, "' not found in graph - skipping")
        next
      }
      
      vals <- igraph::vertex_attr(g, attr)
      if (!is.numeric(vals) || length(unique(vals[!is.na(vals)])) <= 1) {
        warning("Attribute '", attr, "' is not numeric or has no variation - skipping")
        next
      }
      
      used_attr <- attr
      if (isTRUE(scale_continuous)) {
        zname <- paste0(attr, "_z")
        zvals <- network::get.vertex.attribute(net, zname)
        if (!is.null(zvals)) used_attr <- zname
      }
      
      add_term(paste0("absdiff('", used_attr, "')"))
      
      if (verbose) {
        cat("• ", attr, ": Do people with similar ", attr, " values connect more?\n", sep = "")
        cat("  Range: ", round(min(vals, na.rm = TRUE), 2), " to ", round(max(vals, na.rm = TRUE), 2), "\n", sep = "")
        if (used_attr != attr) cat("  Using scaled version: ", used_attr, "\n", sep = "")
        cat("  (Negative coefficient = similarity attracts, Positive = difference attracts)\n")
      }
    }
  }
  
  # ---- Add edgecov terms ----
  if (length(edgecov_terms) > 0) {
    formula_parts <- c(formula_parts, edgecov_terms)
  }
  
  formula_str <- paste(formula_parts, collapse = " + ")
  model_formula <- stats::as.formula(formula_str)
  
  if (verbose) {
    cat("\n=== Model Formula ===\n")
    cat(formula_str, "\n\n")
  }
  
  # ---- Fit ERGM ----
  set.seed(seed)
  if (verbose) {
    cat("Fitting ERGM...\n")
    cat(
      "MCMC settings: burnin =", control_mcmc$MCMC.burnin,
      ", sample size =", control_mcmc$MCMC.samplesize,
      ", interval =", control_mcmc$MCMC.interval, "\n\n"
    )
  }
  
  model <- tryCatch({
    ergm::ergm(
      model_formula,
      control = do.call(ergm::control.ergm, control_mcmc),
      verbose = verbose
    )
  }, error = function(e) {
    stop(
      "ERGM fitting failed: ", e$message,
      "\nTry simplifying the model (often drop/fix gwdegree first) or adjust MCMC settings."
    )
  })
  
  if (verbose) cat("\n=== Model Fitting Complete ===\n\n")
  
  model_summary <- summary(model)
  coefs <- model_summary$coefficients
  coef_df <- as.data.frame(coefs)
  coef_df$term <- rownames(coef_df)
  
  pcol <- grep("^Pr\\(", colnames(coef_df), value = TRUE)
  if (length(pcol) == 1) {
    coef_df$significant <- coef_df[[pcol]] < 0.05
  } else {
    coef_df$significant <- NA
  }
  
  if (verbose) {
    cat("=== Model Results ===\n")
    show_cols <- intersect(c("term", "Estimate", "Std. Error", "z value", "Pr(>|z|)", "significant"), colnames(coef_df))
    print(coef_df[, show_cols, drop = FALSE])
    cat("\n")
  }
  
  interpretation <- generate_ergm_interpretation(coef_df)
  
  if (verbose) {
    cat("\n=== Plain English Interpretation ===\n")
    if (length(interpretation) == 1 && !grepl("^•", interpretation[1])) {
      cat(interpretation, "\n\n")
    } else {
      cat(paste(interpretation, collapse = "\n"), "\n\n")
    }
  }
  
  # ---- GOF (optional) ----
  gof_result <- NULL
  gof_interpretation <- NULL
  
  if (isTRUE(run_gof)) {
    gof_result <- tryCatch({
      if (verbose) cat("Calculating goodness of fit diagnostics...\n")
      ergm::gof(model, verbose = FALSE)
    }, error = function(e) {
      if (verbose) {
        cat("\nWarning: GOF calculation failed:", e$message, "\n")
        cat("Skipping goodness of fit diagnostics.\n")
      }
      NULL
    })
    
    if (!is.null(gof_result)) {
      gof_interpretation <- interpret_gof(gof_result)
      if (verbose) {
        cat("Goodness of fit calculated successfully!\n\n")
        cat("=== Goodness of Fit Interpretation ===\n")
        if (length(gof_interpretation) == 1 && !grepl("%", gof_interpretation[1])) {
          cat(gof_interpretation, "\n\n")
        } else {
          cat(paste(gof_interpretation, collapse = "\n"), "\n\n")
        }
      }
    }
  } else {
    if (verbose) cat("Skipping goodness of fit diagnostics (run_gof = FALSE).\n")
  }
  
  if (verbose) cat("\n=== Analysis Complete ===\n")
  
  list(
    model = model,
    summary = model_summary,
    coefficients = coef_df,
    interpretation = interpretation,
    gof = gof_result,
    gof_interpretation = gof_interpretation,
    formula = model_formula,
    network = net,
    is_directed = is_directed
  )
}


#' Generate plain English interpretation of ERGM results
#' @keywords internal
generate_ergm_interpretation <- function(coef_df) {
  interpretations <- character(0)
  
  pcol <- grep("^Pr\\(", colnames(coef_df), value = TRUE)
  if (length(pcol) != 1) {
    return("Interpretation unavailable: could not locate a p-value column in the ERGM summary.")
  }
  
  for (i in seq_len(nrow(coef_df))) {
    term <- coef_df$term[i]
    est  <- coef_df$Estimate[i]
    pval <- coef_df[[pcol]][i]
    
    if (is.na(pval) || pval >= 0.05) next
    
    direction <- if (est > 0) "increases" else "decreases"
    strength <- if (abs(est) > 1) "strongly" else if (abs(est) > 0.5) "moderately" else "slightly"
    
    interp <- NULL
    
    if (term == "edges") {
      interp <- paste0("Baseline density: network is ", if (est < 0) "sparse" else "dense",
                       " (", strength, " ", direction, " tie probability)")
    } else if (term == "mutual") {
      interp <- paste0("Reciprocity: ", strength, " ", direction,
                       " likelihood of mutual ties (A↔B)")
    } else if (grepl("gwesp", term)) {
      interp <- paste0("Triadic closure (GWESP): ", strength, " ", direction,
                       " tendency for shared-partner clustering")
    } else if (grepl("gwdegree|gwidegree|gwodegree", term)) {
      interp <- paste0("Degree heterogeneity: ", strength, " ", direction,
                       " tendency toward hubs / unequal degree distribution")
    } else if (grepl("^triangles$", term)) {
      interp <- paste0("Triangles: ", strength, " ", direction,
                       " tendency to form closed triads")
    } else if (grepl("^idegree", term)) {
      interp <- paste0("Popularity (idegree): ", strength, " ", direction,
                       " tendency for high-indegree nodes to attract ties")
    } else if (grepl("^odegree", term)) {
      interp <- paste0("Activity (odegree): ", strength, " ", direction,
                       " tendency for some nodes to initiate more ties")
    } else if (grepl("^nodematch\\.", term)) {
      attr_name <- sub("^nodematch\\.", "", term)
      interp <- if (est > 0) {
        paste0("Homophily (", attr_name, "): ", strength, " increases ties among same-", attr_name, " nodes")
      } else {
        paste0("Heterophily (", attr_name, "): ", strength, " increases ties among different-", attr_name, " nodes")
      }
    } else if (grepl("^nodemix\\.", term)) {
      # Extract attribute and levels from term like "nodemix.gender.M.F"
      parts <- strsplit(term, "\\.")[[1]]
      if (length(parts) >= 3) {
        attr_name <- parts[2]
        level_combo <- paste(parts[3:length(parts)], collapse = "-")
        interp <- paste0("Mixing (", attr_name, " ", level_combo, "): ", strength, " ", direction, " ties between these groups")
      } else {
        interp <- paste0("Mixing pattern: ", strength, " ", direction, " tie probability for this combination")
      }
    } else if (grepl("^nodecov\\.", term)) {
      attr_name <- sub("^nodecov\\.", "", term)
      interp <- if (est > 0) {
        paste0("Node covariate (", attr_name, "): ", strength, " increases ties for nodes with higher values")
      } else {
        paste0("Node covariate (", attr_name, "): ", strength, " decreases ties for nodes with higher values")
      }
    } else if (grepl("^nodefactor\\.", term)) {
      attr_name <- sub("^nodefactor\\.", "", term)
      interp <- paste0("Main effect (", attr_name, "): ", strength, " ", direction, " overall tie propensity for this category")
    } else if (grepl("^nodeofactor\\.", term)) {
      attr_name <- sub("^nodeofactor\\.", "", term)
      interp <- paste0("Sender effect (", attr_name, "): ", strength, " ", direction, " outgoing tie activity for this category")
    } else if (grepl("^nodeifactor\\.", term)) {
      attr_name <- sub("^nodeifactor\\.", "", term)
      interp <- paste0("Receiver effect (", attr_name, "): ", strength, " ", direction, " incoming tie popularity for this category")
    } else if (grepl("^absdiff\\.", term)) {
      attr_name <- sub("^absdiff\\.", "", term)
      interp <- if (est < 0) {
        paste0("Similarity (", attr_name, "): ", strength, " increases ties among similar values")
      } else {
        paste0("Difference (", attr_name, "): ", strength, " increases ties among dissimilar values")
      }
    } else if (grepl("^edgecov\\.", term) || grepl("^edgecov\\(", term)) {
      interp <- paste0("Edge covariate: ", strength, " ", direction, " tie probability as the covariate increases")
    }
    
    if (!is.null(interp)) {
      interpretations <- c(interpretations, paste0("• ", interp, " (p = ", signif(pval, 3), ")"))
    }
  }
  
  if (length(interpretations) == 0) {
    return("No significant effects found at p < .05. Consider simplifying the model or revisiting term choices.")
  }
  
  interpretations
}


#' Interpret goodness of fit results
#' @keywords internal
interpret_gof <- function(gof_result) {
  if (is.null(gof_result)) {
    return("GOF not computed.")
  }
  
  nm <- names(gof_result)
  out <- character(0)
  
  `%||%` <- function(x, y) if (is.null(x)) y else x
  
  check_component <- function(comp, comp_name = "component") {
    if (is.null(comp)) return(NULL)
    
    if (inherits(comp, "summary.gof")) {
      if (!is.null(comp$summary)) {
        comp <- comp$summary
      }
    }
    
    if (is.matrix(comp) || is.data.frame(comp)) {
      cn <- colnames(comp)
      
      if (all(c("obs", "min", "max") %in% cn)) {
        obs <- comp[, "obs"]
        mn  <- comp[, "min"]
        mx  <- comp[, "max"]
        total <- sum(!is.na(obs))
        inrng <- sum(obs >= mn & obs <= mx, na.rm = TRUE)
        if (total > 0) {
          pct <- round(100 * inrng / total, 0)
          return(paste0(pct, "% (", inrng, "/", total, ") within simulated range"))
        }
      }
      
      if (all(c("obs", "mean") %in% cn)) {
        obs <- comp[, "obs"]
        mean_sim <- comp[, "mean"]
        std_col <- intersect(cn, c("std", "sd", "Std. Dev.", "MC se"))
        if (length(std_col) > 0) {
          std_sim <- comp[, std_col[1]]
          within_2sd <- sum(abs(obs - mean_sim) <= 2 * std_sim, na.rm = TRUE)
          total <- sum(!is.na(obs))
          if (total > 0) {
            pct <- round(100 * within_2sd / total, 0)
            return(paste0(pct, "% (", within_2sd, "/", total, ") within 2 SD of simulated mean"))
          }
        }
      }
      
      if ("p-value" %in% cn || "pval" %in% cn || "Pr(>Chisq)" %in% cn) {
        pval_col <- intersect(cn, c("p-value", "pval", "Pr(>Chisq)"))[1]
        pvals <- comp[, pval_col]
        good_fit <- sum(pvals > 0.05, na.rm = TRUE)
        total <- sum(!is.na(pvals))
        if (total > 0) {
          pct <- round(100 * good_fit / total, 0)
          return(paste0(pct, "% (", good_fit, "/", total, ") p > 0.05 (good fit)"))
        }
      }
    }
    
    if (is.list(comp) && !is.data.frame(comp)) {
      if ("pval" %in% names(comp) || "p.value" %in% names(comp)) {
        pval <- comp$pval %||% comp$p.value
        if (!is.null(pval) && is.numeric(pval) && length(pval) == 1) {
          if (pval > 0.05) return(paste0("p = ", round(pval, 3), " (good fit)"))
          return(paste0("p = ", round(pval, 3), " (poor fit)"))
        }
      }
    }
    
    NULL
  }
  
  for (cand in c("ideg", "odeg", "deg", "degree")) {
    if (cand %in% nm) {
      deg_res <- check_component(gof_result[[cand]], cand)
      if (!is.null(deg_res)) {
        label <- switch(cand,
                        ideg = "In-degree",
                        odeg = "Out-degree",
                        deg = "Degree",
                        degree = "Degree")
        out <- c(out, paste0(label, ": ", deg_res))
      }
    }
  }
  
  for (cand in c("espartners", "esp", "dspartners", "dsp", "espart")) {
    if (cand %in% nm) {
      esp_res <- check_component(gof_result[[cand]], cand)
      if (!is.null(esp_res)) {
        label <- if (grepl("^e", cand)) "Edgewise shared partners" else "Dyadwise shared partners"
        out <- c(out, paste0(label, " (clustering): ", esp_res))
      }
    }
  }
  
  for (cand in c("distance", "dist", "geodesic")) {
    if (cand %in% nm) {
      dist_res <- check_component(gof_result[[cand]], cand)
      if (!is.null(dist_res)) {
        out <- c(out, paste0("Geodesic distances: ", dist_res))
      }
    }
  }
  
  if ("model" %in% nm) {
    mod_res <- check_component(gof_result$model, "model")
    if (!is.null(mod_res)) {
      out <- c(out, paste0("Model statistics: ", mod_res))
    }
  }
  
  if ("triadcensus" %in% nm) {
    triad_res <- check_component(gof_result$triadcensus, "triadcensus")
    if (!is.null(triad_res)) {
      out <- c(out, paste0("Triad census: ", triad_res))
    }
  }
  
  if (length(out) == 0) {
    diag_info <- c(
      "GOF computed but automatic interpretation unavailable.",
      paste0("GOF object class: ", paste(class(gof_result), collapse = ", ")),
      paste0("GOF components: ", paste(nm, collapse = ", "))
    )
    
    if (length(nm) > 0) {
      first_comp <- gof_result[[nm[1]]]
      if (is.matrix(first_comp) || is.data.frame(first_comp)) {
        diag_info <- c(diag_info,
                       paste0("First component (", nm[1], ") columns: ",
                              paste(colnames(first_comp), collapse = ", ")))
      } else if (is.list(first_comp)) {
        diag_info <- c(diag_info,
                       paste0("First component (", nm[1], ") is a list with: ",
                              paste(names(first_comp), collapse = ", ")))
      }
    }
    
    return(c(
      diag_info,
      "",
      "To interpret manually:",
      "• Use plot(results$gof) to visualize fit",
      "• Use summary(results$gof) for detailed statistics",
      "• Check if observed values fall within simulated ranges"
    ))
  }
  
  c(out, "", "Interpretation: Values >80% indicate good model fit", "Visualize with: plot(results$gof)")
}