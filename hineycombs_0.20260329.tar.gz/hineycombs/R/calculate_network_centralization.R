#' Calculate network centralization metrics
#'
#' @description
#' Measures how centralized or hierarchical a network is. High centralization means
#' a few nodes dominate the network (star-like structure). Low centralization means
#' power/connections are distributed evenly (flat structure).
#'
#' Practical uses:
#' \itemize{
#'   \item Measure organizational hierarchy vs flatness
#'   \item Compare centralization across teams/departments
#'   \item Track changes in power distribution over time
#'   \item Identify overly centralized teams (bottleneck risk)
#'   \item Assess information flow patterns (centralized vs distributed)
#' }
#'
#' @param g An igraph object. Must have a \code{name} vertex attribute.
#' @param measures Character vector of centrality measures to calculate centralization for.
#'   Options: "degree", "betweenness", "closeness", "eigenvector", "all".
#'   Default is "all".
#' @param mode For directed graphs: "all", "in", or "out". Default is "all".
#' @param team_attr Optional vertex attribute for team-level comparison.
#' @param weight_var Optional edge attribute name for weights.
#'
#' @return A list containing:
#' \describe{
#'   \item{network_centralization}{Overall network centralization scores (0-1)}
#'   \item{node_centrality}{Individual node centrality scores}
#'   \item{team_centralization}{Team-level centralization (if team_attr provided)}
#'   \item{interpretation}{Plain English interpretation of results}
#'   \item{comparison}{Comparison to theoretical extremes (star vs circle)}
#' }
#'
#' @details
#' Centralization scores range from 0 to 1:
#'
#' \strong{0 (Decentralized):}
#' \itemize{
#'   \item All nodes have equal centrality (e.g., circle network)
#'   \item Flat organizational structure
#'   \item Distributed decision-making
#'   \item Resilient but potentially slower coordination
#' }
#'
#' \strong{1 (Centralized):}
#' \itemize{
#'   \item One node dominates (e.g., star network)
#'   \item Hierarchical structure
#'   \item Centralized decision-making
#'   \item Fast coordination but single point of failure
#' }
#'
#' \strong{Degree Centralization:} How unequal are connection counts?
#' High = few people have most connections (hub-and-spoke)
#'
#' \strong{Betweenness Centralization:} How unequal is brokerage?
#' High = few people control information flow (gatekeepers)
#'
#' \strong{Closeness Centralization:} How unequal is access to others?
#' High = few people can reach everyone quickly (central positions)
#'
#' \strong{Eigenvector Centralization:} How unequal is influence?
#' High = few people connected to other influential people (elite)
#'
#' Formula: C = sum(max_centrality - node_centrality) / theoretical_max
#'
#' @examples
#' \dontrun{
#' # Calculate all centralization measures
#' cent <- calculate_network_centralization(g)
#' print(cent$interpretation)
#'
#' # Compare teams
#' cent <- calculate_network_centralization(
#'   g,
#'   team_attr = "department"
#' )
#' print(cent$team_centralization)
#'
#' # Focus on degree centralization
#' cent <- calculate_network_centralization(
#'   g,
#'   measures = "degree"
#' )
#' }
#'
#' @importFrom igraph vcount degree betweenness closeness eigen_centrality is_directed
#' @importFrom igraph induced_subgraph V
#' @importFrom dplyr group_by summarise arrange desc
#' @importFrom tibble tibble
#'
#' @export
calculate_network_centralization <- function(g,
                                             measures = c("all", "degree", "betweenness", 
                                                         "closeness", "eigenvector"),
                                             mode = c("all", "out", "in"),
                                             team_attr = NULL,
                                             weight_var = NULL) {
  
  if (!inherits(g, "igraph")) {
    stop("`g` must be an igraph object.")
  }
  
  if (!"name" %in% igraph::vertex_attr_names(g)) {
    stop("Graph must have a 'name' vertex attribute.")
  }
  
  measures <- match.arg(measures, several.ok = TRUE)
  if ("all" %in% measures) {
    measures <- c("degree", "betweenness", "closeness", "eigenvector")
  }
  
  mode <- match.arg(mode)
  
  # Handle weights
  weights <- NULL
  if (!is.null(weight_var) && weight_var %in% igraph::edge_attr_names(g)) {
    weights <- igraph::E(g)[[weight_var]]
  }
  
  cat("Calculating network centralization...\n")
  
  n <- igraph::vcount(g)
  node_names <- igraph::V(g)$name
  is_dir <- igraph::is_directed(g)
  
  # Calculate centrality scores for each node
  node_centrality <- tibble::tibble(node = node_names)
  
  centralization_scores <- list()
  
  # Degree centralization
  if ("degree" %in% measures) {
    deg <- igraph::degree(g, mode = mode)
    node_centrality$degree <- deg
    
    max_deg <- max(deg)
    sum_diff <- sum(max_deg - deg)
    
    # Theoretical maximum for star network
    if (is_dir && mode == "all") {
      max_possible <- (n - 1) * (n - 2)
    } else if (is_dir) {
      max_possible <- (n - 1)^2
    } else {
      max_possible <- (n - 1) * (n - 2)
    }
    
    centralization_scores$degree <- sum_diff / max_possible
  }
  
  # Betweenness centralization
  if ("betweenness" %in% measures) {
    btw <- igraph::betweenness(g, directed = is_dir, weights = weights)
    node_centrality$betweenness <- btw
    
    max_btw <- max(btw)
    sum_diff <- sum(max_btw - btw)
    
    # Theoretical maximum
    if (is_dir) {
      max_possible <- (n - 1)^2 * (n - 2)
    } else {
      max_possible <- (n - 1)^2 * (n - 2) / 2
    }
    
    centralization_scores$betweenness <- sum_diff / max_possible
  }
  
  # Closeness centralization
  if ("closeness" %in% measures) {
    clo <- igraph::closeness(g, mode = mode, weights = weights)
    clo[is.na(clo) | is.infinite(clo)] <- 0
    node_centrality$closeness <- clo
    
    max_clo <- max(clo)
    sum_diff <- sum(max_clo - clo)
    
    # Theoretical maximum (star network)
    if (n > 2) {
      star_center <- (n - 1) / (n - 1)  # = 1
      star_periphery <- (n - 1) / (2*n - 3)
      max_possible <- (star_center - star_periphery) * (n - 1)
      
      centralization_scores$closeness <- sum_diff / max_possible
    } else {
      centralization_scores$closeness <- 0
    }
  }
  
  # Eigenvector centralization
  if ("eigenvector" %in% measures) {
    eig <- tryCatch({
      igraph::eigen_centrality(g, directed = is_dir, weights = weights)$vector
    }, error = function(e) {
      rep(0, n)
    })
    node_centrality$eigenvector <- eig
    
    max_eig <- max(eig)
    sum_diff <- sum(max_eig - eig)
    
    # Theoretical maximum (star network)
    if (n > 2) {
      max_possible <- sqrt(n - 1) * (sqrt(n - 1) - 1)
      centralization_scores$eigenvector <- sum_diff / max_possible
    } else {
      centralization_scores$eigenvector <- 0
    }
  }
  
  # Team-level analysis
  team_centralization <- NULL
  if (!is.null(team_attr)) {
    cat("Calculating team-level centralization...\n")
    team_centralization <- calculate_team_centralization(g, team_attr, measures, mode, weights)
  }
  
  # Generate interpretation
  interpretation <- interpret_centralization(centralization_scores, team_centralization)
  
  # Compare to theoretical extremes
  comparison <- compare_to_extremes(centralization_scores, n)
  
  output <- list(
    network_centralization = centralization_scores,
    node_centrality = node_centrality,
    team_centralization = team_centralization,
    interpretation = interpretation,
    comparison = comparison,
    n_nodes = n,
    is_directed = is_dir
  )
  
  class(output) <- c("network_centralization", "list")
  return(output)
}

# Helper: Calculate team-level centralization
calculate_team_centralization <- function(g, team_attr, measures, mode, weights) {
  nodes <- igraph::as_data_frame(g, what = "vertices")
  
  if (!team_attr %in% names(nodes)) {
    stop("team_attr '", team_attr, "' not found in vertex attributes.")
  }
  
  teams <- unique(nodes[[team_attr]][!is.na(nodes[[team_attr]])])
  
  team_results <- lapply(teams, function(team) {
    team_members <- nodes$name[nodes[[team_attr]] == team]
    team_idx <- which(igraph::V(g)$name %in% team_members)
    
    if (length(team_idx) < 3) {
      return(NULL)  # Need at least 3 nodes for meaningful centralization
    }
    
    # Create subgraph for this team
    g_team <- igraph::induced_subgraph(g, team_idx)
    
    # Calculate centralization for this team
    team_cent <- calculate_network_centralization(
      g_team,
      measures = measures,
      mode = mode,
      weight_var = NULL  # Already filtered
    )
    
    result <- tibble::tibble(
      team = team,
      n_members = length(team_members)
    )
    
    for (measure in names(team_cent$network_centralization)) {
      result[[paste0(measure, "_centralization")]] <- team_cent$network_centralization[[measure]]
    }
    
    result
  })
  
  team_results <- team_results[!sapply(team_results, is.null)]
  do.call(rbind, team_results)
}

# Helper: Interpret centralization scores
interpret_centralization <- function(centralization_scores, team_centralization) {
  interp <- character()
  
  for (measure in names(centralization_scores)) {
    score <- centralization_scores[[measure]]
    
    level <- if (score < 0.2) {
      "very low (decentralized/flat)"
    } else if (score < 0.4) {
      "low to moderate"
    } else if (score < 0.6) {
      "moderate"
    } else if (score < 0.8) {
      "high"
    } else {
      "very high (centralized/hierarchical)"
    }
    
    meaning <- switch(
      measure,
      degree = "Connection distribution",
      betweenness = "Brokerage/gatekeeping",
      closeness = "Access to others",
      eigenvector = "Influence distribution"
    )
    
    interp <- c(interp, paste0(
      toupper(measure), " centralization: ", round(score, 3), " (", level, ")\n",
      "  → ", meaning, " is ", 
      if (score > 0.5) "concentrated in few nodes" else "distributed across network"
    ))
  }
  
  # Overall assessment
  avg_score <- mean(unlist(centralization_scores))
  
  interp <- c(interp, "\n=== Overall Assessment ===")
  
  if (avg_score < 0.3) {
    interp <- c(interp, 
                "Network is DECENTRALIZED (flat structure)",
                "• Pros: Resilient, distributed decision-making, less bottlenecks",
                "• Cons: Slower coordination, potential for silos",
                "• Recommendation: Good for innovation, may need coordination mechanisms")
  } else if (avg_score < 0.6) {
    interp <- c(interp,
                "Network has MODERATE centralization (balanced structure)",
                "• Mix of central coordinators and distributed connections",
                "• Recommendation: Monitor for bottlenecks while maintaining flexibility")
  } else {
    interp <- c(interp,
                "Network is CENTRALIZED (hierarchical structure)",
                "• Pros: Fast coordination, clear authority",
                "• Cons: Bottlenecks, single points of failure, slower innovation",
                "• Recommendation: Consider distributing connections to reduce vulnerability")
  }
  
  # Team comparison
  if (!is.null(team_centralization)) {
    interp <- c(interp, "\n=== Team Comparison ===")
    
    # Find most and least centralized teams
    if ("degree_centralization" %in% names(team_centralization)) {
      most_cent <- team_centralization[which.max(team_centralization$degree_centralization), ]
      least_cent <- team_centralization[which.min(team_centralization$degree_centralization), ]
      
      interp <- c(interp,
                  paste0("Most centralized: ", most_cent$team, 
                         " (", round(most_cent$degree_centralization, 3), ")"),
                  paste0("Least centralized: ", least_cent$team,
                         " (", round(least_cent$degree_centralization, 3), ")"))
    }
  }
  
  interp
}

# Helper: Compare to theoretical extremes
compare_to_extremes <- function(centralization_scores, n) {
  comparisons <- list()
  
  for (measure in names(centralization_scores)) {
    score <- centralization_scores[[measure]]
    
    # Star network has centralization = 1
    # Circle network has centralization ≈ 0
    
    pct_to_star <- score * 100
    pct_to_circle <- (1 - score) * 100
    
    comparisons[[measure]] <- tibble::tibble(
      measure = measure,
      score = score,
      similarity_to_star = paste0(round(pct_to_star, 1), "%"),
      similarity_to_circle = paste0(round(pct_to_circle, 1), "%"),
      interpretation = if (score > 0.7) {
        "Resembles star network (hub-and-spoke)"
      } else if (score < 0.3) {
        "Resembles circle network (distributed)"
      } else {
        "Between star and circle (mixed structure)"
      }
    )
  }
  
  do.call(rbind, comparisons)
}

# Print method
#' @export
print.network_centralization <- function(x, ...) {
  cat("=== Network Centralization Analysis ===\n\n")
  cat("Network size:", x$n_nodes, "nodes\n")
  cat("Directed:", x$is_directed, "\n\n")
  
  cat("Centralization Scores (0 = decentralized, 1 = centralized):\n")
  for (measure in names(x$network_centralization)) {
    cat(sprintf("  %-15s: %.3f\n", measure, x$network_centralization[[measure]]))
  }
  
  cat("\n")
  cat(paste(x$interpretation, collapse = "\n"))
  
  if (!is.null(x$team_centralization)) {
    cat("\n\n=== Team Centralization ===\n")
    print(x$team_centralization)
  }
  
  cat("\n\n=== Comparison to Theoretical Networks ===\n")
  print(x$comparison)
  
  invisible(x)
}
