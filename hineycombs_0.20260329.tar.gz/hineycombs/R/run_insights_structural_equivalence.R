#' Identify structurally equivalent nodes (similar roles/positions)
#'
#' @description
#' Finds nodes that occupy similar structural positions in the network, even if
#' they're not directly connected. Structurally equivalent nodes have similar
#' patterns of connections to the same third parties.
#'
#' Practical uses:
#' \itemize{
#'   \item Find people in similar roles (e.g., all project managers, all team leads)
#'   \item Identify redundant positions
#'   \item Discover informal role structures
#'   \item Find substitutable employees
#'   \item Benchmark performance across similar positions
#' }
#'
#' @param g An igraph object. Must have a \code{name} vertex attribute.
#' @param method Character string: "euclidean" (default), "correlation", "cosine",
#'   or "jaccard". Method for calculating structural similarity.
#' @param mode For directed graphs: "all", "in", or "out". Which ties to consider.
#' @param min_similarity Minimum similarity threshold (0-1) to include in results.
#'   Default is 0.5.
#' @param top_n For each node, return only the top N most similar nodes. Default is 5.
#' @param cluster_roles Logical. If TRUE, uses hierarchical clustering to identify
#'   role groups. Default is TRUE.
#' @param n_roles Number of role clusters to identify. If NULL, uses optimal number.
#' @param weight_var Optional edge attribute name for weights.
#'
#' @return A list containing:
#' \describe{
#'   \item{similarity_matrix}{Matrix of structural similarity scores (0-1)}
#'   \item{similar_pairs}{Data frame of node pairs with high similarity}
#'   \item{role_assignments}{Data frame assigning each node to a role cluster}
#'   \item{role_profiles}{Characteristics of each role cluster}
#'   \item{substitutability}{For each node, who could substitute for them}
#' }
#'
#' @details
#' Structural equivalence measures:
#'
#' \strong{Euclidean distance:} Nodes are similar if they connect to the same alters
#' with similar strength. Good for weighted networks.
#'
#' \strong{Correlation:} Nodes are similar if their connection patterns are correlated.
#' Good for finding similar roles regardless of activity level.
#'
#' \strong{Cosine similarity:} Nodes are similar if they connect to the same alters,
#' normalized by their total activity. Good for comparing active vs inactive nodes.
#'
#' \strong{Jaccard:} Nodes are similar if they share many of the same connections.
#' Good for binary networks.
#'
#' Role clustering uses hierarchical clustering on the similarity matrix to identify
#' groups of structurally equivalent nodes (e.g., "managers", "individual contributors",
#' "boundary spanners").
#'
#' @examples
#' \dontrun{
#' # Find people in similar roles
#' equiv <- run_insights_structural_equivalence(g)
#' print(equiv$role_assignments)
#'
#' # Find who could substitute for key employees
#' print(equiv$substitutability)
#'
#' # Use correlation for role similarity
#' equiv <- run_insights_structural_equivalence(
#'   g,
#'   method = "correlation",
#'   n_roles = 5
#' )
#' }
#'
#' @importFrom igraph as_adjacency_matrix vcount V is_directed
#' @importFrom stats dist hclust cutree cor
#' @importFrom dplyr arrange desc filter
#' @importFrom tibble tibble
#'
#' @export
run_insights_structural_equivalence <- function(g,
                                                method = c("euclidean", "correlation", 
                                                          "cosine", "jaccard"),
                                                mode = c("all", "out", "in"),
                                                min_similarity = 0.5,
                                                top_n = 5,
                                                cluster_roles = TRUE,
                                                n_roles = NULL,
                                                weight_var = NULL) {
  
  if (!inherits(g, "igraph")) {
    stop("`g` must be an igraph object.")
  }
  
  if (!"name" %in% igraph::vertex_attr_names(g)) {
    stop("Graph must have a 'name' vertex attribute.")
  }
  
  method <- match.arg(method)
  mode <- match.arg(mode)
  
  cat("Calculating structural equivalence using", method, "method...\n")
  
  # Get adjacency matrix
  if (!is.null(weight_var) && weight_var %in% igraph::edge_attr_names(g)) {
    adj <- as.matrix(igraph::as_adjacency_matrix(g, attr = weight_var))
  } else {
    adj <- as.matrix(igraph::as_adjacency_matrix(g))
  }
  
  # For directed graphs, consider mode
  if (igraph::is_directed(g)) {
    if (mode == "in") {
      adj <- t(adj)  # Transpose to get incoming ties
    } else if (mode == "out") {
      # Keep as is
    } else {
      # Combine in and out
      adj <- adj + t(adj)
    }
  }
  
  n <- nrow(adj)
  node_names <- igraph::V(g)$name
  
  # Calculate similarity matrix
  sim_matrix <- calculate_similarity(adj, method)
  rownames(sim_matrix) <- node_names
  colnames(sim_matrix) <- node_names
  
  # Convert similarity to distance for clustering
  dist_matrix <- 1 - sim_matrix
  diag(dist_matrix) <- 0
  
  # Find similar pairs
  cat("Identifying similar node pairs...\n")
  similar_pairs <- extract_similar_pairs(sim_matrix, node_names, min_similarity, top_n)
  
  # Cluster into roles
  role_assignments <- NULL
  role_profiles <- NULL
  
  if (cluster_roles) {
    cat("Clustering nodes into role groups...\n")
    
    # Hierarchical clustering
    dist_obj <- stats::as.dist(dist_matrix)
    hc <- stats::hclust(dist_obj, method = "ward.D2")
    
    # Determine number of clusters
    if (is.null(n_roles)) {
      # Use elbow method or silhouette
      n_roles <- determine_optimal_roles(dist_obj, max_k = min(10, n - 1))
    }
    
    clusters <- stats::cutree(hc, k = n_roles)
    
    # Create role assignments
    role_assignments <- tibble::tibble(
      node = node_names,
      role = paste0("Role_", clusters),
      role_id = clusters
    )
    
    # Calculate role profiles
    role_profiles <- calculate_role_profiles(g, role_assignments, adj)
  }
  
  # Identify substitutability
  cat("Calculating substitutability...\n")
  substitutability <- calculate_substitutability(sim_matrix, node_names, top_n)
  
  output <- list(
    similarity_matrix = sim_matrix,
    similar_pairs = similar_pairs,
    role_assignments = role_assignments,
    role_profiles = role_profiles,
    substitutability = substitutability,
    method = method,
    n_roles = n_roles
  )
  
  class(output) <- c("structural_equivalence", "list")
  return(output)
}

# Helper: Calculate similarity matrix
calculate_similarity <- function(adj, method) {
  n <- nrow(adj)
  sim_matrix <- matrix(0, n, n)
  
  if (method == "euclidean") {
    # Euclidean distance, converted to similarity
    for (i in 1:n) {
      for (j in 1:n) {
        if (i == j) {
          sim_matrix[i, j] <- 1
        } else {
          dist <- sqrt(sum((adj[i, ] - adj[j, ])^2))
          # Convert to similarity (0-1 scale)
          max_dist <- sqrt(sum(adj[i, ]^2) + sum(adj[j, ]^2))
          sim_matrix[i, j] <- 1 - (dist / (max_dist + 0.001))
        }
      }
    }
  } else if (method == "correlation") {
    # Pearson correlation
    sim_matrix <- stats::cor(t(adj))
    sim_matrix[is.na(sim_matrix)] <- 0
    # Convert to 0-1 scale
    sim_matrix <- (sim_matrix + 1) / 2
  } else if (method == "cosine") {
    # Cosine similarity
    for (i in 1:n) {
      for (j in 1:n) {
        if (i == j) {
          sim_matrix[i, j] <- 1
        } else {
          dot_prod <- sum(adj[i, ] * adj[j, ])
          norm_i <- sqrt(sum(adj[i, ]^2))
          norm_j <- sqrt(sum(adj[j, ]^2))
          if (norm_i > 0 && norm_j > 0) {
            sim_matrix[i, j] <- dot_prod / (norm_i * norm_j)
          }
        }
      }
    }
  } else if (method == "jaccard") {
    # Jaccard similarity (for binary networks)
    adj_binary <- (adj > 0) * 1
    for (i in 1:n) {
      for (j in 1:n) {
        if (i == j) {
          sim_matrix[i, j] <- 1
        } else {
          intersection <- sum(adj_binary[i, ] & adj_binary[j, ])
          union <- sum(adj_binary[i, ] | adj_binary[j, ])
          if (union > 0) {
            sim_matrix[i, j] <- intersection / union
          }
        }
      }
    }
  }
  
  sim_matrix
}

# Helper: Extract similar pairs
extract_similar_pairs <- function(sim_matrix, node_names, min_similarity, top_n) {
  n <- nrow(sim_matrix)
  pairs <- list()
  
  for (i in 1:(n-1)) {
    for (j in (i+1):n) {
      if (sim_matrix[i, j] >= min_similarity) {
        pairs[[length(pairs) + 1]] <- data.frame(
          node1 = node_names[i],
          node2 = node_names[j],
          similarity = sim_matrix[i, j],
          stringsAsFactors = FALSE
        )
      }
    }
  }
  
  if (length(pairs) == 0) {
    return(data.frame(
      node1 = character(),
      node2 = character(),
      similarity = numeric(),
      stringsAsFactors = FALSE
    ))
  }
  
  result <- do.call(rbind, pairs)
  result <- dplyr::arrange(result, dplyr::desc(similarity))
  result
}

# Helper: Determine optimal number of roles
determine_optimal_roles <- function(dist_obj, max_k = 10) {
  # Use silhouette method
  if (!requireNamespace("cluster", quietly = TRUE)) {
    return(3)  # Default
  }
  
  sil_scores <- numeric(max_k - 1)
  
  for (k in 2:max_k) {
    hc <- stats::hclust(dist_obj, method = "ward.D2")
    clusters <- stats::cutree(hc, k = k)
    sil <- cluster::silhouette(clusters, dist_obj)
    sil_scores[k - 1] <- mean(sil[, 3])
  }
  
  # Return k with highest silhouette score
  which.max(sil_scores) + 1
}

# Helper: Calculate role profiles
calculate_role_profiles <- function(g, role_assignments, adj) {
  roles <- unique(role_assignments$role)
  
  profiles <- lapply(roles, function(role) {
    members <- role_assignments$node[role_assignments$role == role]
    member_idx <- match(members, igraph::V(g)$name)
    
    # Calculate average characteristics
    avg_degree <- mean(rowSums(adj[member_idx, , drop = FALSE]))
    avg_betweenness <- mean(igraph::betweenness(g, v = member_idx))
    
    tibble::tibble(
      role = role,
      n_members = length(members),
      avg_degree = avg_degree,
      avg_betweenness = avg_betweenness,
      example_members = paste(head(members, 3), collapse = ", ")
    )
  })
  
  do.call(rbind, profiles)
}

# Helper: Calculate substitutability
calculate_substitutability <- function(sim_matrix, node_names, top_n) {
  n <- nrow(sim_matrix)
  
  subs <- lapply(1:n, function(i) {
    # Get similarities for this node (excluding self)
    sims <- sim_matrix[i, -i]
    names(sims) <- node_names[-i]
    
    # Get top N
    top_idx <- order(-sims)[1:min(top_n, length(sims))]
    top_nodes <- names(sims)[top_idx]
    top_sims <- sims[top_idx]
    
    tibble::tibble(
      node = node_names[i],
      substitute = top_nodes,
      similarity = top_sims,
      rank = 1:length(top_nodes)
    )
  })
  
  do.call(rbind, subs)
}

# Print method
#' @export
print.structural_equivalence <- function(x, ...) {
  cat("=== Structural Equivalence Analysis ===\n\n")
  cat("Method:", x$method, "\n")
  cat("Nodes analyzed:", nrow(x$similarity_matrix), "\n\n")
  
  if (!is.null(x$role_assignments)) {
    cat("Role Clusters:", x$n_roles, "\n\n")
    cat("Role Profiles:\n")
    print(x$role_profiles)
    cat("\n")
  }
  
  cat("Most Similar Pairs (Top 10):\n")
  print(head(x$similar_pairs, 10))
  
  cat("\n=== Substitutability ===\n")
  cat("Sample substitutes for first 3 nodes:\n")
  sample_nodes <- unique(x$substitutability$node)[1:min(3, length(unique(x$substitutability$node)))]
  for (node in sample_nodes) {
    subs <- x$substitutability[x$substitutability$node == node, ]
    cat("\n", node, "could be substituted by:\n")
    print(head(subs[, c("substitute", "similarity")], 3))
  }
  
  invisible(x)
}
