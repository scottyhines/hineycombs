#' QAP and MRQAP tests for network data
#'
#' @description
#' Quadratic Assignment Procedure (QAP) tests hypotheses about relationships between
#' networks or between networks and attributes, accounting for network autocorrelation.
#' MRQAP (Multiple Regression QAP) tests multiple predictors simultaneously.
#'
#' Practical uses:
#' \itemize{
#'   \item Test if advice network predicts friendship network
#'   \item Test if similarity (age, gender, location) predicts collaboration
#'   \item Test if formal reporting structure matches informal communication
#'   \item Control for confounds in network regression
#'   \item Validate network theories with proper statistical tests
#' }
#'
#' @param dependent_network Igraph object or adjacency matrix. The outcome network.
#' @param independent_networks List of igraph objects or matrices. Predictor networks.
#' @param independent_attributes Optional data frame of node attributes to test.
#'   Creates similarity/difference matrices automatically.
#' @param attribute_types Named vector specifying how to handle each attribute:
#'   "match" (same/different), "absdiff" (absolute difference), "euclidean" (distance).
#' @param test_type Character: "correlation" for QAP correlation, "regression" for MRQAP.
#'   Default is "regression" if multiple predictors, "correlation" otherwise.
#' @param n_permutations Number of permutations for significance testing. Default 1000.
#' @param directed Logical. Are networks directed? Default TRUE.
#' @param diagonal Logical. Include diagonal (self-loops)? Default FALSE.
#'
#' @return A list containing:
#' \describe{
#'   \item{coefficients}{Regression coefficients or correlations}
#'   \item{p_values}{Permutation-based p-values}
#'   \item{r_squared}{R-squared for regression models}
#'   \item{observed_stats}{Observed test statistics}
#'   \item{null_distribution}{Distribution of statistics under null hypothesis}
#'   \item{interpretation}{Plain English interpretation}
#' }
#'
#' @details
#' QAP addresses the problem that network data violates independence assumptions
#' of standard statistics. Rows and columns of adjacency matrices are not independent.
#'
#' \strong{QAP Correlation:}
#' Tests if two networks are correlated by permuting rows/columns together and
#' recalculating correlation. P-value = proportion of permutations with correlation
#' as extreme as observed.
#'
#' \strong{MRQAP Regression:}
#' Tests multiple predictors of a network outcome. Permutes dependent network and
#' recalculates regression. Provides coefficients and p-values for each predictor.
#'
#' \strong{Attribute Matrices:}
#' Automatically creates matrices from node attributes:
#' \itemize{
#'   \item match: 1 if same value, 0 if different (for categorical)
#'   \item absdiff: Absolute difference (for continuous)
#'   \item euclidean: Euclidean distance across multiple attributes
#' }
#'
#' \strong{Interpretation:}
#' \itemize{
#'   \item p < 0.05: Significant relationship (reject null hypothesis)
#'   \item Positive coefficient: Predictor increases tie probability
#'   \item Negative coefficient: Predictor decreases tie probability
#' }
#'
#' @examples
#' \dontrun{
#' # Test if advice network predicts friendship
#' qap_result <- run_insights_qap_test(
#'   dependent_network = friendship_network,
#'   independent_networks = list(advice = advice_network),
#'   n_permutations = 1000
#' )
#'
#' # Test if similarity predicts collaboration
#' qap_result <- run_insights_qap_test(
#'   dependent_network = collab_network,
#'   independent_attributes = node_data,
#'   attribute_types = c(
#'     department = "match",
#'     age = "absdiff",
#'     tenure = "absdiff"
#'   )
#' )
#'
#' # Multiple predictors (MRQAP)
#' qap_result <- run_insights_qap_test(
#'   dependent_network = communication,
#'   independent_networks = list(
#'     advice = advice_network,
#'     friendship = friendship_network
#'   ),
#'   independent_attributes = node_data,
#'   attribute_types = c(location = "match", age = "absdiff")
#' )
#' }
#'
#' @importFrom igraph as_adjacency_matrix vcount V
#' @importFrom stats cor lm coef
#' @importFrom tibble tibble
#'
#' @export
run_stats_qap_test <- function(dependent_network,
                                  independent_networks = NULL,
                                  independent_attributes = NULL,
                                  attribute_types = NULL,
                                  test_type = c("auto", "correlation", "regression"),
                                  n_permutations = 1000,
                                  directed = TRUE,
                                  diagonal = FALSE) {
  
  test_type <- match.arg(test_type)
  
  cat("=== QAP/MRQAP Network Analysis ===\n\n")
  
  # Convert dependent network to matrix
  if (inherits(dependent_network, "igraph")) {
    dep_mat <- as.matrix(igraph::as_adjacency_matrix(dependent_network))
  } else {
    dep_mat <- as.matrix(dependent_network)
  }
  
  n <- nrow(dep_mat)
  
  # Remove diagonal if requested
  if (!diagonal) {
    diag(dep_mat) <- NA
  }
  
  # Convert to vector (excluding NA)
  dep_vec <- as.vector(dep_mat)
  dep_vec <- dep_vec[!is.na(dep_vec)]
  
  # Build independent matrices
  indep_matrices <- list()
  indep_names <- character()
  
  # From networks
  if (!is.null(independent_networks)) {
    for (i in seq_along(independent_networks)) {
      net <- independent_networks[[i]]
      name <- names(independent_networks)[i]
      if (is.null(name) || name == "") name <- paste0("Network_", i)
      
      if (inherits(net, "igraph")) {
        mat <- as.matrix(igraph::as_adjacency_matrix(net))
      } else {
        mat <- as.matrix(net)
      }
      
      if (!diagonal) diag(mat) <- NA
      
      indep_matrices[[name]] <- mat
      indep_names <- c(indep_names, name)
    }
  }
  
  # From attributes
  if (!is.null(independent_attributes)) {
    cat("Creating attribute matrices...\n")
    
    for (attr_name in names(attribute_types)) {
      if (!attr_name %in% names(independent_attributes)) {
        warning("Attribute '", attr_name, "' not found in data. Skipping.")
        next
      }
      
      attr_values <- independent_attributes[[attr_name]]
      attr_type <- attribute_types[attr_name]
      
      mat <- create_attribute_matrix(attr_values, attr_type, n)
      
      if (!diagonal) diag(mat) <- NA
      
      indep_matrices[[attr_name]] <- mat
      indep_names <- c(indep_names, attr_name)
    }
  }
  
  if (length(indep_matrices) == 0) {
    stop("No independent variables provided.")
  }
  
  # Convert independent matrices to vectors
  indep_vecs <- lapply(indep_matrices, function(mat) {
    vec <- as.vector(mat)
    vec[!is.na(vec)]
  })
  
  # Determine test type
  if (test_type == "auto") {
    test_type <- if (length(indep_matrices) == 1) "correlation" else "regression"
  }
  
  cat("Running", test_type, "test with", n_permutations, "permutations...\n")
  
  # Run appropriate test
  if (test_type == "correlation") {
    result <- qap_correlation(dep_vec, indep_vecs[[1]], dep_mat, indep_matrices[[1]], 
                             n_permutations, indep_names[1])
  } else {
    result <- mrqap_regression(dep_vec, indep_vecs, dep_mat, indep_matrices, 
                              n_permutations, indep_names)
  }
  
  # Add interpretation
  result$interpretation <- interpret_qap_results(result, test_type)
  
  result$test_type <- test_type
  result$n_permutations <- n_permutations
  result$n_nodes <- n
  
  class(result) <- c("qap_test", "list")
  return(result)
}

# Helper: Create attribute matrix
create_attribute_matrix <- function(attr_values, attr_type, n) {
  mat <- matrix(0, n, n)
  
  if (attr_type == "match") {
    # 1 if same, 0 if different
    for (i in 1:n) {
      for (j in 1:n) {
        mat[i, j] <- as.numeric(attr_values[i] == attr_values[j])
      }
    }
  } else if (attr_type == "absdiff") {
    # Absolute difference
    for (i in 1:n) {
      for (j in 1:n) {
        mat[i, j] <- abs(as.numeric(attr_values[i]) - as.numeric(attr_values[j]))
      }
    }
  } else if (attr_type == "euclidean") {
    # Euclidean distance (for multiple attributes)
    for (i in 1:n) {
      for (j in 1:n) {
        mat[i, j] <- sqrt(sum((attr_values[i, ] - attr_values[j, ])^2))
      }
    }
  }
  
  mat
}

# Helper: QAP correlation
qap_correlation <- function(dep_vec, indep_vec, dep_mat, indep_mat, n_perm, var_name) {
  
  # Observed correlation
  obs_cor <- stats::cor(dep_vec, indep_vec, use = "complete.obs")
  
  # Permutation distribution
  perm_cors <- numeric(n_perm)
  
  pb <- txtProgressBar(min = 0, max = n_perm, style = 3)
  
  for (i in 1:n_perm) {
    # Permute rows and columns of dependent matrix
    perm_order <- sample(nrow(dep_mat))
    dep_perm <- dep_mat[perm_order, perm_order]
    
    dep_perm_vec <- as.vector(dep_perm)
    dep_perm_vec <- dep_perm_vec[!is.na(dep_perm_vec)]
    
    perm_cors[i] <- stats::cor(dep_perm_vec, indep_vec, use = "complete.obs")
    
    setTxtProgressBar(pb, i)
  }
  
  close(pb)
  
  # Calculate p-value (two-tailed)
  p_value <- mean(abs(perm_cors) >= abs(obs_cor))
  
  list(
    observed_correlation = obs_cor,
    p_value = p_value,
    null_distribution = perm_cors,
    variable_name = var_name
  )
}

# Helper: MRQAP regression
mrqap_regression <- function(dep_vec, indep_vecs, dep_mat, indep_matrices, n_perm, var_names) {
  
  # Observed regression
  data_obs <- data.frame(y = dep_vec)
  for (i in seq_along(indep_vecs)) {
    data_obs[[var_names[i]]] <- indep_vecs[[i]]
  }
  
  formula_str <- paste("y ~", paste(var_names, collapse = " + "))
  obs_model <- stats::lm(as.formula(formula_str), data = data_obs)
  obs_coefs <- stats::coef(obs_model)
  obs_r2 <- summary(obs_model)$r.squared
  
  # Permutation distribution
  perm_coefs <- matrix(0, n_perm, length(obs_coefs))
  colnames(perm_coefs) <- names(obs_coefs)
  
  pb <- txtProgressBar(min = 0, max = n_perm, style = 3)
  
  for (i in 1:n_perm) {
    # Permute dependent matrix
    perm_order <- sample(nrow(dep_mat))
    dep_perm <- dep_mat[perm_order, perm_order]
    
    dep_perm_vec <- as.vector(dep_perm)
    dep_perm_vec <- dep_perm_vec[!is.na(dep_perm_vec)]
    
    data_perm <- data.frame(y = dep_perm_vec)
    for (j in seq_along(indep_vecs)) {
      data_perm[[var_names[j]]] <- indep_vecs[[j]]
    }
    
    perm_model <- stats::lm(as.formula(formula_str), data = data_perm)
    perm_coefs[i, ] <- stats::coef(perm_model)
    
    setTxtProgressBar(pb, i)
  }
  
  close(pb)
  
  # Calculate p-values
  p_values <- sapply(1:length(obs_coefs), function(j) {
    mean(abs(perm_coefs[, j]) >= abs(obs_coefs[j]))
  })
  
  # Build results table
  results_table <- tibble::tibble(
    variable = names(obs_coefs),
    coefficient = obs_coefs,
    p_value = p_values,
    significant = p_values < 0.05
  )
  
  list(
    coefficients = results_table,
    r_squared = obs_r2,
    observed_model = obs_model,
    null_distribution = perm_coefs,
    variable_names = var_names
  )
}

# Helper: Interpret results
interpret_qap_results <- function(result, test_type) {
  interp <- character()
  
  if (test_type == "correlation") {
    interp <- c(interp, "=== QAP CORRELATION TEST ===")
    interp <- c(interp, sprintf("Variable: %s", result$variable_name))
    interp <- c(interp, sprintf("Observed correlation: %.3f", result$observed_correlation))
    interp <- c(interp, sprintf("P-value: %.4f", result$p_value))
    
    if (result$p_value < 0.001) {
      sig <- "***"
    } else if (result$p_value < 0.01) {
      sig <- "**"
    } else if (result$p_value < 0.05) {
      sig <- "*"
    } else {
      sig <- "ns"
    }
    
    interp <- c(interp, sprintf("Significance: %s", sig))
    interp <- c(interp, "")
    
    if (result$p_value < 0.05) {
      direction <- if (result$observed_correlation > 0) "positive" else "negative"
      strength <- if (abs(result$observed_correlation) > 0.5) {
        "strong"
      } else if (abs(result$observed_correlation) > 0.3) {
        "moderate"
      } else {
        "weak"
      }
      
      interp <- c(interp, paste0("SIGNIFICANT ", strength, " ", direction, " relationship"))
      interp <- c(interp, "The networks are significantly correlated.")
    } else {
      interp <- c(interp, "NOT SIGNIFICANT")
      interp <- c(interp, "No significant relationship detected.")
    }
    
  } else {
    interp <- c(interp, "=== MRQAP REGRESSION TEST ===")
    interp <- c(interp, sprintf("R-squared: %.3f", result$r_squared))
    interp <- c(interp, sprintf("Model explains %.1f%% of variance", result$r_squared * 100))
    interp <- c(interp, "")
    
    sig_vars <- result$coefficients[result$coefficients$significant, ]
    
    if (nrow(sig_vars) > 0) {
      interp <- c(interp, "SIGNIFICANT PREDICTORS:")
      for (i in 1:nrow(sig_vars)) {
        var <- sig_vars$variable[i]
        coef <- sig_vars$coefficient[i]
        p <- sig_vars$p_value[i]
        
        if (var == "(Intercept)") next
        
        direction <- if (coef > 0) "increases" else "decreases"
        interp <- c(interp, sprintf("• %s: %.3f (p = %.4f) - %s tie probability",
                                    var, coef, p, direction))
      }
    } else {
      interp <- c(interp, "No significant predictors found.")
    }
    
    interp <- c(interp, "")
    interp <- c(interp, "=== INTERPRETATION ===")
    
    if (nrow(sig_vars) > 0) {
      interp <- c(interp, "The model identifies significant network predictors.")
      interp <- c(interp, "These relationships hold after controlling for network autocorrelation.")
    } else {
      interp <- c(interp, "No significant relationships detected.")
      interp <- c(interp, "Predictors do not explain network structure beyond chance.")
    }
  }
  
  interp
}

# Print method
#' @export
print.qap_test <- function(x, ...) {
  cat("=== QAP/MRQAP Test Results ===\n\n")
  cat("Test type:", x$test_type, "\n")
  cat("Permutations:", x$n_permutations, "\n")
  cat("Network size:", x$n_nodes, "nodes\n\n")
  
  if (x$test_type == "correlation") {
    cat("Observed correlation:", round(x$observed_correlation, 3), "\n")
    cat("P-value:", round(x$p_value, 4), "\n")
  } else {
    cat("R-squared:", round(x$r_squared, 3), "\n\n")
    cat("Coefficients:\n")
    print(x$coefficients)
  }
  
  cat("\n")
  cat(paste(x$interpretation, collapse = "\n"))
  cat("\n")
  
  invisible(x)
}
