#' Comprehensive Network Data Diagnostics
#'
#' @description
#' `check_all_diagnostics()` performs a comprehensive suite of validation checks
#' on node and edge data frames before network creation. It identifies common
#' issues that prevent successful network construction with `igraph::graph_from_data_frame()`,
#' including structural problems, data type mismatches, missing values, duplicates,
#' and inconsistencies between node and edge lists.
#'
#' @details
#' The function performs the following diagnostic checks:
#'
#' **1. Edge Structure Validation**
#' - Verifies required columns (from/to) exist
#' - Checks for NA values in edge endpoints
#' - Identifies empty strings or whitespace-only values
#' - Detects trailing/leading whitespace issues
#'
#' **2. Node Structure Validation**
#' - Verifies node ID column exists
#' - Checks for duplicate node IDs
#' - Identifies NA values in node ID column
#' - Detects empty strings in node IDs
#'
#' **3. Data Type Consistency**
#' - Ensures node IDs and edge endpoints are compatible types
#' - Identifies factor columns that may cause issues
#' - Checks for mixed numeric/character types
#'
#' **4. Node-Edge Consistency**
#' - Identifies edge endpoints not present in node list
#' - Finds orphaned nodes (in node list but not in edges)
#'
#' **5. Network Properties**
#' - Counts self-loops (edges from node to itself)
#' - Identifies multi-edges (duplicate from-to pairs)
#' - Calculates basic network statistics
#'
#' **6. Missing Value Handling**
#' - If `recode_missing = TRUE`, replaces NA values in metadata columns
#'   with "not_available" to ensure all nodes have complete metadata
#'
#' @param nodes A data frame containing node attributes. Must include a
#'   column with unique node identifiers.
#' @param edges A data frame containing edge relationships. Must include
#'   `from` and `to` columns.
#' @param node_id_col A string specifying the column name in `nodes` that
#'   contains vertex identifiers. Defaults to `"name"`.
#' @param from_col A string specifying the column name in `edges` for
#'   source nodes. Defaults to `"from"`.
#' @param to_col A string specifying the column name in `edges` for
#'   target nodes. Defaults to `"to"`.
#' @param recode_missing Logical. If TRUE, replaces NA values in node
#'   metadata columns (excluding the ID column) with "not_available".
#'   Defaults to TRUE.
#' @param exclude_cols Character vector of column names to exclude from
#'   missing value recoding. Defaults to NULL.
#'
#' @return
#' A list with the following elements:
#' \describe{
#'   \item{status}{Overall status: "PASS", "WARNING", or "CRITICAL"}
#'   \item{can_create_network}{Logical indicating if network creation should succeed}
#'   \item{critical_issues}{List of issues that will prevent network creation}
#'   \item{warnings}{List of issues that may cause problems}
#'   \item{info}{List of informational messages about the data}
#'   \item{edge_checks}{Detailed results from edge validation}
#'   \item{node_checks}{Detailed results from node validation}
#'   \item{consistency_checks}{Results from node-edge consistency checks}
#'   \item{network_properties}{Basic network statistics}
#'   \item{cleaned_nodes}{Node data frame with missing values recoded (if recode_missing=TRUE)}
#'   \item{cleaned_edges}{Edge data frame with whitespace trimmed}
#'   \item{summary_report}{Human-readable summary of all findings}
#' }
#'
#' @examples
#' \dontrun{
#' # Run comprehensive diagnostics
#' diagnostics <- check_all_diagnostics(
#'   nodes = my_nodes,
#'   edges = my_edges,
#'   node_id_col = "name",
#'   recode_missing = TRUE
#' )
#'
#' # Check if network can be created
#' if (diagnostics$can_create_network) {
#'   g <- igraph::graph_from_data_frame(
#'     diagnostics$cleaned_edges,
#'     directed = TRUE,
#'     vertices = diagnostics$cleaned_nodes
#'   )
#' } else {
#'   print(diagnostics$summary_report)
#' }
#' }
#'
#' @importFrom dplyr filter mutate across where
#' @export
check_all_diagnostics <- function(nodes,
                                   edges,
                                   node_id_col = "name",
                                   from_col = "from",
                                   to_col = "to",
                                   recode_missing = TRUE,
                                   exclude_cols = NULL) {
  
  # Initialize results
  critical_issues <- list()
  warnings <- list()
  info <- list()
  
  cat("Running comprehensive network diagnostics...\n\n")
  
  # ============================================================================
  # 1. EDGE STRUCTURE CHECKS
  # ============================================================================
  cat("1. Checking edge structure...\n")
  edge_checks <- list()
  
  # Check required columns exist
  if (!from_col %in% names(edges)) {
    critical_issues <- c(critical_issues, 
                        paste0("CRITICAL: '", from_col, "' column not found in edges"))
    edge_checks$has_from_col <- FALSE
  } else {
    edge_checks$has_from_col <- TRUE
  }
  
  if (!to_col %in% names(edges)) {
    critical_issues <- c(critical_issues,
                        paste0("CRITICAL: '", to_col, "' column not found in edges"))
    edge_checks$has_to_col <- FALSE
  } else {
    edge_checks$has_to_col <- TRUE
  }
  
  if (edge_checks$has_from_col && edge_checks$has_to_col) {
    # Check for NA values
    na_from <- sum(is.na(edges[[from_col]]))
    na_to <- sum(is.na(edges[[to_col]]))
    edge_checks$na_from_count <- na_from
    edge_checks$na_to_count <- na_to
    
    if (na_from > 0) {
      critical_issues <- c(critical_issues,
                          paste0("CRITICAL: ", na_from, " NA values in '", from_col, "' column"))
    }
    if (na_to > 0) {
      critical_issues <- c(critical_issues,
                          paste0("CRITICAL: ", na_to, " NA values in '", to_col, "' column"))
    }
    
    # Check for empty strings
    empty_from <- sum(edges[[from_col]] == "", na.rm = TRUE)
    empty_to <- sum(edges[[to_col]] == "", na.rm = TRUE)
    edge_checks$empty_from_count <- empty_from
    edge_checks$empty_to_count <- empty_to
    
    if (empty_from > 0) {
      critical_issues <- c(critical_issues,
                          paste0("CRITICAL: ", empty_from, " empty strings in '", from_col, "' column"))
    }
    if (empty_to > 0) {
      critical_issues <- c(critical_issues,
                          paste0("CRITICAL: ", empty_to, " empty strings in '", to_col, "' column"))
    }
    
    # Check for whitespace issues
    if (is.character(edges[[from_col]])) {
      whitespace_from <- sum(edges[[from_col]] != trimws(edges[[from_col]]), na.rm = TRUE)
      edge_checks$whitespace_from_count <- whitespace_from
      if (whitespace_from > 0) {
        warnings <- c(warnings,
                     paste0("WARNING: ", whitespace_from, " values in '", from_col, 
                            "' have leading/trailing whitespace"))
      }
    }
    
    if (is.character(edges[[to_col]])) {
      whitespace_to <- sum(edges[[to_col]] != trimws(edges[[to_col]]), na.rm = TRUE)
      edge_checks$whitespace_to_count <- whitespace_to
      if (whitespace_to > 0) {
        warnings <- c(warnings,
                     paste0("WARNING: ", whitespace_to, " values in '", to_col,
                            "' have leading/trailing whitespace"))
      }
    }
    
    edge_checks$total_edges <- nrow(edges)
    info <- c(info, paste0("INFO: ", nrow(edges), " total edges in edge list"))
  }
  
  # ============================================================================
  # 2. NODE STRUCTURE CHECKS
  # ============================================================================
  cat("2. Checking node structure...\n")
  node_checks <- list()
  
  # Check node ID column exists
  if (!node_id_col %in% names(nodes)) {
    critical_issues <- c(critical_issues,
                        paste0("CRITICAL: '", node_id_col, "' column not found in nodes"))
    node_checks$has_id_col <- FALSE
  } else {
    node_checks$has_id_col <- TRUE
    
    # Check for NA values in node IDs
    na_ids <- sum(is.na(nodes[[node_id_col]]))
    node_checks$na_id_count <- na_ids
    if (na_ids > 0) {
      critical_issues <- c(critical_issues,
                          paste0("CRITICAL: ", na_ids, " NA values in node ID column '", 
                                 node_id_col, "'"))
    }
    
    # Check for empty strings in node IDs
    empty_ids <- sum(nodes[[node_id_col]] == "", na.rm = TRUE)
    node_checks$empty_id_count <- empty_ids
    if (empty_ids > 0) {
      critical_issues <- c(critical_issues,
                          paste0("CRITICAL: ", empty_ids, " empty strings in node ID column"))
    }
    
    # Check for duplicate node IDs
    dup_ids <- sum(duplicated(nodes[[node_id_col]]))
    node_checks$duplicate_id_count <- dup_ids
    if (dup_ids > 0) {
      critical_issues <- c(critical_issues,
                          paste0("CRITICAL: ", dup_ids, " duplicate node IDs found"))
      node_checks$duplicate_ids <- nodes[[node_id_col]][duplicated(nodes[[node_id_col]])]
    }
    
    # Check for whitespace in node IDs
    if (is.character(nodes[[node_id_col]])) {
      whitespace_ids <- sum(nodes[[node_id_col]] != trimws(nodes[[node_id_col]]), na.rm = TRUE)
      node_checks$whitespace_id_count <- whitespace_ids
      if (whitespace_ids > 0) {
        warnings <- c(warnings,
                     paste0("WARNING: ", whitespace_ids, 
                            " node IDs have leading/trailing whitespace"))
      }
    }
    
    node_checks$total_nodes <- nrow(nodes)
    info <- c(info, paste0("INFO: ", nrow(nodes), " total nodes in node list"))
  }
  
  # ============================================================================
  # 3. DATA TYPE CONSISTENCY CHECKS
  # ============================================================================
  cat("3. Checking data type consistency...\n")
  type_checks <- list()
  
  if (node_checks$has_id_col && edge_checks$has_from_col && edge_checks$has_to_col) {
    node_type <- class(nodes[[node_id_col]])[1]
    from_type <- class(edges[[from_col]])[1]
    to_type <- class(edges[[to_col]])[1]
    
    type_checks$node_id_type <- node_type
    type_checks$from_type <- from_type
    type_checks$to_type <- to_type
    
    # Check for factor issues
    if (node_type == "factor") {
      warnings <- c(warnings,
                   "WARNING: Node ID column is a factor - consider converting to character")
    }
    if (from_type == "factor") {
      warnings <- c(warnings,
                   "WARNING: 'from' column is a factor - consider converting to character")
    }
    if (to_type == "factor") {
      warnings <- c(warnings,
                   "WARNING: 'to' column is a factor - consider converting to character")
    }
    
    # Check type compatibility
    if (node_type != from_type || node_type != to_type) {
      warnings <- c(warnings,
                   paste0("WARNING: Data type mismatch - node IDs are ", node_type,
                          ", from is ", from_type, ", to is ", to_type))
    }
  }
  
  # ============================================================================
  # 4. NODE-EDGE CONSISTENCY CHECKS
  # ============================================================================
  cat("4. Checking node-edge consistency...\n")
  consistency_checks <- list()
  
  if (node_checks$has_id_col && edge_checks$has_from_col && edge_checks$has_to_col) {
    node_ids <- unique(nodes[[node_id_col]])
    edge_nodes <- unique(c(edges[[from_col]], edges[[to_col]]))
    
    # Nodes in edges but not in node list
    missing_nodes <- setdiff(edge_nodes, node_ids)
    consistency_checks$missing_node_count <- length(missing_nodes)
    consistency_checks$missing_nodes <- missing_nodes
    
    if (length(missing_nodes) > 0) {
      critical_issues <- c(critical_issues,
                          paste0("CRITICAL: ", length(missing_nodes),
                                 " nodes referenced in edges but not in node list"))
      if (length(missing_nodes) <= 10) {
        critical_issues <- c(critical_issues,
                            paste0("  Missing nodes: ", paste(missing_nodes, collapse = ", ")))
      }
    }
    
    # Nodes in node list but not in edges (isolates)
    orphaned_nodes <- setdiff(node_ids, edge_nodes)
    consistency_checks$orphaned_node_count <- length(orphaned_nodes)
    
    if (length(orphaned_nodes) > 0) {
      info <- c(info,
               paste0("INFO: ", length(orphaned_nodes),
                      " nodes in node list but not referenced in edges (will be isolates)"))
    }
  }
  
  # ============================================================================
  # 5. NETWORK PROPERTIES CHECKS
  # ============================================================================
  cat("5. Checking network properties...\n")
  network_props <- list()
  
  if (edge_checks$has_from_col && edge_checks$has_to_col) {
    # Self-loops
    self_loops <- sum(edges[[from_col]] == edges[[to_col]], na.rm = TRUE)
    network_props$self_loop_count <- self_loops
    if (self_loops > 0) {
      info <- c(info, paste0("INFO: ", self_loops, " self-loops detected"))
    }
    
    # Multi-edges (duplicate from-to pairs)
    edge_pairs <- paste(edges[[from_col]], edges[[to_col]], sep = "->")
    multi_edges <- sum(duplicated(edge_pairs))
    network_props$multi_edge_count <- multi_edges
    if (multi_edges > 0) {
      info <- c(info, paste0("INFO: ", multi_edges, " duplicate edges detected"))
    }
    
    # Unique nodes in edges
    unique_edge_nodes <- length(unique(c(edges[[from_col]], edges[[to_col]])))
    network_props$unique_nodes_in_edges <- unique_edge_nodes
  }
  
  # ============================================================================
  # 6. MISSING VALUE HANDLING
  # ============================================================================
  cleaned_nodes <- nodes
  cleaned_edges <- edges
  
  if (recode_missing && node_checks$has_id_col) {
    cat("6. Recoding missing values...\n")
    
    # Get metadata columns (exclude ID column and any specified exclusions)
    metadata_cols <- setdiff(names(nodes), c(node_id_col, exclude_cols))
    
    # Count NAs before recoding
    na_counts <- sapply(metadata_cols, function(col) sum(is.na(nodes[[col]])))
    total_nas <- sum(na_counts)
    
    if (total_nas > 0) {
      # Recode NAs to "not_available"
      cleaned_nodes <- nodes
      for (col in metadata_cols) {
        if (sum(is.na(cleaned_nodes[[col]])) > 0) {
          cleaned_nodes[[col]][is.na(cleaned_nodes[[col]])] <- "not_available"
        }
      }
      info <- c(info,
               paste0("INFO: Recoded ", total_nas, " NA values to 'not_available' across ",
                      sum(na_counts > 0), " columns"))
    }
  }
  
  # Clean whitespace from edges
  if (edge_checks$has_from_col && is.character(edges[[from_col]])) {
    cleaned_edges[[from_col]] <- trimws(edges[[from_col]])
  }
  if (edge_checks$has_to_col && is.character(edges[[to_col]])) {
    cleaned_edges[[to_col]] <- trimws(edges[[to_col]])
  }
  
  # Clean whitespace from node IDs
  if (node_checks$has_id_col && is.character(nodes[[node_id_col]])) {
    cleaned_nodes[[node_id_col]] <- trimws(cleaned_nodes[[node_id_col]])
  }
  
  # ============================================================================
  # 7. DETERMINE OVERALL STATUS
  # ============================================================================
  can_create <- length(critical_issues) == 0
  
  if (can_create) {
    if (length(warnings) > 0) {
      status <- "WARNING"
    } else {
      status <- "PASS"
    }
  } else {
    status <- "CRITICAL"
  }
  
  # ============================================================================
  # 8. CREATE SUMMARY REPORT
  # ============================================================================
  summary_lines <- c(
    "=============================================================",
    "NETWORK DIAGNOSTICS SUMMARY",
    "=============================================================",
    paste0("Overall Status: ", status),
    paste0("Can Create Network: ", ifelse(can_create, "YES", "NO")),
    ""
  )
  
  if (length(critical_issues) > 0) {
    summary_lines <- c(summary_lines,
                      "CRITICAL ISSUES (must fix):",
                      paste0("  ", critical_issues),
                      "")
  }
  
  if (length(warnings) > 0) {
    summary_lines <- c(summary_lines,
                      "WARNINGS (should review):",
                      paste0("  ", warnings),
                      "")
  }
  
  if (length(info) > 0) {
    summary_lines <- c(summary_lines,
                      "INFORMATION:",
                      paste0("  ", info),
                      "")
  }
  
  summary_lines <- c(summary_lines,
                    "=============================================================")
  
  summary_report <- paste(summary_lines, collapse = "\n")
  
  # Print summary
  cat("\n")
  cat(summary_report)
  cat("\n")
  
  # ============================================================================
  # 9. RETURN RESULTS
  # ============================================================================
  results <- list(
    status = status,
    can_create_network = can_create,
    critical_issues = critical_issues,
    warnings = warnings,
    info = info,
    edge_checks = edge_checks,
    node_checks = node_checks,
    type_checks = type_checks,
    consistency_checks = consistency_checks,
    network_properties = network_props,
    cleaned_nodes = cleaned_nodes,
    cleaned_edges = cleaned_edges,
    summary_report = summary_report
  )
  
  return(invisible(results))
}
