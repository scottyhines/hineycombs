#' @importFrom utils globalVariables
utils::globalVariables(c(
  ".", ":=", "After", "Attribute", "Before", "a", "adjustcolor", "all_n", 
  "all_weight", "alter", "as.formula", "attribute", "avg_similarity", "b", 
  "best_friend", "block", "block_general", "coef", "combn", "comparison", 
  "complete.cases", "cumulative_infections", "df", "estimate", "final_opinion", 
  "focal_high", "from", "from_comm", "from_group", "group_pair", "head", 
  "high_n", "incoming_n", "incoming_weight", "is", "legend", "level", "lm", 
  "measure_group_interconnections", "name", "name1", "name2", "node", 
  "observed_estimate", "outcome", "outgoing_n", "outgoing_weight", "p.value", 
  "p_value", "par", "pct_high", "percent_infected", "quantile", 
  "random_effects_model_term", "random_effects_model_variable_of_interest", 
  "runif", "same", "score", "state", "statistic", "std.error", "step", "term", 
  "to", "to_comm", "to_group", "value", "var", "weight"
))
