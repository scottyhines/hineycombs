#' Calculate Mixing Matrix for Graph Attributes
#'
#' @description
#' Creates a mixing matrix for a given attribute in a graph, showing either connection counts
#' or edge weights between different attribute categories.
#'
#' @param graph An igraph object containing the network
#' @param number Numeric. The number of top categories to include in the matrix
#' @param attribute_name Character. The name of the vertex attribute to analyze
#' @param type Character. Either "connections" for count-based or "edges" for weight-based analysis
#' @param percentage Logical. If TRUE, converts values to percentages with raw counts in parentheses
#' @param exclude_diagonal Logical. If TRUE, sets diagonal elements to zero
#'
#' @return A data frame containing the mixing matrix
#'
#' @examples
#' \dontrun{
#' # For connections
#' run_mixing(graph, 10, "gender", type = "connections", percentage = TRUE)
#' # For weighted edges
#' run_mixing(graph, 10, "gender", type = "edges", percentage = TRUE)
#' }
#'
#' @import igraph
#' @import dplyr
#' @importFrom janitor tabyl
#'
#' @export
run_connectivity_mixing_matrix <- function(graph, number, attribute_name, type = "connections", 
                       percentage = FALSE, exclude_diagonal = FALSE) {
  # Input validation
  if (!(attribute_name %in% igraph::vertex_attr_names(graph))) {
    stop("Attribute not found in the graph")
  }
  
  if (!(type %in% c("connections", "edges"))) {
    stop("Type must be either 'connections' or 'edges'")
  }
  
  # Common initial setup
  igraph::V(graph)$category <- igraph::vertex_attr(graph, attribute_name)
  igraph::V(graph)$category[is.na(igraph::V(graph)$category)] <- "missing"
  vars <- as.factor(igraph::V(graph)$category)
  vars_numeric <- as.numeric(vars)
  
  # Calculate assortativity
  assortativity <- igraph::assortativity_nominal(graph, vars_numeric, directed = FALSE)
  print(paste("Assortativity Coefficient:", assortativity))
  
  # Identify top categories
  top_categories <- janitor::tabyl(igraph::V(graph)$category) %>%
    dplyr::arrange(dplyr::desc(n)) %>%
    dplyr::slice(1:number) %>%
    dplyr::rename(var = 1) %>%
    dplyr::arrange(var) %>% 
    dplyr::pull(var)
  
  print("Top Categories:")
  print(top_categories)
  
  # Get edge information
  edge_ends <- igraph::ends(graph, igraph::E(graph), names = FALSE)
  
  # Filter edges for top categories
  filtered_edges <- edge_ends[vars[edge_ends[,1]] %in% top_categories & 
                                vars[edge_ends[,2]] %in% top_categories, ]
  
  # Create mixing matrix based on type
  if (type == "connections") {
    filtered_vars_from <- factor(vars[filtered_edges[,1]], levels = top_categories)
    filtered_vars_to <- factor(vars[filtered_edges[,2]], levels = top_categories)
    mixing_matrix <- table(from = filtered_vars_from, to = filtered_vars_to)
    
  } else {
    edge_weights <- igraph::E(graph)$weight
    filtered_weights <- edge_weights[vars[edge_ends[,1]] %in% top_categories & 
                                       vars[edge_ends[,2]] %in% top_categories]
    
    filtered_vars_from <- factor(vars[filtered_edges[,1]], levels = top_categories)
    filtered_vars_to <- factor(vars[filtered_edges[,2]], levels = top_categories)
    
    mixing_matrix <- matrix(0, nrow = length(top_categories), 
                            ncol = length(top_categories),
                            dimnames = list(top_categories, top_categories))
    
    for (i in seq_len(nrow(filtered_edges))) {
      from <- filtered_vars_from[i]
      to <- filtered_vars_to[i]
      weight <- filtered_weights[i]
      mixing_matrix[from, to] <- mixing_matrix[from, to] + weight
    }
  }
  
  if (exclude_diagonal) {
    diag(mixing_matrix) <- 0
  }
  
  if (percentage) {
    row_totals <- rowSums(mixing_matrix)
    mixing_matrix_perc <- sweep(mixing_matrix, 1, row_totals, FUN = "/") * 100
    mixing_matrix_perc[is.na(mixing_matrix_perc)] <- 0
    
    formatted_matrix <- matrix(NA, nrow = nrow(mixing_matrix), 
                               ncol = ncol(mixing_matrix))
    for (i in seq_len(nrow(mixing_matrix))) {
      for (j in seq_len(ncol(mixing_matrix))) {
        formatted_matrix[i, j] <- paste0(round(mixing_matrix_perc[i, j], 2), 
                                         "% (", mixing_matrix[i, j], ")")
      }
    }
    
    rownames(formatted_matrix) <- rownames(mixing_matrix)
    colnames(formatted_matrix) <- colnames(mixing_matrix)
    mixing_matrix <- formatted_matrix
  }
  
  if (!percentage) {
    mixing_matrix_df <- as.data.frame.matrix(mixing_matrix)
  } else {
    mixing_matrix_df <- as.data.frame(mixing_matrix)
  }
  
  print("Mixing Matrix:")
  print(mixing_matrix_df)
  
  return(mixing_matrix_df)
}
