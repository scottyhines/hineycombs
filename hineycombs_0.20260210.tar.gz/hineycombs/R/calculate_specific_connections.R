#' Count attribute-based connections in a network
#'
#' @description
#' For each vertex in an \code{igraph} object, this function counts how many
#' connections it has with alters in specific categories of one or more
#' vertex attributes (e.g., job level, organization, region), optionally
#' distinguishing between ties to alters with the same vs. different value
#' on that attribute.
#'
#' The function supports both directed and undirected graphs:
#' \itemize{
#'   \item For directed graphs, it returns separate metrics for
#'   incoming and outgoing ties.
#'   \item For undirected graphs, it returns metrics aggregating
#'   across all ties.
#' }
#'
#' @param g An \code{igraph} object. Vertices must have a \code{name}
#'   attribute that uniquely identifies them.
#' @param attr_vars Character vector of vertex attribute names (categorical
#'   variables) to summarize, e.g. \code{"job_level_name"},
#'   \code{"organization"}, \code{"geographic_region"}.
#' @param weight_var Optional character string giving the name of the edge
#'   attribute to use as weights (e.g., interaction frequency). If
#'   \code{NULL} or not present in the edge data, all edges are treated
#'   as having weight 1.
#' @param same_diff Logical. If \code{FALSE} (default), the function computes
#'   per-level summaries for each attribute (e.g.,
#'   \code{job_level_name_4_incoming_n}). If \code{TRUE}, the function
#'   computes only "same" vs. "different" summaries relative to each ego's
#'   own attribute value (e.g., \code{geographic_region_incoming_same_n}),
#'   and does not produce per-level columns.
#' @param return_graph Logical. If \code{FALSE} (default), a data frame of
#'   vertex attributes is returned, including the newly created summary
#'   variables. If \code{TRUE}, the input graph \code{g} is returned with
#'   these variables added as vertex attributes.
#'
#' @details
#' Let \code{attr} be a vertex attribute in \code{attr_vars} and
#' \code{level} one of its values (e.g., job level 4, 5, 6). The function
#' always counts:
#' \itemize{
#'   \item \code{*_n}: the number of distinct alters (unique neighbors)
#'   in the relevant category.
#'   \item \code{*_f}: the sum of edge weights to those alters (or the
#'   number of edges if no weight variable is supplied).
#' }
#'
#' For \strong{directed graphs} and \code{same_diff = FALSE}, the following
#' variables are created for each attribute and level:
#' \itemize{
#'   \item \code{<attr>_<level>_incoming_n}: distinct alters with that level
#'     sending edges to ego.
#'   \item \code{<attr>_<level>_incoming_f}: total weight from that level
#'     to ego.
#'   \item \code{<attr>_<level>_outgoing_n}: distinct alters with that level
#'     ego sends edges to.
#'   \item \code{<attr>_<level>_outgoing_f}: total weight from ego to that
#'     level.
#' }
#'
#' For \strong{directed graphs} and \code{same_diff = TRUE}, the function
#' compares each ego's attribute value to each alter's value and creates:
#' \itemize{
#'   \item \code{<attr>_incoming_same_n}, \code{<attr>_incoming_same_f}
#'   \item \code{<attr>_incoming_diff_n}, \code{<attr>_incoming_diff_f}
#'   \item \code{<attr>_outgoing_same_n}, \code{<attr>_outgoing_same_f}
#'   \item \code{<attr>_outgoing_diff_n}, \code{<attr>_outgoing_diff_f}
#' }
#'
#' For \strong{undirected graphs}, there is no direction, so metrics are
#' aggregated over all ties. When \code{same_diff = FALSE}, the function
#' creates:
#' \itemize{
#'   \item \code{<attr>_<level>_all_n}: distinct neighbors with that level.
#'   \item \code{<attr>_<level>_all_f}: total weight on edges to neighbors
#'     with that level.
#' }
#'
#' When \code{same_diff = TRUE} for undirected graphs, the function creates:
#' \itemize{
#'   \item \code{<attr>_all_same_n}, \code{<attr>_all_same_f}:
#'     distinct neighbors with the same attribute value as ego.
#'   \item \code{<attr>_all_diff_n}, \code{<attr>_all_diff_f}:
#'     distinct neighbors with a different attribute value from ego.
#' }
#'
#' Attribute levels are converted to syntactically valid column fragments via
#' \code{\link[base]{make.names}} before being used in column names.
#'
#' @return
#' If \code{return_graph = FALSE}, a data frame of vertex attributes,
#' including the newly created summary variables.
#'
#' If \code{return_graph = TRUE}, an \code{igraph} object with the new
#' summary variables added as vertex attributes.
#'
#' @importFrom igraph is_directed as_data_frame set_vertex_attr V
#' @importFrom dplyr group_by summarise n_distinct
#'
#' @examples
#' \dontrun{
#' library(igraph)
#'
#' # Directed example --------------------------------------------
#' g_dir <- make_ring(5, directed = TRUE)
#' V(g_dir)$name <- LETTERS[1:5]
#' V(g_dir)$job_level_name <- c(4, 4, 5, 6, 6)
#' V(g_dir)$geographic_region <- c("NA", "NA", "EU", "EU", "NA")
#' E(g_dir)$weight <- c(3, 1, 2, 5, 4)
#'
#' # Per-level metrics by job level and region
#' res_dir <- count_attr_connections(
#'   g          = g_dir,
#'   attr_vars  = c("job_level_name", "geographic_region"),
#'   weight_var = "weight",
#'   same_diff  = FALSE,
#'   return_graph = FALSE
#' )
#'
#' # Same vs different region (directed)
#' res_dir_sd <- count_attr_connections(
#'   g          = g_dir,
#'   attr_vars  = "geographic_region",
#'   weight_var = "weight",
#'   same_diff  = TRUE,
#'   return_graph = FALSE
#' )
#'
#' # Undirected example ------------------------------------------
#' g_undir <- make_ring(5, directed = FALSE)
#' V(g_undir)$name <- LETTERS[1:5]
#' V(g_undir)$job_level_name <- c(4, 4, 5, 6, 6)
#' E(g_undir)$weight <- c(3, 1, 2, 5, 4)
#'
#' # Per-level metrics (all neighbors)
#' res_undir <- count_attr_connections(
#'   g          = g_undir,
#'   attr_vars  = "job_level_name",
#'   weight_var = "weight",
#'   same_diff  = FALSE,
#'   return_graph = FALSE
#' )
#'
#' # Same vs different job level (all neighbors)
#' res_undir_sd <- count_attr_connections(
#'   g          = g_undir,
#'   attr_vars  = "job_level_name",
#'   weight_var = "weight",
#'   same_diff  = TRUE,
#'   return_graph = FALSE
#' )
#'
#' # Write results back onto the graph
#' g_dir_with_attrs <- count_attr_connections(
#'   g          = g_dir,
#'   attr_vars  = "job_level_name",
#'   weight_var = "weight",
#'   same_diff  = FALSE,
#'   return_graph = TRUE
#' )
#' }
#'
#' @export
calculate_specific_connections <- function (g, attr_vars, weight_var = NULL, same_diff = FALSE, return_graph = FALSE)
{
  if (!inherits(g, "igraph")) {
    stop("`g` must be an igraph object.")
  }
  is_dir <- igraph::is_directed(g)
  attr_vars <- as.character(attr_vars)
  edges <- igraph::as_data_frame(g, what = "edges")
  nodes <- igraph::as_data_frame(g, what = "vertices")
  if (!"name" %in% names(nodes)) {
    stop("Vertices must have a `name` attribute.")
  }
  if (is.null(weight_var) || !weight_var %in% names(edges)) {
    edges[["..weight_tmp.."]] <- 1
    wcol <- "..weight_tmp.."
  }
  else {
    wcol <- weight_var
  }
  result <- nodes
  add_column_if_missing <- function(df, col) {
    if (!col %in% names(df)) {
      df[[col]] <- 0
    }
    df
  }
  for (attr in attr_vars) {
    if (!attr %in% names(nodes)) {
      warning(sprintf("Vertex attribute '%s' not found; skipping.",
                      attr))
      next
    }
    if (!is_dir) {
      df_all <- data.frame(ego = edges$from, alter = edges$to,
                           weight = edges[[wcol]], stringsAsFactors = FALSE)
      df_rev <- data.frame(ego = edges$to, alter = edges$from,
                           weight = edges[[wcol]], stringsAsFactors = FALSE)
      df_all <- rbind(df_all, df_rev)
      df_all[[attr]] <- nodes[[attr]][match(df_all$alter,
                                            nodes$name)]
      df_all <- df_all[!is.na(df_all[[attr]]), ]
      if (nrow(df_all) == 0)
        next
      if (!same_diff) {
        df_all$level <- df_all[[attr]]
        agg <- dplyr::summarise(dplyr::group_by(df_all,
                                                ego, level), n = dplyr::n_distinct(alter),
                                f = sum(weight, na.rm = TRUE), .groups = "drop")
        for (i in seq_len(nrow(agg))) {
          ego_name <- agg$ego[i]
          level_val <- make.names(as.character(agg$level[i]))
          base <- paste(attr, level_val, "all", sep = "_")
          ncol <- paste0(base, "_n")
          fcol <- paste0(base, "_f")
          result <- add_column_if_missing(result, ncol)
          result <- add_column_if_missing(result, fcol)
          row_idx <- match(ego_name, result$name)
          result[[ncol]][row_idx] <- agg$n[i]
          result[[fcol]][row_idx] <- agg$f[i]
        }
      }
      if (same_diff) {
        ego_attr_vals <- nodes[[attr]][match(df_all$ego,
                                             nodes$name)]
        alter_attr_vals <- df_all[[attr]]
        same_flag <- ego_attr_vals == alter_attr_vals
        df_sd <- df_all
        df_sd$same <- same_flag
        agg_sd <- dplyr::summarise(dplyr::group_by(df_sd,
                                                   ego, same), n = dplyr::n_distinct(alter), f = sum(weight,
                                                                                                     na.rm = TRUE), .groups = "drop")
        if (nrow(agg_sd) > 0) {
          for (i in seq_len(nrow(agg_sd))) {
            ego_name <- agg_sd$ego[i]
            tag <- if (isTRUE(agg_sd$same[i]))
              "same"
            else "diff"
            base <- paste(attr, "all", tag, sep = "_")
            ncol <- paste0(base, "_n")
            fcol <- paste0(base, "_f")
            result <- add_column_if_missing(result, ncol)
            result <- add_column_if_missing(result, fcol)
            row_idx <- match(ego_name, result$name)
            result[[ncol]][row_idx] <- agg_sd$n[i]
            result[[fcol]][row_idx] <- agg_sd$f[i]
          }
        }
      }
      next
    }
    # Directed network - process incoming and outgoing separately
    for (direction in c("in", "out")) {
      if (direction == "in") {
        df <- data.frame(ego = edges$to, alter = edges$from,
                         weight = edges[[wcol]], stringsAsFactors = FALSE)
        dir_label <- "incoming"
      }
      else {
        df <- data.frame(ego = edges$from, alter = edges$to,
                         weight = edges[[wcol]], stringsAsFactors = FALSE)
        dir_label <- "outgoing"
      }
      df[[attr]] <- nodes[[attr]][match(df$alter, nodes$name)]
      df <- df[!is.na(df[[attr]]), ]
      if (nrow(df) == 0)
        next
      if (!same_diff) {
        df$level <- df[[attr]]
        agg <- dplyr::summarise(dplyr::group_by(df, ego,
                                                level), n = dplyr::n_distinct(alter), f = sum(weight,
                                                                                              na.rm = TRUE), .groups = "drop")
        for (i in seq_len(nrow(agg))) {
          ego_name <- agg$ego[i]
          level_val <- agg$level[i]
          level_safe <- make.names(as.character(level_val))
          base <- paste(attr, level_safe, dir_label,
                        sep = "_")
          ncol <- paste0(base, "_n")
          fcol <- paste0(base, "_f")
          result <- add_column_if_missing(result, ncol)
          result <- add_column_if_missing(result, fcol)
          row_idx <- match(ego_name, result$name)
          result[[ncol]][row_idx] <- agg$n[i]
          result[[fcol]][row_idx] <- agg$f[i]
        }
      }
      if (same_diff) {
        ego_attr_vals <- nodes[[attr]][match(df$ego,
                                             nodes$name)]
        alter_attr_vals <- df[[attr]]
        same_flag <- ego_attr_vals == alter_attr_vals
        df_sd <- df
        df_sd$same <- same_flag
        agg_sd <- dplyr::summarise(dplyr::group_by(df_sd,
                                                   ego, same), n = dplyr::n_distinct(alter), f = sum(weight,
                                                                                                     na.rm = TRUE), .groups = "drop")
        if (nrow(agg_sd) > 0) {
          for (i in seq_len(nrow(agg_sd))) {
            ego_name <- agg_sd$ego[i]
            tag <- if (isTRUE(agg_sd$same[i]))
              "same"
            else "diff"
            base <- paste(attr, dir_label, tag, sep = "_")
            ncol <- paste0(base, "_n")
            fcol <- paste0(base, "_f")
            result <- add_column_if_missing(result, ncol)
            result <- add_column_if_missing(result, fcol)
            row_idx <- match(ego_name, result$name)
            result[[ncol]][row_idx] <- agg_sd$n[i]
            result[[fcol]][row_idx] <- agg_sd$f[i]
          }
        }
      }
    }
    
    # NEW: Calculate TOTAL metrics (incoming + outgoing combined)
    if (is_dir && !same_diff) {
      # Combine both directions to get total connections
      df_all_edges <- rbind(
        data.frame(ego = edges$from, alter = edges$to,
                   weight = edges[[wcol]], stringsAsFactors = FALSE),
        data.frame(ego = edges$to, alter = edges$from,
                   weight = edges[[wcol]], stringsAsFactors = FALSE)
      )
      
      df_all_edges[[attr]] <- nodes[[attr]][match(df_all_edges$alter, nodes$name)]
      df_all_edges <- df_all_edges[!is.na(df_all_edges[[attr]]), ]
      
      if (nrow(df_all_edges) > 0) {
        df_all_edges$level <- df_all_edges[[attr]]
        agg_total <- dplyr::summarise(dplyr::group_by(df_all_edges, ego, level),
                                      n = dplyr::n_distinct(alter),
                                      f = sum(weight, na.rm = TRUE),
                                      .groups = "drop")
        
        for (i in seq_len(nrow(agg_total))) {
          ego_name <- agg_total$ego[i]
          level_val <- agg_total$level[i]
          level_safe <- make.names(as.character(level_val))
          base <- paste(attr, level_safe, "total", sep = "_")
          ncol <- paste0(base, "_n")
          fcol <- paste0(base, "_f")
          result <- add_column_if_missing(result, ncol)
          result <- add_column_if_missing(result, fcol)
          row_idx <- match(ego_name, result$name)
          result[[ncol]][row_idx] <- agg_total$n[i]
          result[[fcol]][row_idx] <- agg_total$f[i]
        }
      }
    }
  }
  if (return_graph) {
    for (col in setdiff(names(result), names(nodes))) {
      idx <- match(igraph::V(g)$name, result$name)
      values <- result[[col]][idx]
      g <- igraph::set_vertex_attr(g, name = col, value = values)
    }
    return(g)
  }
  else {
    return(result)
  }
}