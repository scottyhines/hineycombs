#' Run Exponential Random Graph Model (ERGM) Analysis
#'
#' @description
#' Fits an Exponential Random Graph Model to understand what drives tie formation in your network.
#'
#' @param g An igraph object representing the network
#' @param node_attributes Character vector of vertex attribute names to test for homophily
#' @param continuous_attributes Character vector of vertex attributes that are continuous (e.g., c("tenure","age"))
#' @param structural_terms Character vector of structural effects to include. Options:
#'   \itemize{
#'     \item "edges" - Baseline density (always included automatically)
#'     \item "mutual" - Reciprocity (directed only)
#'     \item "triangles" - Simple triangle count (undirected only; gwesp is usually better)
#'     \item "gwesp" - Geometrically weighted edgewise shared partners (triadic closure)
#'     \item "gwdegree" - Geometrically weighted degree distribution (hubs/degree heterogeneity)
#'     \item "popularity" - Directed-only (uses idegree(1.5))
#'     \item "activity" - Directed-only (uses odegree(1.5))
#'     \item "transitivity" - Alias for gwesp (kept for compatibility; may be skipped if gwesp included)
#'   }
#'   Default: c("mutual", "gwesp", "gwdegree") for directed, c("gwesp", "gwdegree") for undirected
#' @param edge_covariates Named list mapping model covariate names -> igraph edge attribute names
#'   e.g., list(weight = "weight") will build a dyadic matrix from E(g)$weight and include edgecov(weight_matrix)
#' @param gwesp_decay Decay parameter for GWESP (default = 0.5)
#' @param gwdegree_decay Decay parameter for GWDEGREE (default = 0.5)
#' @param gwdegree_fixed Logical. If FALSE (default), ERGM estimates decay (more stable). If TRUE, fixes at gwdegree_decay.
#' @param gwesp_fixed Logical. If TRUE (default), fixes GWESP decay at gwesp_decay (usually fine).
#' @param scale_continuous Logical. If TRUE (default), continuous attributes are z-scored and absdiff uses the _z version.
#' @param control_mcmc List of MCMC control parameters (passed to ergm::control.ergm)
#' @param seed Random seed for reproducibility
#' @param verbose Logical. Print detailed fitting progress? (default = TRUE)
#'
#' @return A list with model, summary, coefficients, interpretation, gof, formula, etc.
#'
#' @importFrom ergm ergm gof summary.ergm control.ergm
#' @importFrom intergraph asNetwork
#' @importFrom network set.vertex.attribute
#' @export
run_insights_ergm_analysis <- function(
    g,
    node_attributes = NULL,
    continuous_attributes = NULL,
    structural_terms = NULL,
    edge_covariates = NULL,
    gwesp_decay = 0.5,
    gwdegree_decay = 0.5,
    gwdegree_fixed = FALSE,
    gwesp_fixed = TRUE,
    scale_continuous = TRUE,
    control_mcmc = list(MCMC.burnin = 10000, MCMC.samplesize = 10000, MCMC.interval = 1000),
    seed = 12345,
    verbose = TRUE
) {
  
  # ---- Package checks ----
  if (!requireNamespace("ergm", quietly = TRUE)) {
    stop("Package 'ergm' is required. Install with: install.packages('ergm')")
  }
  if (!requireNamespace("intergraph", quietly = TRUE)) {
    stop("Package 'intergraph' is required. Install with: install.packages('intergraph')")
  }
  if (!requireNamespace("igraph", quietly = TRUE)) {
    stop("Package 'igraph' is required. Install with: install.packages('igraph')")
  }
  if (!requireNamespace("network", quietly = TRUE)) {
    stop("Package 'network' is required. Install with: install.packages('network')")
  }
  
  if (!inherits(g, "igraph")) stop("`g` must be an igraph object.")
  
  if (verbose) {
    cat("=== ERGM Analysis ===\n")
    cat("Preparing network for ERGM modeling...\n\n")
  }
  
  # Convert igraph -> network
  net <- intergraph::asNetwork(g)
  
  # Directed?
  is_directed <- igraph::is_directed(g)
  
  # Defaults
  if (is.null(structural_terms)) {
    structural_terms <- if (is_directed) c("mutual", "gwesp", "gwdegree") else c("gwesp", "gwdegree")
    if (verbose) {
      cat(
        "Using default structural terms for ",
        if (is_directed) "directed" else "undirected",
        " network: ",
        paste(structural_terms, collapse = ", "),
        "\n",
        sep = ""
      )
    }
  }
  
  # Validate structural terms
  valid_terms <- c("edges","mutual","transitivity","triangles","gwesp","gwdegree","popularity","activity")
  invalid <- setdiff(structural_terms, valid_terms)
  if (length(invalid) > 0) {
    warning("Invalid structural terms ignored: ", paste(invalid, collapse = ", "))
    structural_terms <- intersect(structural_terms, valid_terms)
  }
  
  # Compatibility alias: transitivity -> gwesp (only if gwesp not already included)
  if ("transitivity" %in% structural_terms) {
    if (!("gwesp" %in% structural_terms)) {
      structural_terms[structural_terms == "transitivity"] <- "gwesp"
    } else {
      # skip redundant alias
      structural_terms <- structural_terms[structural_terms != "transitivity"]
      if (verbose) cat("Note: 'transitivity' skipped because 'gwesp' is already included.\n")
    }
  }
  
  # --- Scale continuous attributes on the *network* object (so ERGM sees them) ---
  # We create attr_z on `net` and use that in absdiff().
  if (!is.null(continuous_attributes) && scale_continuous) {
    for (attr in continuous_attributes) {
      if (attr %in% igraph::vertex_attr_names(g)) {
        vals <- igraph::vertex_attr(g, attr)
        if (is.numeric(vals) && length(unique(vals[!is.na(vals)])) > 1) {
          zname <- paste0(attr, "_z")
          zvals <- as.numeric(scale(vals))
          network::set.vertex.attribute(net, zname, zvals)
        }
      }
    }
  }
  
  # --- Build edge covariate matrices (edgecov needs a dyadic matrix) ---
  # edge_covariates: list(model_name = "igraph_edge_attr_name")
  edgecov_env <- new.env(parent = parent.frame())
  edgecov_terms <- character(0)
  
  if (!is.null(edge_covariates)) {
    if (!is.list(edge_covariates) || is.null(names(edge_covariates)) || any(names(edge_covariates) == "")) {
      stop("edge_covariates must be a *named* list, e.g., list(weight = 'weight').")
    }
    
    n <- igraph::vcount(g)
    edgelist <- igraph::as_edgelist(g, names = FALSE)
    for (model_name in names(edge_covariates)) {
      edge_attr <- edge_covariates[[model_name]]
      
      if (!(edge_attr %in% igraph::edge_attr_names(g))) {
        warning("Edge attribute '", edge_attr, "' not found in graph; skipping edge covariate '", model_name, "'.")
        next
      }
      
      w <- igraph::edge_attr(g, edge_attr)
      if (!is.numeric(w)) {
        warning("Edge attribute '", edge_attr, "' is not numeric; skipping edge covariate '", model_name, "'.")
        next
      }
      
      mat <- matrix(0, nrow = n, ncol = n)
      
      # fill matrix
      # For undirected, make symmetric.
      for (i in seq_len(nrow(edgelist))) {
        a <- edgelist[i, 1]
        b <- edgelist[i, 2]
        mat[a, b] <- w[i]
        if (!is_directed) mat[b, a] <- w[i]
      }
      
      obj_name <- paste0(model_name, "_matrix")
      assign(obj_name, mat, envir = edgecov_env)
      
      edgecov_terms <- c(edgecov_terms, paste0("edgecov(", obj_name, ")"))
      if (verbose) cat("Including edge covariate: ", model_name, " from E(g)$", edge_attr, "\n", sep = "")
    }
  }
  
  # ---- Formula parts ----
  formula_parts <- c("net ~ edges")
  
  if (verbose) {
    cat("\n=== Structural Effects Being Tested ===\n")
    cat("• Edges: Baseline network density (always included)\n")
  }
  
  # Helper for adding a term once
  add_term <- function(x) { formula_parts <<- c(formula_parts, x) }
  
  for (term in structural_terms) {
    if (term == "edges") next
    
    if (term == "mutual") {
      if (is_directed) {
        add_term("mutual")
        if (verbose) {
          cat("• Mutual: Testing RECIPROCITY - Do people reciprocate connections?\n")
          cat("  Example: If Alice emails Bob, does Bob email Alice back?\n")
        }
      } else if (verbose) {
        cat("• Mutual: SKIPPED (only for directed networks)\n")
      }
      
    } else if (term == "triangles") {
      if (!is_directed) {
        add_term("triangles")
        if (verbose) {
          cat("• Triangles: Testing CLUSTERING - Do people form tight-knit groups?\n")
          cat("  Example: Do your connections also connect with each other?\n")
        }
      } else if (verbose) {
        cat("• Triangles: SKIPPED (typically use 'gwesp' for directed networks)\n")
      }
      
    } else if (term == "gwesp") {
      add_term(paste0("gwesp(", gwesp_decay, ", fixed=", if (gwesp_fixed) "TRUE" else "FALSE", ")"))
      if (verbose) {
        cat("• GWESP: Testing SHARED PARTNERS - Do people connect through mutual contacts?\n")
        cat("  Example: Are you more likely to connect with someone if you share many mutual friends?\n")
        cat("  (This is a more sophisticated version of triangle counting)\n")
      }
      
    } else if (term == "gwdegree") {
      if (is_directed) {
        # For directed, model both in- and out-degree heterogeneity
        add_term(paste0("gwidegree(", gwdegree_decay, ", fixed=", if (gwdegree_fixed) "TRUE" else "FALSE", ")"))
        add_term(paste0("gwodegree(", gwdegree_decay, ", fixed=", if (gwdegree_fixed) "TRUE" else "FALSE", ")"))
      } else {
        add_term(paste0("gwdegree(", gwdegree_decay, ", fixed=", if (gwdegree_fixed) "TRUE" else "FALSE", ")"))
      }
      if (verbose) {
        cat("• GWDegree: Testing DEGREE DISTRIBUTION - Are there 'hubs' or is it evenly distributed?\n")
        cat("  Example: Do a few people have many connections while most have few?\n")
        if (!gwdegree_fixed) cat("  Note: decay will be estimated (fixed=FALSE) for stability.\n")
      }
      
    } else if (term == "popularity") {
      if (is_directed) {
        add_term("idegree(1.5)")
        if (verbose) {
          cat("• Popularity: Testing PREFERENTIAL ATTACHMENT (directed) - do high-indegree nodes attract ties?\n")
        }
      } else if (verbose) {
        cat("• Popularity: SKIPPED (directed-only; use 'gwdegree' for undirected)\n")
      }
      
    } else if (term == "activity") {
      if (is_directed) {
        add_term("odegree(1.5)")
        if (verbose) {
          cat("• Activity: Testing SENDER EFFECTS (directed) - are some nodes more active at sending ties?\n")
        }
      } else if (verbose) {
        cat("• Activity: SKIPPED (directed-only; use 'gwdegree' for undirected)\n")
      }
    }
  }
  
  # Homophily terms
  if (!is.null(node_attributes)) {
    if (verbose) {
      cat("\n=== Homophily Testing ===\n")
      cat("Testing if people connect with others who share the same attributes:\n")
    }
    
    for (attr in node_attributes) {
      if (!(attr %in% igraph::vertex_attr_names(g))) {
        warning("Attribute '", attr, "' not found in graph - skipping")
        next
      }
      vals <- igraph::vertex_attr(g, attr)
      uniq <- unique(vals[!is.na(vals)])
      if (length(uniq) <= 1) {
        warning("Attribute '", attr, "' has no variation - skipping")
        next
      }
      add_term(paste0("nodematch('", attr, "')"))
      if (verbose) {
        cat("• ", attr, ": Do people with the same ", attr, " connect more?\n", sep = "")
        cat("  Groups: ", paste(head(uniq, 5), collapse = ", "),
            if (length(uniq) > 5) "..." else "", "\n", sep = "")
      }
    }
  }
  
  # Continuous similarity terms
  if (!is.null(continuous_attributes)) {
    if (verbose) {
      cat("\n=== Similarity Testing (Continuous Attributes) ===\n")
      cat("Testing if people with similar values connect more:\n")
    }
    
    for (attr in continuous_attributes) {
      if (!(attr %in% igraph::vertex_attr_names(g))) {
        warning("Attribute '", attr, "' not found in graph - skipping")
        next
      }
      
      vals <- igraph::vertex_attr(g, attr)
      if (!is.numeric(vals) || length(unique(vals[!is.na(vals)])) <= 1) {
        warning("Attribute '", attr, "' is not numeric or has no variation - skipping")
        next
      }
      
      used_attr <- attr
      if (scale_continuous) {
        zname <- paste0(attr, "_z")
        # If we failed to create it for some reason, fall back
        if (!is.null(network::get.vertex.attribute(net, zname))) {
          used_attr <- zname
        }
      }
      
      add_term(paste0("absdiff('", used_attr, "')"))
      
      if (verbose) {
        cat("• ", attr, ": Do people with similar ", attr, " values connect more?\n", sep = "")
        cat("  Range: ", round(min(vals, na.rm = TRUE), 2), " to ", round(max(vals, na.rm = TRUE), 2), "\n", sep = "")
        if (used_attr != attr) cat("  Using scaled version: ", used_attr, "\n", sep = "")
        cat("  (Negative coefficient = similarity attracts, Positive = difference attracts)\n")
      }
    }
  }
  
  # Edge covariates (dyadic matrices)
  if (length(edgecov_terms) > 0) {
    formula_parts <- c(formula_parts, edgecov_terms)
  }
  
  # Construct formula with an environment that includes any edgecov matrices
  formula_str <- paste(formula_parts, collapse = " + ")
  # Create formula in the current environment so 'net' is accessible
  model_formula <- stats::as.formula(formula_str)
  
  if (verbose) {
    cat("\n=== Model Formula ===\n")
    cat(formula_str, "\n\n")
  }
  
  set.seed(seed)
  
  if (verbose) {
    cat("Fitting ERGM...\n")
    cat("MCMC settings: burnin =", control_mcmc$MCMC.burnin,
        ", sample size =", control_mcmc$MCMC.samplesize,
        ", interval =", control_mcmc$MCMC.interval, "\n\n")
  }
  
  model <- tryCatch({
    ergm::ergm(
      model_formula,
      control = do.call(ergm::control.ergm, control_mcmc),
      verbose = verbose
    )
  }, error = function(e) {
    stop(
      "ERGM fitting failed: ", e$message,
      "\nTry simplifying the model (often drop/fix gwdegree first) or adjust MCMC settings."
    )
  })
  
  if (verbose) cat("\n=== Model Fitting Complete ===\n\n")
  
  model_summary <- summary(model)
  
  # Coefficients table
  coefs <- model_summary$coefficients
  coef_df <- as.data.frame(coefs)
  coef_df$term <- rownames(coef_df)
  
  # Robust p-value column name (ergm usually: Pr(>|z|))
  pcol <- grep("^Pr\\(", colnames(coef_df), value = TRUE)
  if (length(pcol) == 1) {
    coef_df$significant <- coef_df[[pcol]] < 0.05
  } else {
    # fallback
    coef_df$significant <- NA
  }
  
  if (verbose) {
    cat("=== Model Results ===\n")
    show_cols <- intersect(c("term","Estimate","Std. Error","z value","Pr(>|z|)","significant"), colnames(coef_df))
    print(coef_df[, show_cols, drop = FALSE])
    cat("\n")
  }
  
  interpretation <- generate_ergm_interpretation(coef_df)
  
  if (verbose) {
    cat("\n=== Plain English Interpretation ===\n")
    cat(interpretation, "\n\n")
  }
  
  # GOF (optional)
  gof_result <- tryCatch({
    if (verbose) cat("Calculating goodness of fit diagnostics...\n")
    ergm::gof(model, verbose = FALSE)
  }, error = function(e) {
    if (verbose) {
      cat("\nWarning: GOF calculation failed:", e$message, "\n")
      cat("Skipping goodness of fit diagnostics.\n")
    }
    NULL
  })
  
  gof_interpretation <- NULL
  if (!is.null(gof_result)) {
    gof_interpretation <- interpret_gof(gof_result)
    if (verbose) {
      cat("Goodness of fit calculated successfully!\n\n")
      cat("=== Goodness of Fit Interpretation ===\n")
      cat(gof_interpretation, "\n\n")
      cat("Use plot(results$gof) to visualize.\n")
    }
  }
  
  if (verbose) cat("\n=== Analysis Complete ===\n")
  
  list(
    model = model,
    summary = model_summary,
    coefficients = coef_df,
    interpretation = interpretation,
    gof = gof_result,
    gof_interpretation = gof_interpretation,
    formula = model_formula,
    network = net,
    is_directed = is_directed
  )
}

#' Generate plain English interpretation of ERGM results
#' @keywords internal
generate_ergm_interpretation <- function(coef_df) {
  interpretations <- character(0)
  
  pcol <- grep("^Pr\\(", colnames(coef_df), value = TRUE)
  if (length(pcol) != 1) {
    return("Interpretation unavailable: could not locate a p-value column in the ERGM summary.")
  }
  
  for (i in seq_len(nrow(coef_df))) {
    term <- coef_df$term[i]
    est  <- coef_df$Estimate[i]
    pval <- coef_df[[pcol]][i]
    
    if (is.na(pval) || pval >= 0.05) next
    
    direction <- if (est > 0) "increases" else "decreases"
    strength <- if (abs(est) > 1) "strongly" else if (abs(est) > 0.5) "moderately" else "slightly"
    
    interp <- NULL
    
    if (term == "edges") {
      interp <- paste0("Baseline density: network is ", if (est < 0) "sparse" else "dense",
                       " (", strength, " ", direction, " tie probability)")
    } else if (term == "mutual") {
      interp <- paste0("Reciprocity: ", strength, " ", direction,
                       " likelihood of mutual ties (A↔B)")
    } else if (grepl("gwesp", term)) {
      interp <- paste0("Triadic closure (GWESP): ", strength, " ", direction,
                       " tendency for shared-partner clustering")
    } else if (grepl("gwdegree|gwidegree|gwodegree", term)) {
      interp <- paste0("Degree heterogeneity: ", strength, " ", direction,
                       " tendency toward hubs / unequal degree distribution")
    } else if (grepl("^triangles$", term)) {
      interp <- paste0("Triangles: ", strength, " ", direction,
                       " tendency to form closed triads")
    } else if (grepl("^idegree", term)) {
      interp <- paste0("Popularity (idegree): ", strength, " ", direction,
                       " tendency for high-indegree nodes to attract ties")
    } else if (grepl("^odegree", term)) {
      interp <- paste0("Activity (odegree): ", strength, " ", direction,
                       " tendency for some nodes to initiate more ties")
    } else if (grepl("^nodematch\\.", term)) {
      attr_name <- sub("^nodematch\\.", "", term)
      interp <- if (est > 0) {
        paste0("Homophily (", attr_name, "): ", strength, " increases ties among same-", attr_name, " nodes")
      } else {
        paste0("Heterophily (", attr_name, "): ", strength, " increases ties among different-", attr_name, " nodes")
      }
    } else if (grepl("^absdiff\\.", term)) {
      attr_name <- sub("^absdiff\\.", "", term)
      interp <- if (est < 0) {
        paste0("Similarity (", attr_name, "): ", strength, " increases ties among similar values")
      } else {
        paste0("Difference (", attr_name, "): ", strength, " increases ties among dissimilar values")
      }
    } else if (grepl("^edgecov\\.", term) || grepl("^edgecov\\(", term)) {
      interp <- paste0("Edge covariate: ", strength, " ", direction, " tie probability as the covariate increases")
    }
    
    if (!is.null(interp)) {
      interpretations <- c(interpretations, paste0("• ", interp, " (p = ", signif(pval, 3), ")"))
    }
  }
  
  if (length(interpretations) == 0) {
    return("No significant effects found at p < .05. Consider simplifying the model or revisiting term choices.")
  }
  
  paste(interpretations, collapse = "\n")
}

#' Interpret goodness of fit results
#' @keywords internal
interpret_gof <- function(gof_result) {
  # GOF object names vary by model/options; keep interpretation robust.
  nm <- names(gof_result)
  out <- character(0)
  
  check_component <- function(comp) {
    if (is.null(comp)) return(NULL)
    if (is.matrix(comp) || is.data.frame(comp)) {
      cn <- colnames(comp)
      if (all(c("obs","min","max") %in% cn)) {
        obs <- comp[, "obs"]
        mn  <- comp[, "min"]
        mx  <- comp[, "max"]
        total <- sum(!is.na(obs))
        inrng <- sum(obs >= mn & obs <= mx, na.rm = TRUE)
        if (total > 0) return(list(pct = 100 * inrng/total, inrng = inrng, total = total))
      }
    }
    NULL
  }
  
  # degree component can be "deg", "ideg", "odeg" depending on directedness/model
  deg_res <- NULL
  for (cand in c("deg","ideg","odeg","degree")) {
    if (cand %in% nm) { deg_res <- check_component(gof_result[[cand]]); if (!is.null(deg_res)) break }
  }
  if (!is.null(deg_res)) {
    out <- c(out, paste0("Degree: ", round(deg_res$pct,0), "% of observed points within simulated range"))
  }
  
  # shared partners component often "espartners" (sometimes abbreviated)
  esp_res <- NULL
  esp_name <- intersect(nm, c("espartners","esp","espart"))
  if (length(esp_name) >= 1) esp_res <- check_component(gof_result[[esp_name[1]]])
  if (!is.null(esp_res)) {
    out <- c(out, paste0("Shared partners (clustering): ", round(esp_res$pct,0),
                         "% of observed points within simulated range"))
  }
  
  # distances often "dist"
  if ("dist" %in% nm) {
    dist_res <- check_component(gof_result$dist)
    if (!is.null(dist_res)) {
      out <- c(out, paste0("Geodesic distances: ", round(dist_res$pct,0),
                           "% of observed points within simulated range"))
    }
  }
  
  # model terms often "model"
  if ("model" %in% nm) {
    mod_res <- check_component(gof_result$model)
    if (!is.null(mod_res)) {
      out <- c(out, paste0("Model statistics: ", round(mod_res$pct,0),
                           "% of observed points within simulated range"))
    }
  }
  
  if (length(out) == 0) {
    return("GOF computed. Use plot(results$gof) and look for observed values (black line) inside simulated distributions.")
  }
  
  paste(c(out, "Visualize with: plot(results$gof)"), collapse = "\n")
}