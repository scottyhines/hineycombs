#' Identify Important Inter-Community Edges in a Network
#'
#' Finds edges that span across different communities within a network, based on a specified community detection algorithm.
#' These inter-community edges are optionally ranked by either the distance between nodes if the edge were removed,
#' or by edge betweenness centrality. These are useful for identifying bridges that tie clusters together.
#'
#' @param g An `igraph` object representing the network.
#' @param method Character string. The community detection method to use. Options are `"louvain"` (default) or `"walktrap"`.
#' @param sort_by Character string. How to rank inter-community edges. Options are:
#'   - `"distance"`: Computes how far apart the nodes would be if the edge were removed (default).
#'   - `"betweenness"`: Ranks by edge betweenness centrality.
#'
#' @return A data frame of inter-community edges with ranking information.
#'
#' @importFrom igraph cluster_louvain cluster_walktrap membership as_data_frame distances edge_betweenness
#' @export
run_connectivity_intercommunity_edges <- function(g, method = "louvain", sort_by = "distance") {
  cat("Detecting communities using", method, "method...\n")
  if (method == "louvain") {
    com <- igraph::cluster_louvain(g)
  } else {
    com <- igraph::cluster_walktrap(g)
  }
  
  membership <- igraph::membership(com)
  cat("Found", max(membership), "communities\n")
  
  edges <- igraph::as_data_frame(g, what = "edges")
  edges$from_comm <- membership[edges$from]
  edges$to_comm <- membership[edges$to]
  
  # Filter for inter-community edges
  inter_edges <- subset(edges, from_comm != to_comm)
  cat("Identified", nrow(inter_edges), "inter-community edges\n")
  
  if (nrow(inter_edges) == 0) {
    warning("No inter-community edges found")
    return(inter_edges)
  }
  
  if (sort_by == "distance") {
    cat("Calculating distances for", nrow(inter_edges), "edges (this may take a while)...\n")
    pb <- txtProgressBar(min = 0, max = nrow(inter_edges), style = 3)
    
    inter_edges$dist <- sapply(1:nrow(inter_edges), function(i) {
      row <- inter_edges[i, ]
      # Temporarily remove the edge and calculate new distance
      g_tmp <- igraph::delete_edges(g, igraph::E(g, P = c(row$from, row$to)))
      dist_val <- igraph::distances(g_tmp, v = row$from, to = row$to)
      setTxtProgressBar(pb, i)
      return(dist_val[1, 1])
    })
    
    close(pb)
    cat("\nSorting by distance...\n")
    inter_edges <- inter_edges[order(-inter_edges$dist), ]
    
  } else if (sort_by == "betweenness") {
    cat("Calculating edge betweenness...\n")
    eb <- igraph::edge_betweenness(g)
    edge_df <- igraph::as_data_frame(g, what = "edges")
    edge_df$betweenness <- eb
    inter_edges <- merge(inter_edges, edge_df, by = c("from", "to"))
    cat("Sorting by betweenness...\n")
    inter_edges <- inter_edges[order(-inter_edges$betweenness), ]
  }
  
  cat("Analysis completed!\n")
  return(inter_edges)
}
