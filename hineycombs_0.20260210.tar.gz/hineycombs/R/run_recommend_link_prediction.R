#' Run Link Prediction via Jaccard Similarity
#'
#' Predicts likely future ties between unconnected nodes using Jaccard similarity.
#' Optionally includes group membership of each node (e.g., gender, team) for intergroup analysis.
#'
#' @param g An igraph object with a "name" vertex attribute.
#' @param group_var Optional. A vertex attribute (e.g., "team", "gender") to include in the output.
#' @param method Similarity method to use. Default is "jaccard". Options: "jaccard", "dice", "invlogweighted", "wnn".
#' @param top_n Optional. Number of top predicted links to return. Returns all if NULL.
#' @param return_group_summary Logical. If TRUE and group_var is supplied, returns a group-to-group summary table.
#'
#' @return A list with predicted links, and optionally, a group summary table.
#' @export
run_recommend_link_prediction <- function(g, group_var = NULL, method = "jaccard", top_n = NULL, return_group_summary = FALSE) {
  if (is.null(igraph::V(g)$name)) {
    stop("Graph must have a 'name' vertex attribute.")
  }
  
  cat("Starting link prediction analysis...\n")
  
  g <- igraph::as.undirected(g)
  
  cat("Calculating", method, "similarity for all node pairs...\n")
  sim <- igraph::similarity(g, method = method)
  
  all_names <- igraph::V(g)$name
  n_nodes <- length(all_names)
  n_possible_pairs <- choose(n_nodes, 2)
  
  cat("Identifying non-connected pairs from", n_possible_pairs, "possible connections...\n")
  all_pairs <- t(combn(all_names, 2))
  
  edge_list <- apply(igraph::get.edgelist(g), 1, function(e) paste(sort(e), collapse = "-"))
  
  non_edges <- all_pairs[!apply(all_pairs, 1, function(e) {
    paste(sort(e), collapse = "-") %in% edge_list
  }), , drop = FALSE]
  
  if (nrow(non_edges) == 0) {
    warning("No non-edges found - graph may be fully connected.")
    return(NULL)
  }
  
  cat("Found", nrow(non_edges), "non-connected pairs to score\n")
  
  name_to_index <- setNames(seq_along(all_names), all_names)
  
  cat("Extracting similarity scores...\n")
  non_edge_scores <- apply(non_edges, 1, function(pair) {
    i <- name_to_index[pair[1]]
    j <- name_to_index[pair[2]]
    sim[i, j]
  })
  
  df <- data.frame(
    from = non_edges[, 1],
    to = non_edges[, 2],
    score = non_edge_scores,
    stringsAsFactors = FALSE
  )
  
  if (!is.null(group_var)) {
    cat("Adding group information...\n")
    group_data <- igraph::vertex_attr(g, group_var)
    if (is.null(group_data)) stop(paste("Group variable", group_var, "not found in graph."))
    
    df <- df %>%
      dplyr::left_join(data.frame(name = all_names, from_group = group_data, stringsAsFactors = FALSE),
                       by = c("from" = "name")) %>%
      dplyr::left_join(data.frame(name = all_names, to_group = group_data, stringsAsFactors = FALSE),
                       by = c("to" = "name"))
  }
  
  cat("Sorting predictions by similarity score...\n")
  df <- df %>% dplyr::arrange(desc(score))
  
  if (!is.null(top_n)) {
    df <- head(df, top_n)
    cat("Returning top", top_n, "predictions\n")
  } else {
    cat("Returning all", nrow(df), "predictions\n")
  }
  
  if (return_group_summary && !is.null(group_var)) {
    cat("Generating group-level summary...\n")
    group_summary <- df %>%
      dplyr::mutate(group_pair = ifelse(from_group < to_group,
                                        paste(from_group, to_group, sep = " - "),
                                        paste(to_group, from_group, sep = " - "))) %>%
      dplyr::group_by(group_pair) %>%
      dplyr::summarise(
        n_predictions = dplyr::n(),
        avg_similarity = mean(score, na.rm = TRUE),
        max_similarity = max(score, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      dplyr::arrange(desc(avg_similarity))
    
    cat("Link prediction completed!\n")
    return(list(
      predicted_links = df,
      group_summary = group_summary
    ))
  } else {
    cat("Link prediction completed!\n")
    return(df)
  }
}
