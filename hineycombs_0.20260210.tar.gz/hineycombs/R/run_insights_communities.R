#' Plot Communities in a Graph using Multiple Detection Algorithms
#'
#' This function detects and visualizes community structures in an \code{igraph} network
#' using various community detection algorithms. The results include modularity scores and 
#' a plotted graph with color-coded communities and degree-based node sizes. The function 
#' also returns a dataframe with node names and their community memberships for each algorithm.
#'
#' @param g An \code{igraph} graph object.
#' @param algorithms A character vector specifying which community detection algorithms to apply.
#'                   Available options include: \code{"walktrap"}, \code{"leading_eigen"},
#'                   \code{"edge_betweenness"}, \code{"optimal"}, \code{"fastgreedy"},
#'                   \code{"spinglass"}, \code{"label_propagation"}, and \code{"multilevel"}.
#' @param min_size Minimum vertex size (default = 5)
#' @param max_size Maximum vertex size (default = 20)
#'
#' @return A dataframe with node names as the first column and community memberships 
#'         for each algorithm applied.
#' @import igraph
#' @import MetBrewer
#' @importFrom scales rescale
#' @export
#'
#' @examples
#' \dontrun{
#' library(igraph)
#' g <- erdos.renyi.game(50, p = 0.1)  # Generate a random graph
#' result <- plot_communities(g, algorithms = c("walktrap", "fastgreedy", "multilevel"))
#' }

run_insights_communities <- function(g, algorithms = c("walktrap", "leading_eigen", "edge_betweenness", 
                                               "optimal", "fastgreedy", "spinglass", 
                                               "label_propagation", "multilevel"),
                             min_size = 5, max_size = 20) {
  # Ensure graph is simplified to remove loops and multiple edges
  g2 <- igraph::simplify(g)
  
  # Define available community detection algorithms using explicit package calls
  community_algorithms <- list(
    walktrap = function(g) igraph::cluster_walktrap(g),
    leading_eigen = function(g) igraph::cluster_leading_eigen(g),
    edge_betweenness = function(g) igraph::cluster_edge_betweenness(g),
    optimal = function(g) igraph::cluster_optimal(g),
    fastgreedy = function(g) igraph::cluster_fast_greedy(g2),
    spinglass = function(g) igraph::cluster_spinglass(g2),
    label_propagation = function(g) igraph::cluster_label_prop(g),
    multilevel = function(g) igraph::cluster_louvain(g)
  )
  
  # Initialize a dataframe to store the community memberships for each algorithm
  community_df <- data.frame(Node = igraph::V(g)$name)
  
  # Generate layout coordinates for consistent plotting
  laycords <- igraph::layout_with_mds(g)
  
  # Calculate degree and scale vertex sizes
  degree_values <- igraph::degree(g)
  if (length(unique(degree_values)) == 1) {
    # If all degrees are the same, use min_size
    scaled_sizes <- rep(min_size, igraph::vcount(g))
  } else {
    # Scale degrees to be between min_size and max_size
    scaled_sizes <- scales::rescale(degree_values, to = c(min_size, max_size))
  }
  
  # Loop through selected algorithms
  cat("Running", length(algorithms), "community detection algorithms...\n")
  pb <- txtProgressBar(min = 0, max = length(algorithms), style = 3)
  
  for (i in seq_along(algorithms)) {
    alg <- algorithms[i]
    if (alg %in% names(community_algorithms)) {
      cat(paste("\nRunning", alg, "algorithm...\n"))
      
      comm <- community_algorithms[[alg]](g)
      modularity_score <- igraph::modularity(comm)
      cat(paste(alg, "modularity:", round(modularity_score, 4), "\n"))
      
      # Store membership in the dataframe
      community_df[[alg]] <- igraph::membership(comm)
      
      # Assign community membership to vertices for visualization
      igraph::V(g)$community <- igraph::membership(comm)
      
      # Generate colors for plotting
      unique_values <- unique(igraph::V(g)$community)
      unique_count <- length(unique_values)
      colrs <- grDevices::adjustcolor(MetBrewer::met.brewer("VanGogh2", unique_count), alpha = 0.5)
      
      # Plot the graph with colored communities
      plot(g, layout = laycords,
           vertex.color = colrs[igraph::V(g)$community],
           main = paste(alg, "Community Detection"),
           vertex.size = scaled_sizes, 
           vertex.label = NA,
           vertex.label.cex = 0.75,
           vertex.label.color = "black",
           vertex.frame.width = 1,
           edge.arrow.size = 0.01,
           edge.arrow.width = 0.01,
           edge.width= .75,
           edge.curved = 0.5)
      
      # Add algorithm name to the plot
      graphics::mtext(alg, side = 1)
      
      # Create ordered legend entries and matching colors
      legend_entries <- paste("Community", sort(unique_values))
      ordered_colors <- colrs[order(unique_values)]
      
      # Add a legend for community memberships
      graphics::legend("bottomleft",
                       title = "Community Membership",
                       legend = legend_entries,
                       pch = 21,
                       col = "#777777",
                       pt.bg = ordered_colors,
                       pt.cex = 2,
                       cex = 0.8,
                       bty = "n",
                       ncol = 1)
      
      # Add information about node sizes
      graphics::mtext(paste("Node size: Degree (", min(degree_values), "-", max(degree_values), ")"),
                      side = 3, line = 0.5, cex = 0.8)
      
      setTxtProgressBar(pb, i)
    } else {
      warning(paste("Algorithm", alg, "not recognized. Skipping."))
      setTxtProgressBar(pb, i)
    }
  }
  
  close(pb)
  cat("\nAll community detection algorithms completed!\n")
  
  return(community_df)
}

