#' Analyze Impact of Node Removal on Network Metrics
#'
#' @description
#' Evaluates the impact of removing specified nodes from a network by calculating various network metrics 
#' before and after node removal.
#'
#' @param graph An igraph object representing the network
#' @param nodes_to_remove A character vector of node names to be removed from the network
#'
#' @return A list containing four elements:
#' \itemize{
#'   \item original_graph: The input graph before node removal
#'   \item modified_graph: The graph after node removal
#'   \item metrics: A dataframe of network metrics before and after node removal
#'   \item changes: A dataframe showing absolute and percentage changes in metrics
#' }
#'
#' @details
#' Calculates the following network metrics:
#' \itemize{
#'   \item Average degree
#'   \item Average betweenness
#'   \item Average closeness
#'   \item Network density
#'   \item Network diameter
#'   \item Average path length
#'   \item Clustering coefficient
#'   \item Degree centralization
#'   \item Number of components
#'   \item Largest component size
#'   \item Assortativity
#'   \item Average eigenvector centrality
#' }
#'
#' Also calculates impact metrics:
#' \itemize{
#'   \item Number of nodes/edges
#'   \item Nodes/edges removed
#'   \item Nodes touched
#'   \item Total weight removed (if weight attribute exists)
#'   \item Percentage metrics for removal impact
#' }
#'
#' @examples
#' \dontrun{
#' g <- igraph::make_ring(10)
#' igraph::V(g)$name <- letters[1:10]
#' results <- run_node_removal_impact(g, c("a", "b"))
#' }
#'
#' @importFrom igraph V E is_directed delete_vertices degree betweenness closeness 
#' @importFrom igraph edge_density diameter mean_distance transitivity centr_degree
#' @importFrom igraph components assortativity_degree eigen_centrality vcount ecount
#' @importFrom igraph neighborhood edge_attr_names
#' @importFrom dplyr bind_rows mutate %>%
#' @importFrom tidyr pivot_longer pivot_wider
#'
#' @export
run_insights_node_removal_impact <- function(graph, nodes_to_remove) {
  
  # Input validation
  if(!is(graph, "igraph")) {
    stop("Input must be an igraph object")
  }
  
  # Validate node names
  valid_nodes <- V(graph)$name
  if(is.null(valid_nodes)) {
    stop("Graph vertices do not have names")
  }
  
  invalid_nodes <- setdiff(nodes_to_remove, valid_nodes)
  if(length(invalid_nodes) > 0) {
    stop(paste("Invalid node names:", paste(invalid_nodes, collapse=", ")))
  }
  
  cat("Analyzing impact of removing", length(nodes_to_remove), "node(s)...\n")
  
  # Convert node names to vertex IDs
  nodes_ids <- which(valid_nodes %in% nodes_to_remove)
  
  # Check if graph is directed
  is_directed <- igraph::is_directed(graph)
  
  # Function to safely calculate metrics
  calculate_metrics <- function(g, is_after=FALSE, original_graph=NULL) {
    
    # Helper function for harmonic closeness (works on disconnected graphs)
    harmonic_closeness <- function(graph) {
      n <- vcount(graph)
      distances <- igraph::distances(graph, mode = "all")
      # Replace infinite distances with 0 (unreachable nodes contribute 0)
      distances[is.infinite(distances)] <- 0
      # Calculate harmonic mean: sum of 1/distance for each node
      harmonic <- apply(distances, 1, function(d) {
        d[d == 0] <- Inf  # Don't count self (distance 0)
        sum(1/d[is.finite(1/d)])
      })
      return(harmonic / (n - 1))  # Normalize by n-1
    }
    
    results <- data.frame(
      # Original metrics
      avg_degree = 0,
      avg_betweenness = 0,
      avg_closeness = 0,
      density = 0,
      diameter = 0,
      avg_path_length = 0,
      clustering_coefficient = 0,
      degree_centralization = 0,
      num_components = 0,
      largest_component_size = 0,
      assortativity = 0,
      avg_eigenvector_centrality = 0,
      
      # New impact metrics
      num_nodes = 0,
      num_edges = 0,
      nodes_removed = 0,
      edges_removed = 0,
      nodes_touched = 0,
      total_weight_removed = 0,
      percent_nodes_removed = 0,
      percent_edges_removed = 0,
      percent_nodes_touched = 0
    )
    
    # Safely calculate metrics
    tryCatch({
      # Original metrics
      results$avg_degree <- mean(igraph::degree(g))
      results$avg_betweenness <- mean(igraph::betweenness(g))
      results$avg_closeness <- mean(harmonic_closeness(g))
      results$density <- igraph::edge_density(g)
      results$diameter <- igraph::diameter(g, directed = FALSE)
      results$avg_path_length <- igraph::mean_distance(g)
      results$clustering_coefficient <- igraph::transitivity(g, type = "global")
      results$degree_centralization <- igraph::centr_degree(g)$centralization
      results$num_components <- igraph::components(g)$no
      results$largest_component_size <- max(igraph::components(g)$csize)
      results$assortativity <- igraph::assortativity_degree(g)
      results$avg_eigenvector_centrality <- mean(igraph::eigen_centrality(g)$vector)
      
      # Impact metrics
      results$num_nodes <- igraph::vcount(g)
      results$num_edges <- igraph::ecount(g)
      
      # Calculate impact metrics only for the "after" state
      if(is_after && !is.null(original_graph)) {
        results$nodes_removed <- vcount(original_graph) - igraph::vcount(g)
        results$edges_removed <- ecount(original_graph) - igraph::ecount(g)
        results$nodes_touched <- length(unique(unlist(neighborhood(original_graph, 
                                                                   order = 1, nodes = which(V(original_graph)$name %in% nodes_to_remove)))))
        
        # Calculate total weight removed if weight attribute exists
        if("weight" %in% edge_attr_names(original_graph)) {
          results$total_weight_removed <- sum(E(original_graph)$weight) - sum(E(g)$weight)
        }
        
        results$percent_nodes_removed <- (results$nodes_removed / vcount(original_graph)) * 100
        results$percent_edges_removed <- (results$edges_removed / ecount(original_graph)) * 100
        results$percent_nodes_touched <- (results$nodes_touched / vcount(original_graph)) * 100
      }
      
    }, error = function(e) {
      warning("Error calculating some metrics: ", e$message)
    })
    
    return(results)
  }
  
  # Calculate metrics before removal
  cat("Calculating baseline metrics...\n")
  metrics_before <- calculate_metrics(graph, is_after=FALSE)
  
  # Remove nodes
  cat("Removing nodes from network...\n")
  graph_after <- delete_vertices(graph, nodes_ids)
  
  # Calculate metrics after removal with impact metrics
  cat("Calculating post-removal metrics...\n")
  metrics_after <- calculate_metrics(graph_after, is_after=TRUE, original_graph=graph)
  
  # Combine results
  cat("Computing changes...\n")
  results <- bind_rows(
    metrics_before %>% mutate(state = "Before"),
    metrics_after %>% mutate(state = "After")
  )
  
  # Calculate changes
  changes <- results %>%
    pivot_longer(-state, names_to = "metric", values_to = "value") %>%
    pivot_wider(names_from = state, values_from = value) %>%
    mutate(
      absolute_change = After - Before,
      percent_change = ifelse(Before != 0, (After - Before) / Before * 100, NA)
    )
  
  cat("Node removal impact analysis completed!\n")
  
  # Return results
  list(
    original_graph = graph,
    modified_graph = graph_after,
    metrics = results,
    changes = changes
  )
}
