#' Compute edge embeddedness (shared neighbors) and a friendship/alliance score
#'
#' Embeddedness = number of shared neighbors between edge endpoints.
#' In dense networks, ties that are both strong (high weight) and highly embedded
#' (many shared neighbors) are often good "friendship/alliance" candidates.
#'
#' The default score is: z(weight) + z(embeddedness), with safe handling when SD=0.
#'
#' @param g An igraph object.
#' @param weight_attr Character. Edge attribute name for weights. If missing, weight=1.
#' @param neighbor_mode Character. For directed graphs: "all", "out", or "in" neighbor sets used.
#' @param score_weights Numeric length-2 named vector (weight, embeddedness) to weight z-scores.
#' @param na_weight_zero Logical. If TRUE, NA weights treated as 0.
#' @param return_graph Logical. If TRUE, attaches edge attributes `embeddedness` and `friendship_score`
#'   and returns the igraph. Otherwise returns a data.frame.
#'
#' @return Either a data.frame (default) or igraph (if return_graph=TRUE).
#' @export
run_dense_edge_embeddedness_and_score <- function(
    g,
    weight_attr = "weight",
    neighbor_mode = c("all", "out", "in"),
    score_weights = c(weight = 1, embeddedness = 1),
    na_weight_zero = TRUE,
    return_graph = FALSE
) {
  stopifnot(igraph::is_igraph(g))
  neighbor_mode <- match.arg(neighbor_mode)
  
  if (igraph::ecount(g) == 0) {
    out <- data.frame(
      from = character(0),
      to = character(0),
      weight = numeric(0),
      embeddedness = integer(0),
      friendship_score = numeric(0)
    )
    return(if (return_graph) g else out)
  }
  
  # vertex names fallback
  if (is.null(igraph::V(g)$name)) igraph::V(g)$name <- as.character(seq_len(igraph::vcount(g)))
  
  eds <- igraph::as_edgelist(g, names = TRUE)
  w <- igraph::edge_attr(g, weight_attr)
  if (is.null(w)) w <- rep(1, igraph::ecount(g))
  w <- as.numeric(w)
  if (na_weight_zero) w[is.na(w)] <- 0
  
  # Precompute neighbor sets by vertex index
  neigh_list <- igraph::adjacent_vertices(g, igraph::V(g), mode = neighbor_mode)
  vnames <- igraph::V(g)$name
  name_to_idx <- setNames(seq_along(vnames), vnames)
  
  emb <- integer(nrow(eds))
  for (i in seq_len(nrow(eds))) {
    a <- eds[i, 1]
    b <- eds[i, 2]
    ia <- name_to_idx[[a]]
    ib <- name_to_idx[[b]]
    
    na <- names(neigh_list[[ia]])
    nb <- names(neigh_list[[ib]])
    emb[i] <- length(intersect(na, nb))
  }
  
  z <- function(x) {
    x <- as.numeric(x)
    ok <- is.finite(x)
    if (sum(ok) < 2 || stats::sd(x[ok]) == 0) return(rep(0, length(x)))
    (x - mean(x[ok])) / stats::sd(x[ok])
  }
  
  score <- as.numeric(score_weights[["weight"]]) * z(w) +
    as.numeric(score_weights[["embeddedness"]]) * z(emb)
  
  if (return_graph) {
    igraph::E(g)$embeddedness <- emb
    igraph::E(g)$friendship_score <- score
    return(g)
  }
  
  out <- data.frame(
    from = eds[, 1],
    to = eds[, 2],
    weight = w,
    embeddedness = emb,
    friendship_score = score
  )
  out[order(-out$friendship_score), ]
}