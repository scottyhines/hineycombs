#' Calculate Clique Statistics for Network Nodes
#'
#' @description 
#' Calculates the number of cliques each node belongs to and identifies nodes that are members
#' of the largest cliques in the network.
#'
#' @param g An igraph object representing the network
#'
#' @return A data frame with the following columns:
#' \itemize{
#'   \item node - Node ID number
#'   \item clique_count - Number of cliques the node belongs to
#'   \item in_largest_clique - Logical indicating if node is in largest clique
#'   \item name - Node name (if present in original graph)
#' }
#'
#' @details 
#' The function considers all cliques of size 2 or greater. For directed graphs,
#' the function first converts the graph to undirected using collapse mode.
#' Single nodes are not counted as cliques.
#'
#' @examples
#' \dontrun{
#' # Create example graph
#' g <- igraph::make_ring(10)
#' 
#' # Calculate clique statistics
#' clique_stats <- run_cliques(g)
#' 
#' # View top results
#' head(clique_stats[order(-clique_stats$clique_count),])
#' }
#'
#' @export
#' @importFrom igraph is_directed as.undirected cliques largest_cliques vcount V
run_embedded_cliques <- function(g) {
  # Convert to undirected if directed
  if(igraph::is_directed(g)) {
    g <- igraph::as.undirected(g, mode="collapse")
  }
  
  cat("Finding all cliques in the network...\n")
  # Get all cliques (excluding single nodes)
  all_cliques <- igraph::cliques(g, min=2)
  cat("Found", length(all_cliques), "cliques\n")
  
  # Get largest cliques
  largest <- igraph::largest_cliques(g)
  cat("Largest clique size:", length(largest[[1]]), "nodes\n")
  
  # Get nodes in largest cliques
  nodes_in_largest <- unique(unlist(largest))
  
  # Initialize result dataframe with all vertices
  result <- data.frame(
    node = 1:igraph::vcount(g),
    clique_count = 0,
    in_largest_clique = FALSE,
    stringsAsFactors = FALSE
  )
  
  # Count cliques per node
  cat("Counting clique memberships for", igraph::vcount(g), "nodes...\n")
  pb <- txtProgressBar(min = 0, max = igraph::vcount(g), style = 3)
  
  for(v in 1:igraph::vcount(g)) {
    result$clique_count[v] <- sum(sapply(all_cliques, function(x) v %in% x))
    setTxtProgressBar(pb, v)
  }
  
  close(pb)
  cat("\nClique analysis completed!\n")
  
  # Mark nodes in largest cliques
  result$in_largest_clique <- result$node %in% nodes_in_largest
  
  # If graph has vertex names, add them
  if(!is.null(igraph::V(g)$name)) {
    result$name <- igraph::V(g)$name
  }
  
  return(result)
}
