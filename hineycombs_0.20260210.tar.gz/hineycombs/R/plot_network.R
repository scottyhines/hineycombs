#' Plot Network Graph
#'
#' Creates a visualization of a network graph using MDS layout, with optional group-based node coloring
#' and degree-based vertex sizing.
#'
#' @param g An igraph object representing the network to be plotted
#' @param group_var Character string specifying the vertex attribute name for grouping.
#'                 If NULL (default), all nodes will be colored the same.
#' @param min_size Minimum vertex size (default = 5)
#' @param max_size Maximum vertex size (default = 15)
#' @param show_labels Logical. If TRUE, displays vertex labels. Default is FALSE.
#'
#' @details
#' The function creates a network visualization using multidimensional scaling (MDS) layout.
#' Vertex sizes are scaled based on node degrees between min_size and max_size.
#' If a grouping variable is specified, nodes will be colored according to their group
#' membership using the MetBrewer "Johnson" palette.
#'
#' @export
plot_network <- function(g, group_var = NULL, min_size = 5, max_size = 15, show_labels = FALSE) {
  # Set default plotting parameters
  edge_arrow_size <- 0.01
  edge_arrow_width <- 0.01
  default_vertex_color <- "gray70"
  default_edge_color <- "gray80"
  
  # Calculate degree and scale vertex sizes
  degrees <- igraph::degree(g)
  if (length(unique(degrees)) == 1) {
    vertex_sizes <- rep(min_size, length(degrees))
  } else {
    vertex_sizes <- scales::rescale(degrees, 
                                    to = c(min_size, max_size),
                                    from = range(degrees))
  }
  
  # Calculate layout
  layout_mds <- igraph::layout_with_mds(g)
  
  # Handle vertex labels
  if (show_labels) {
    vertex_labels <- igraph::V(g)$name
    if (is.null(vertex_labels)) {
      vertex_labels <- as.character(1:igraph::vcount(g))
    }
  } else {
    vertex_labels <- NA
  }
  
  if (!is.null(group_var)) {
    # Get group membership safely
    if (!group_var %in% igraph::vertex_attr_names(g)) {
      stop(paste("Group variable", group_var, "not found in vertex attributes"))
    }
    group_membership <- igraph::vertex_attr(g, group_var)
    unique_groups <- unique(group_membership)
    
    # Create color palette based on number of unique groups
    palette <- MetBrewer::met.brewer("Johnson", n = length(unique_groups))
    
    # Assign colors to nodes based on group membership
    node_colors <- palette[match(group_membership, unique_groups)]
    
    # Create plot
    plot(g, layout = layout_mds,
         vertex.color = node_colors,
         vertex.size = vertex_sizes,
         edge.arrow.size = edge_arrow_size,
         edge.arrow.width = edge_arrow_width,
         vertex.label = vertex_labels,
         vertex.label.dist = 0.5,    # Add some distance between node and label
         vertex.label.color = "black",
         edge.color = default_edge_color,
         main = "Network Plot (MDS)")
    
    # Add legend
    legend("topright", 
           legend = unique_groups,
           col = palette, 
           pch = 16,
           bty = "n", 
           cex = 0.8)
    
  } else {
    # Create plot without group colors
    plot(g, layout = layout_mds,
         vertex.color = default_vertex_color,
         vertex.size = vertex_sizes,
         edge.arrow.size = edge_arrow_size,
         edge.arrow.width = edge_arrow_width,
         vertex.label = vertex_labels,
         vertex.label.dist = 0.5,    # Add some distance between node and label
         vertex.label.color = "black",
         edge.color = default_edge_color,
         main = "Network Plot (MDS)")
  }
}