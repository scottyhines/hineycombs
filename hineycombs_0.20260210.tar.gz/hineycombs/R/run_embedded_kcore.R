#' Calculate K-core Statistics for Network Nodes
#'
#' @description 
#' Calculates k-core membership and coreness for each node in the network. A k-core is a 
#' maximal subgraph in which every node has a degree of at least k. A node's coreness is 
#' the highest k for which it belongs to a k-core.
#'
#' @param g An igraph object representing the network
#' @param mode Character string, specifying how to handle edge directions. 
#'        Can be "all" (default), "in", or "out". Ignored for undirected graphs.
#'
#' @return A data frame with the following columns:
#' \itemize{
#'   \item node - Node ID number
#'   \item coreness - The node's coreness value
#'   \item max_core - Logical indicating if node is in the highest k-core
#'   \item name - Node name (if present in original graph)
#' }
#'
#' @details 
#' The function calculates the coreness of each vertex using igraph's coreness function.
#' The max_core column identifies nodes that are members of the highest k-core in the network.
#'
#' @examples
#' \dontrun{
#' # Create example ring graph
#' g <- igraph::make_ring(10)
#' 
#' # Calculate k-core statistics
#' kcore_stats <- run_kcore(g)
#' 
#' # View results
#' head(kcore_stats[order(-kcore_stats$coreness),])
#' }
#'
#' @export
#' @importFrom igraph coreness vcount V
run_embedded_kcore <- function(g, mode = "all") {
  # Calculate coreness for each vertex
  core_numbers <- igraph::coreness(g, mode = mode)
  
  # Initialize result dataframe with all vertices
  result <- data.frame(
    node = 1:igraph::vcount(g),
    coreness = core_numbers,
    max_core = FALSE,
    stringsAsFactors = FALSE
  )
  
  # Identify nodes in the maximum k-core
  max_core_number <- max(core_numbers)
  result$max_core <- result$coreness == max_core_number
  
  # If graph has vertex names, add them
  if(!is.null(igraph::V(g)$name)) {
    result$name <- igraph::V(g)$name
  }
  
  # Add attributes to describe the analysis
  attr(result, "max_coreness") <- max_core_number
  attr(result, "mode") <- mode
  
  class(result) <- c("kcore_stats", "data.frame")
  
  return(result)
}
