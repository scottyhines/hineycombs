#' Perform Community Detection and Block Analysis
#'
#' @description
#' Identifies cohesive subgroups (communities/blocks) in your network and analyzes their
#' characteristics. This helps understand organizational silos, informal groups, and
#' communication patterns. Returns easy-to-interpret results with visualizations.
#'
#' @param g An igraph graph object (directed or undirected)
#' @param method Community detection method. Options:
#'   \itemize{
#'     \item "louvain" (default) - Fast, good for large networks
#'     \item "walktrap" - Based on random walks
#'     \item "fastgreedy" - Fast modularity optimization
#'     \item "infomap" - Information-theoretic approach
#'   }
#' @param min_block_size Minimum number of nodes to be considered a block (default = 3)
#' @param compare_attribute Optional. Name of vertex attribute to compare against blocks
#'        (e.g., "department", "gender") to see if blocks align with formal structure
#' @param plot Logical. Create visualizations? (default = TRUE)
#'
#' @return A list containing:
#' \itemize{
#'   \item \code{node_blocks}: Dataframe with each node's block assignment
#'   \item \code{block_summary}: Summary statistics for each block
#'   \item \code{block_interactions}: Matrix showing connections between blocks
#'   \item \code{modularity}: Overall modularity score (higher = stronger blocks)
#'   \item \code{attribute_comparison}: If compare_attribute provided, shows overlap
#'   \item \code{graph}: Original graph with block assignments added
#' }
#'
#' @details
#' \strong{What are blocks/communities?}
#' Groups of nodes that are more densely connected to each other than to the rest
#' of the network. In organizations, these often represent:
#' - Informal working groups
#' - Communication silos
#' - Collaborative clusters
#' - Social cliques
#'
#' \strong{Modularity score:}
#' - > 0.3: Significant community structure
#' - 0.3-0.5: Moderate structure
#' - > 0.5: Strong community structure
#'
#' @examples
#' \dontrun{
#' # Basic usage
#' results <- run_insights_block_modeling(g)
#' 
#' # Compare blocks to formal departments
#' results <- run_insights_block_modeling(g, compare_attribute = "department")
#' 
#' # View block assignments
#' head(results$node_blocks)
#' 
#' # See which blocks interact most
#' results$block_interactions
#' }
#'
#' @importFrom igraph cluster_louvain cluster_walktrap cluster_fast_greedy cluster_infomap
#' @importFrom igraph membership modularity V E vcount ecount as_edgelist vertex_attr
#' @importFrom igraph degree layout_with_fr as_undirected
#' @importFrom dplyr group_by summarise n left_join arrange desc
#' @importFrom scales rescale
#'
#' @export
run_insights_block_modeling <- function(g, 
                                        method = c("louvain", "walktrap", "fastgreedy", "infomap"),
                                        min_block_size = 3,
                                        compare_attribute = NULL,
                                        plot = TRUE) {
  
  method <- match.arg(method)
  
  # Ensure we have node names
  if (is.null(igraph::V(g)$name)) {
    igraph::V(g)$name <- as.character(seq_len(igraph::vcount(g)))
  }
  
  cat("Detecting communities using", method, "method...\n")
  cat("This may take a moment for large networks...\n")
  
  # Convert to undirected for community detection if needed
  g_undirected <- if (igraph::is_directed(g)) {
    igraph::as_undirected(g, mode = "collapse")
  } else {
    g
  }
  
  # Run community detection
  communities <- switch(method,
    louvain = igraph::cluster_louvain(g_undirected),
    walktrap = igraph::cluster_walktrap(g_undirected),
    fastgreedy = igraph::cluster_fast_greedy(g_undirected),
    infomap = igraph::cluster_infomap(g_undirected)
  )
  
  cat("Community detection completed!\n")
  
  # Extract memberships
  block_membership <- igraph::membership(communities)
  mod_score <- igraph::modularity(communities)
  
  cat("Found", max(block_membership), "communities\n")
  cat("Modularity score:", round(mod_score, 3), "\n")
  
  if (mod_score < 0.3) {
    cat("Note: Low modularity suggests weak community structure\n")
  } else if (mod_score > 0.5) {
    cat("Note: High modularity indicates strong community structure\n")
  }
  
  # Create node-level dataframe
  node_blocks <- data.frame(
    node = igraph::V(g)$name,
    block = block_membership,
    degree = igraph::degree(g),
    stringsAsFactors = FALSE
  )
  
  # Add attribute if provided
  if (!is.null(compare_attribute) && compare_attribute %in% igraph::vertex_attr_names(g)) {
    node_blocks[[compare_attribute]] <- igraph::vertex_attr(g, compare_attribute)
  }
  
  # Filter small blocks
  block_sizes <- table(block_membership)
  small_blocks <- as.numeric(names(block_sizes[block_sizes < min_block_size]))
  
  if (length(small_blocks) > 0) {
    cat("Filtering", length(small_blocks), "blocks with <", min_block_size, "nodes\n")
    node_blocks$block[node_blocks$block %in% small_blocks] <- NA
  }
  
  # Block summary statistics
  block_summary <- node_blocks %>%
    dplyr::group_by(block) %>%
    dplyr::summarise(
      size = dplyr::n(),
      avg_degree = mean(degree, na.rm = TRUE),
      total_degree = sum(degree, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    dplyr::arrange(dplyr::desc(size))
  
  # Calculate internal vs external edges for each block
  edges <- igraph::as_edgelist(g, names = TRUE)
  edge_blocks_from <- block_membership[match(edges[,1], igraph::V(g)$name)]
  edge_blocks_to <- block_membership[match(edges[,2], igraph::V(g)$name)]
  
  internal_edges <- tapply(edge_blocks_from == edge_blocks_to, edge_blocks_from, sum, na.rm = TRUE)
  external_edges <- tapply(edge_blocks_from != edge_blocks_to, edge_blocks_from, sum, na.rm = TRUE)
  
  block_summary$internal_edges <- as.numeric(internal_edges[as.character(block_summary$block)])
  block_summary$external_edges <- as.numeric(external_edges[as.character(block_summary$block)])
  block_summary$internal_edges[is.na(block_summary$internal_edges)] <- 0
  block_summary$external_edges[is.na(block_summary$external_edges)] <- 0
  
  block_summary$cohesion <- block_summary$internal_edges / 
    (block_summary$internal_edges + block_summary$external_edges)
  block_summary$cohesion[is.na(block_summary$cohesion)] <- 0
  
  # Block interaction matrix
  valid_blocks <- block_summary$block[!is.na(block_summary$block)]
  interaction_matrix <- matrix(0, 
                               nrow = length(valid_blocks), 
                               ncol = length(valid_blocks),
                               dimnames = list(paste("Block", valid_blocks), 
                                             paste("Block", valid_blocks)))
  
  for (i in seq_len(nrow(edges))) {
    b_from <- edge_blocks_from[i]
    b_to <- edge_blocks_to[i]
    if (!is.na(b_from) && !is.na(b_to) && b_from %in% valid_blocks && b_to %in% valid_blocks) {
      row_idx <- which(valid_blocks == b_from)
      col_idx <- which(valid_blocks == b_to)
      interaction_matrix[row_idx, col_idx] <- interaction_matrix[row_idx, col_idx] + 1
    }
  }
  
  # Compare to attribute if provided
  attribute_comparison <- NULL
  if (!is.null(compare_attribute) && compare_attribute %in% names(node_blocks)) {
    cat("\nComparing blocks to", compare_attribute, "...\n")
    
    comparison_table <- table(node_blocks$block, node_blocks[[compare_attribute]])
    attribute_comparison <- list(
      contingency_table = as.data.frame.matrix(comparison_table),
      overlap_summary = node_blocks %>%
        dplyr::group_by(block, .data[[compare_attribute]]) %>%
        dplyr::summarise(count = dplyr::n(), .groups = "drop") %>%
        dplyr::arrange(block, dplyr::desc(count))
    )
    
    print(attribute_comparison$contingency_table)
  }
  
  # Add block to graph
  igraph::V(g)$block <- block_membership
  
  # Plotting
  if (plot && requireNamespace("grDevices", quietly = TRUE)) {
    cat("\nGenerating visualizations...\n")
    
    # Color palette
    n_blocks <- length(valid_blocks)
    if (n_blocks <= 12) {
      colors <- c("#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00", "#FFFF33",
                  "#A65628", "#F781BF", "#999999", "#66C2A5", "#FC8D62", "#8DA0CB")[1:n_blocks]
    } else {
      colors <- grDevices::rainbow(n_blocks)
    }
    
    node_colors <- colors[match(block_membership, valid_blocks)]
    node_colors[is.na(node_colors)] <- "gray80"
    
    # Node sizes based on degree
    node_sizes <- scales::rescale(igraph::degree(g), to = c(3, 15))
    
    # Layout
    layout <- igraph::layout_with_fr(g_undirected)
    
    # Plot
    par(mar = c(1, 1, 3, 1))
    plot(g_undirected,
         vertex.color = node_colors,
         vertex.size = node_sizes,
         vertex.label = NA,
         vertex.frame.color = "white",
         edge.arrow.size = 0.3,
         edge.color = "gray70",
         edge.width = 0.8,
         layout = layout,
         main = paste("Community Structure (Modularity =", round(mod_score, 3), ")"))
    
    # Legend
    legend("bottomright",
           legend = paste("Block", valid_blocks, "(n=", block_summary$size, ")"),
           col = colors,
           pch = 19,
           pt.cex = 1.5,
           cex = 0.8,
           bty = "n")
  }
  
  # Print summary
  cat("\n=== BLOCK SUMMARY ===\n")
  print(block_summary)
  
  cat("\n=== INTERPRETATION ===\n")
  cat("Cohesion score: proportion of edges within block vs. across blocks\n")
  cat("- High cohesion (>0.7): Tight-knit group, potential silo\n")
  cat("- Medium cohesion (0.4-0.7): Balanced internal/external connections\n")
  cat("- Low cohesion (<0.4): Loosely connected, well-integrated with network\n")
  
  return(list(
    node_blocks = node_blocks,
    block_summary = block_summary,
    block_interactions = interaction_matrix,
    modularity = mod_score,
    attribute_comparison = attribute_comparison,
    graph = g
  ))
}
