#' Diagnose Issues in a Node Metadata Table
#'
#' @description
#' `diagnose_nodes()` inspects a node metadata table and identifies:
#' (1) nodes that contain missing metadata (excluding any explicitly exempted
#' columns), and (2) potential duplicate node names detected via string distance
#' and substring matching. This is useful for validating character or entity
#' lists prior to building a network.
#'
#' @details
#' The function performs three diagnostics:
#'
#' **1. Missing metadata detection**
#'
#' A node is flagged as having missing metadata if *any* of the metadata
#' columns—except those listed in `exclude_cols`—contain either `NA` or the
#' literal string `"missing"` in any capitalization (e.g., `"MISSING"`,
#' `"Missing"`). The identifier column specified in `name_col` is never checked.
#'
#' **2. String-distance duplicate suggestions**
#'
#' Pairwise Levenshtein string distances are computed across all node names.
#' Pairs with distance greater than 0 and less than or equal to 6 are returned
#' as potential duplicates (e.g., `"CHRISTOPHER PIKE"` vs `"CHRISTOPER PIKE"`).
#'
#' **3. Substring-based duplicate suggestions**
#'
#' Returns name pairs where one name appears as a standalone word inside another
#' (e.g., `"PIKE"` inside `"CHRISTOPHER PIKE"`), useful for catching short/long
#' form duplicates.
#'
#' @param nodes A data frame containing node metadata. Must contain at least the
#'   identifier column specified in `name_col`.
#' @param name_col A string giving the name of the node identifier column.
#'   Defaults to `"name"`.
#' @param exclude_cols A character vector of column names that should be ignored
#'   when checking for missing metadata. Defaults to `"series"`, which is often
#'   complete for all nodes.
#'
#' @return
#' A list with three elements:
#'
#' \describe{
#'   \item{nodes_missing_metadata}{
#'     A data frame of nodes whose metadata contains missing values (NA or the
#'     string `"missing"`), excluding any columns listed in `exclude_cols`.
#'   }
#'
#'   \item{possible_duplicates_stringdist}{
#'     A tibble containing node name pairs with small Levenshtein distance,
#'     flagged as possible duplicates.
#'   }
#'
#'   \item{possible_duplicates_substring}{
#'     A tibble containing node name pairs where one appears as a word within
#'     the other.
#'   }
#' }
#'
#' @examples
#' \dontrun{
#' diagnose_nodes(final_nodes,
#'                name_col = "name",
#'                exclude_cols = c("series"))
#' }
#'
#' @importFrom dplyr filter if_any all_of %>%
#' @importFrom stringdist stringdistmatrix
#' @importFrom stringr str_detect
#' @importFrom tibble tibble
#'
#' @export
diagnose_nodes <- function(nodes,
                           name_col = "name",
                           exclude_cols = c("series")) {
  
  # ---------------------------------------------------------------------------
  # 1. Determine which metadata columns to check
  # ---------------------------------------------------------------------------
  other_cols <- setdiff(names(nodes), name_col)
  check_cols <- setdiff(other_cols, exclude_cols)
  
  if (length(check_cols) == 0) {
    warning("No columns left to check after exclusions.")
    return(list(
      nodes_missing_metadata = nodes[0, ],
      possible_duplicates_stringdist = tibble(),
      possible_duplicates_substring = tibble()
    ))
  }
  
  # ---------------------------------------------------------------------------
  # 2. Nodes with ANY missing metadata (except excluded columns)
  # ---------------------------------------------------------------------------
  nodes_with_missing <- nodes %>%
    filter(
      if_any(
        all_of(check_cols),
        ~ is.na(.x) | tolower(.x) == "missing"
      )
    )
  
  # ---------------------------------------------------------------------------
  # 3. String distance duplicate suggestions
  # ---------------------------------------------------------------------------
  name_vec <- unique(nodes[[name_col]])
  
  dist_mat <- stringdistmatrix(name_vec, name_vec, method = "lv")
  rownames(dist_mat) <- colnames(dist_mat) <- name_vec
  
  close_pairs_idx <- which(dist_mat > 0 & dist_mat <= 6, arr.ind = TRUE)
  
  string_dist_pairs <- tibble(
    name1 = rownames(dist_mat)[close_pairs_idx[, 1]],
    name2 = colnames(dist_mat)[close_pairs_idx[, 2]],
    distance = dist_mat[close_pairs_idx]
  ) %>%
    filter(name1 < name2)
  
  # ---------------------------------------------------------------------------
  # 4. Substring-based duplicate suggestions
  # ---------------------------------------------------------------------------
  substring_pairs <- expand.grid(
    a = name_vec,
    b = name_vec,
    stringsAsFactors = FALSE
  ) %>%
    filter(a != b) %>%
    filter(str_detect(b, paste0("\\b", a, "\\b")))
  
  # ---------------------------------------------------------------------------
  # 5. Return combined diagnostics
  # ---------------------------------------------------------------------------
  list(
    nodes_missing_metadata = nodes_with_missing,
    possible_duplicates_stringdist = string_dist_pairs,
    possible_duplicates_substring = substring_pairs
  )
}
