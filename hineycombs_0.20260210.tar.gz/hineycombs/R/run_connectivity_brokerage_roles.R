#' Calculate Gould-Fernandez Brokerage Roles
#'
#' @description
#' Implements the Gould-Fernandez brokerage typology (1989) which identifies five distinct
#' brokerage roles based on group membership patterns in triads. This is particularly useful
#' for understanding how individuals broker information and resources between organizational
#' groups, departments, or communities.
#'
#' @param g An igraph object representing the network (must be directed)
#' @param group_attr Character string specifying the vertex attribute containing group memberships
#' @param normalize Logical. If TRUE, normalizes raw counts by the expected count under random
#'                  group assignment. Default is FALSE.
#'
#' @return A data frame with one row per node containing:
#' \itemize{
#'   \item node - Node name/ID
#'   \item group - Group membership
#'   \item coordinator - Broker within same group (i->b->j, all same group)
#'   \item gatekeeper - Controls information entering their group (i->b->j, i external, b&j same)
#'   \item representative - Controls information leaving their group (i->b->j, i&b same, j external)
#'   \item consultant - Mediates between two other groups (i->b->j, all different groups)
#'   \item liaison - Mediates while being external (i->b->j, i&j same, b different)
#'   \item total_brokerage - Sum of all brokerage roles
#'   \item primary_role - The dominant brokerage role for this node
#' }
#'
#' @details
#' The five brokerage roles are defined by the group membership pattern in directed triads
#' where node b mediates between i and j (i->b->j):
#'
#' \strong{Coordinator}: All three nodes in the same group. Brokers within-group connections.
#'
#' \strong{Gatekeeper}: i is external, b and j are in the same group. Controls what enters the group.
#'
#' \strong{Representative}: i and b are in the same group, j is external. Controls what leaves the group.
#'
#' \strong{Consultant}: All three nodes in different groups. Bridges multiple groups.
#'
#' \strong{Liaison}: i and j are in the same group, b is external. Connects a group from outside.
#'
#' @references
#' Gould, R. V., & Fernandez, R. M. (1989). Structures of mediation: A formal approach to
#' brokerage in transaction networks. Sociological Methodology, 19, 89-126.
#'
#' @examples
#' \dontrun{
#' library(igraph)
#' g <- make_graph("Zachary")
#' V(g)$department <- sample(c("Sales", "Engineering", "Marketing"), 
#'                           vcount(g), replace = TRUE)
#' 
#' # Calculate brokerage roles
#' brokerage <- run_connectivity_brokerage_roles(g, "department")
#' 
#' # Find top gatekeepers
#' head(brokerage[order(-brokerage$gatekeeper), ])
#' }
#'
#' @importFrom igraph V E is_directed vcount vertex_attr as_edgelist
#' @importFrom dplyr case_when
#'
#' @export
run_connectivity_brokerage_roles <- function(g, group_attr, normalize = FALSE) {
  
  # Input validation and auto-conversion
  if (!igraph::is_directed(g)) {
    cat("Graph is undirected. Converting to directed using 'mutual' mode...\n")
    g <- igraph::as.directed(g, mode = "mutual")
  }
  
  cat("Graph properties: ", igraph::vcount(g), "vertices,", igraph::ecount(g), "edges\n")
  
  if (!(group_attr %in% igraph::vertex_attr_names(g))) {
    stop(paste("Attribute", group_attr, "not found in graph"))
  }
  
  # Get node names and groups
  node_names <- igraph::V(g)$name
  if (is.null(node_names)) {
    node_names <- as.character(seq_len(igraph::vcount(g)))
    igraph::V(g)$name <- node_names
  }
  
  groups <- igraph::vertex_attr(g, group_attr)
  
  # Handle missing group values
  if (any(is.na(groups))) {
    warning("Some nodes have NA group membership - treating as separate group 'NA'")
    groups[is.na(groups)] <- "NA"
  }
  
  # Initialize brokerage counts
  n <- igraph::vcount(g)
  brokerage <- data.frame(
    node = node_names,
    group = groups,
    coordinator = 0,
    gatekeeper = 0,
    representative = 0,
    consultant = 0,
    liaison = 0,
    stringsAsFactors = FALSE
  )
  
  # Get edge list
  edges <- igraph::as_edgelist(g, names = TRUE)
  
  cat("Calculating brokerage roles for", n, "nodes...\n")
  pb <- txtProgressBar(min = 0, max = n, style = 3)
  
  # For each potential broker b
  for (b_idx in seq_len(n)) {
    b <- node_names[b_idx]
    b_group <- groups[b_idx]
    
    # Find all i->b edges (incoming to b)
    incoming <- edges[edges[, 2] == b, 1, drop = TRUE]
    
    # Find all b->j edges (outgoing from b)
    outgoing <- edges[edges[, 1] == b, 2, drop = TRUE]
    
    # For each i->b->j path
    if (length(incoming) > 0 && length(outgoing) > 0) {
      for (i in incoming) {
        i_group <- groups[which(node_names == i)]
        
        for (j in outgoing) {
          # Skip if i == j (would be a cycle)
          if (i == j) next
          
          j_group <- groups[which(node_names == j)]
          
          # Classify the brokerage role based on group pattern
          # Pattern: i -> b -> j
          
          if (i_group == b_group && b_group == j_group) {
            # All same group: Coordinator
            brokerage$coordinator[b_idx] <- brokerage$coordinator[b_idx] + 1
            
          } else if (i_group != b_group && b_group == j_group) {
            # i external, b and j same: Gatekeeper
            brokerage$gatekeeper[b_idx] <- brokerage$gatekeeper[b_idx] + 1
            
          } else if (i_group == b_group && b_group != j_group) {
            # i and b same, j external: Representative
            brokerage$representative[b_idx] <- brokerage$representative[b_idx] + 1
            
          } else if (i_group != b_group && b_group != j_group && i_group != j_group) {
            # All different: Consultant
            brokerage$consultant[b_idx] <- brokerage$consultant[b_idx] + 1
            
          } else if (i_group == j_group && b_group != i_group) {
            # i and j same, b different: Liaison
            brokerage$liaison[b_idx] <- brokerage$liaison[b_idx] + 1
          }
        }
      }
    }
    
    setTxtProgressBar(pb, b_idx)
  }
  close(pb)
  
  # Normalize if requested
  if (normalize) {
    cat("\nNormalizing brokerage scores...\n")
    
    # Calculate expected counts under random group assignment
    group_sizes <- table(groups)
    n_groups <- length(group_sizes)
    total_paths <- sum(brokerage[, c("coordinator", "gatekeeper", "representative", 
                                     "consultant", "liaison")])
    
    if (total_paths > 0) {
      # Expected probabilities for each role type
      # These are based on random group assignment probabilities
      for (i in seq_len(n)) {
        b_group <- groups[i]
        p_same <- group_sizes[b_group] / n
        p_diff <- 1 - p_same
        
        # Expected counts (simplified - assumes independence)
        in_degree <- sum(edges[, 2] == node_names[i])
        out_degree <- sum(edges[, 1] == node_names[i])
        potential_paths <- in_degree * out_degree
        
        if (potential_paths > 0) {
          # Normalize each role by its expected count
          expected_coordinator <- potential_paths * p_same * p_same
          expected_gatekeeper <- potential_paths * p_diff * p_same
          expected_representative <- potential_paths * p_same * p_diff
          expected_consultant <- potential_paths * p_diff * p_diff * ((n_groups - 2) / n_groups)
          expected_liaison <- potential_paths * p_diff * p_same
          
          if (expected_coordinator > 0) 
            brokerage$coordinator[i] <- brokerage$coordinator[i] / expected_coordinator
          if (expected_gatekeeper > 0) 
            brokerage$gatekeeper[i] <- brokerage$gatekeeper[i] / expected_gatekeeper
          if (expected_representative > 0) 
            brokerage$representative[i] <- brokerage$representative[i] / expected_representative
          if (expected_consultant > 0) 
            brokerage$consultant[i] <- brokerage$consultant[i] / expected_consultant
          if (expected_liaison > 0) 
            brokerage$liaison[i] <- brokerage$liaison[i] / expected_liaison
        }
      }
    }
  }
  
  # Calculate total brokerage
  brokerage$total_brokerage <- rowSums(brokerage[, c("coordinator", "gatekeeper", 
                                                      "representative", "consultant", "liaison")])
  
  # Identify primary role
  role_cols <- c("coordinator", "gatekeeper", "representative", "consultant", "liaison")
  brokerage$primary_role <- apply(brokerage[, role_cols], 1, function(x) {
    if (all(x == 0)) return("none")
    role_cols[which.max(x)]
  })
  
  # Add interpretation
  brokerage$role_interpretation <- dplyr::case_when(
    brokerage$primary_role == "coordinator" ~ "Within-group broker",
    brokerage$primary_role == "gatekeeper" ~ "Controls information entering group",
    brokerage$primary_role == "representative" ~ "Controls information leaving group",
    brokerage$primary_role == "consultant" ~ "Bridges multiple different groups",
    brokerage$primary_role == "liaison" ~ "Connects group from outside",
    brokerage$primary_role == "none" ~ "No brokerage activity",
    TRUE ~ "Unknown"
  )
  
  cat("\nBrokerage role summary:\n")
  print(table(brokerage$primary_role))
  
  cat("\nTop 5 brokers by total brokerage:\n")
  print(head(brokerage[order(-brokerage$total_brokerage), 
                       c("node", "group", "total_brokerage", "primary_role")], 5))
  
  return(brokerage)
}
