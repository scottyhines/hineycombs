#' Extract an ego “inner circle” subgraph (tight friendships)
#'
#' Builds a subgraph consisting of ego, ego's neighbors, and then keeps:
#' - the top-k strongest edges incident to ego (by weight), and
#' - (optionally) only neighbor-neighbor edges that meet an embeddedness threshold
#'   (helps isolate "real circles" vs. incidental contacts).
#'
#' @param g An igraph object.
#' @param ego Vertex name or integer vertex id.
#' @param k_keep Integer. Keep top-k ego-incident edges by weight.
#' @param weight_attr Character. Edge attribute name for weights. If missing, weight=1.
#' @param neighbor_mode Character. For directed graphs: neighborhood mode used to collect neighbors.
#' @param keep_neighbor_edges Logical. If TRUE, keep neighbor-neighbor edges too (default TRUE).
#' @param min_neighbor_embeddedness Optional integer. If provided, filters neighbor-neighbor edges to those
#'   with embeddedness >= threshold (computed within the ego subgraph).
#' @param simplify Logical. If TRUE, simplify the resulting subgraph.
#'
#' @return An igraph subgraph centered on ego.
#' @export
run_dense_ego_inner_circle <- function(
    g,
    ego,
    k_keep = 10,
    weight_attr = "weight",
    neighbor_mode = c("all", "out", "in"),
    keep_neighbor_edges = TRUE,
    min_neighbor_embeddedness = NULL,
    simplify = TRUE
) {
  stopifnot(igraph::is_igraph(g))
  neighbor_mode <- match.arg(neighbor_mode)
  
  # Ensure names for lookup
  if (is.null(igraph::V(g)$name)) igraph::V(g)$name <- as.character(seq_len(igraph::vcount(g)))
  
  ego_vid <- if (is.numeric(ego)) {
    as.integer(ego)
  } else {
    which(igraph::V(g)$name == ego)[1]
  }
  if (is.na(ego_vid)) stop("Ego not found in graph: ", ego)
  
  nbrs <- igraph::neighbors(g, ego_vid, mode = neighbor_mode)
  vids <- unique(c(ego_vid, as.integer(nbrs)))
  
  sub <- igraph::induced_subgraph(g, vids)
  
  # weights in the subgraph
  w <- igraph::edge_attr(sub, weight_attr)
  if (is.null(w)) w <- rep(1, igraph::ecount(sub))
  w <- as.numeric(w)
  w[is.na(w)] <- 0
  
  # ego within subgraph corresponds to same vertex name
  ego_name <- igraph::V(g)$name[ego_vid]
  ego_sub_vid <- which(igraph::V(sub)$name == ego_name)[1]
  if (is.na(ego_sub_vid)) ego_sub_vid <- 1
  
  e_ego <- igraph::incident(sub, ego_sub_vid, mode = "all")
  
  keep_eids <- integer(0)
  if (length(e_ego) > 0) {
    ord <- order(w[e_ego], decreasing = TRUE, na.last = TRUE)
    keep_eids <- c(keep_eids, e_ego[head(ord, min(k_keep, length(ord)))])
  }
  
  if (keep_neighbor_edges && igraph::ecount(sub) > 0) {
    if (!is.null(min_neighbor_embeddedness)) {
      # Compute embeddedness within this ego-subgraph and keep edges meeting threshold
      scored <- edge_embeddedness_and_score(sub, weight_attr = weight_attr, neighbor_mode = "all", return_graph = FALSE)
      # scored is ordered; we need embeddedness by edge endpoints
      # Create a key to map scored edges back to sub edges (safe for simple graphs)
      key_scored <- paste(pmin(scored$from, scored$to), pmax(scored$from, scored$to), sep = "||")
      
      eds_sub <- igraph::as_edgelist(sub, names = TRUE)
      key_sub <- paste(pmin(eds_sub[, 1], eds_sub[, 2]), pmax(eds_sub[, 1], eds_sub[, 2]), sep = "||")
      
      emb_map <- setNames(scored$embeddedness, key_scored)
      emb_sub <- emb_map[key_sub]
      emb_sub[is.na(emb_sub)] <- 0L
      
      keep_eids <- unique(c(keep_eids, which(emb_sub >= min_neighbor_embeddedness)))
    } else {
      # keep all edges among ego+neighbors in addition to top-k ego edges
      keep_eids <- unique(c(keep_eids, seq_len(igraph::ecount(sub))))
    }
  }
  
  out <- igraph::subgraph.edges(sub, eids = keep_eids, delete.vertices = FALSE)
  if (simplify) out <- igraph::simplify(out, remove.multiple = TRUE, remove.loops = TRUE)
  out
}