#' Calculate and Standardize Network Centrality Metrics
#'
#' @description
#' Calculates various network centrality metrics for vertices and edges, including both
#' basic and advanced measures. For each metric, both raw and standardized versions are computed.
#'
#' Network archetypes (attributes prefixed with `network_`) are computed primarily from
#' standardized (z-scored) basic metrics. Archetypes that depend on advanced metrics
#' (e.g., `bridging_s`) are only computed when `include_advanced_metrics = TRUE`.
#'
#' @param g An igraph object. The network to analyze.
#' @param include_advanced_metrics Logical. Whether to calculate computationally intensive
#'        advanced metrics. Default is FALSE.
#'
#' @return An igraph object with added vertex and edge attributes.
#'
#' @importFrom igraph V E degree betweenness closeness harmonic_centrality coreness strength page_rank eigen_centrality constraint transitivity as_undirected edge_attr_names diversity ego_size vertex_attr vcount distances as_adjacency_matrix eccentricity subgraph_centrality edge_betweenness
#' @importFrom influenceR ens bridging
#' @importFrom centiserve leverage communibet crossclique markovcent
#' @importFrom stats sd
#'
#' @export
calculate_centrality_metrics <- function(g, include_advanced_metrics = FALSE) {
  cat("Starting basic network metrics calculation...\n")
  
  # -----------------------------
  # Helper: standardize (z-score)
  # -----------------------------
  standardize <- function(x) {
    if (all(is.na(x)) || length(unique(x[!is.na(x)])) <= 1) return(x)
    (x - mean(x, na.rm = TRUE)) / stats::sd(x, na.rm = TRUE)
  }
  
  # Helper: safe comparisons when values may be NA
  z_ge <- function(x, cut) !is.na(x) & x >= cut
  z_le <- function(x, cut) !is.na(x) & x <= cut
  z_bw <- function(x, lo, hi) !is.na(x) & x >= lo & x <= hi
  
  # -----------------------------
  # Basic metrics (vertex)
  # -----------------------------
  V(g)$degree <- igraph::degree(g, mode = "total")
  V(g)$degree_s <- standardize(V(g)$degree)
  
  V(g)$indegree <- igraph::degree(g, mode = "in")
  V(g)$indegree_s <- standardize(V(g)$indegree)
  
  V(g)$outdegree <- igraph::degree(g, mode = "out")
  V(g)$outdegree_s <- standardize(V(g)$outdegree)
  
  cat("Degree metrics completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$betweenness <- igraph::betweenness(g)
  V(g)$betweenness_s <- standardize(V(g)$betweenness)
  cat("Node Betweenness completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  # -----------------------------
  # NEW: Closeness / Harmonic / Coreness (basic)
  # -----------------------------
  V(g)$closeness <- igraph::closeness(g, mode = "all", normalized = TRUE)
  V(g)$closeness_s <- standardize(V(g)$closeness)
  cat("Closeness completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  # Harmonic closeness (better for disconnected graphs)
  if ("harmonic_centrality" %in% getNamespaceExports("igraph")) {
    V(g)$harmonic_closeness <- igraph::harmonic_centrality(g, mode = "all", normalized = TRUE)
  } else {
    d <- igraph::distances(g, mode = "all")
    diag(d) <- Inf
    invd <- 1 / d
    invd[!is.finite(invd)] <- 0
    V(g)$harmonic_closeness <- rowSums(invd, na.rm = TRUE)
    if (igraph::vcount(g) > 1) {
      V(g)$harmonic_closeness <- V(g)$harmonic_closeness / (igraph::vcount(g) - 1)
    }
  }
  V(g)$harmonic_closeness_s <- standardize(V(g)$harmonic_closeness)
  cat("Harmonic closeness completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  # K-core / coreness
  V(g)$coreness <- igraph::coreness(g, mode = "all")
  V(g)$coreness_s <- standardize(V(g)$coreness)
  cat("Coreness (k-core) completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  # NOTE: Kept as-is from your original. Consider igraph::strength(g, weights=E(g)$weight) if desired.
  V(g)$strength <- igraph::strength(g, weights=E(g)$weight)
  V(g)$strength_s <- standardize(V(g)$strength)
  cat("Strength completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$pagerank <- as.numeric(igraph::page_rank(g)$vector)
  V(g)$pagerank_s <- standardize(V(g)$pagerank)
  cat("PageRank completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$leverage <- centiserve::leverage(g)
  V(g)$leverage_s <- standardize(V(g)$leverage)
  cat("Leverage completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$evcent <- igraph::eigen_centrality(g)$vector
  V(g)$evcent_s <- standardize(V(g)$evcent)
  cat("Eigenvector centrality completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$effsize <- influenceR::ens(g)
  V(g)$effsize_s <- standardize(V(g)$effsize)
  cat("Effective size completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$constraint <- igraph::constraint(g)
  V(g)$constraint_s <- standardize(V(g)$constraint)
  cat("Constraint completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$transitivity <- igraph::transitivity(g, type = "local")
  V(g)$transitivity_s <- standardize(V(g)$transitivity)
  cat("Local transitivity completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  # g_undirected <- igraph::as.undirected(g, mode="collapse")
  # V(g)$diversity <- igraph::diversity(g_undirected)
  # V(g)$diversity_s <- standardize(V(g)$diversity)
  # cat("Diversity completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  # Convert to undirected graph
  g_undirected <- igraph::as_undirected(g, mode="collapse")
  # Check if edge weights exist
  if ("weight" %in% igraph::edge_attr_names(g_undirected) && !all(is.na(E(g_undirected)$weight))) {
    # Use existing weights
    V(g)$diversity <- igraph::diversity(g_undirected, weights = E(g_undirected)$weight)} else {
    # No weights exist or all are NA - assign unit weights
    V(g)$diversity <- igraph::diversity(g_undirected, weights = rep(1, ecount(g_undirected)))}
  V(g)$diversity_s <- standardize(V(g)$diversity)
  cat("Diversity completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  # -----------------------------
  # Reach (vertex)
  # -----------------------------
  V(g)$reach_1 <- igraph::ego_size(g, order = 1)
  V(g)$reach_1_s <- standardize(V(g)$reach_1)
  cat("Reach 1 completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$reach_2 <- igraph::ego_size(g, order = 2)
  V(g)$reach_2_s <- standardize(V(g)$reach_2)
  cat("Reach 2 completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$reach_3 <- igraph::ego_size(g, order = 3)
  V(g)$reach_3_s <- standardize(V(g)$reach_3)
  cat("Reach 3 completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  # -----------------------------
  # Demand / engagement (vertex)
  # -----------------------------
  # Demand and engagement calculations with standardization
  V(g)$indemand <- igraph::strength(g, mode = "in")
  V(g)$indemand_s <- standardize(V(g)$indemand)
  cat("Indemand completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$chatty <- igraph::strength(g, mode = "out")
  V(g)$chatty_s <- standardize(V(g)$chatty)
  cat("Chatty completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$engagements <- V(g)$indemand + V(g)$chatty
  V(g)$engagements_s <- standardize(V(g)$engagements)
  cat("Engagements completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  # =============================================================
  # NETWORK HEALTH METRIC (Hierarchical with Subscales)
  # =============================================================
  
  # Subscale 1: Connectivity Quality (40% of Network Health)
  V(g)$connectivity_quality <- (
    0.50 * V(g)$harmonic_closeness_s +
      0.30 * V(g)$evcent_s +
      0.20 * V(g)$reach_2_s
  )
  V(g)$connectivity_quality_s <- standardize(V(g)$connectivity_quality)
  
  # Subscale 2: Structural Efficiency (35% of Network Health)
  V(g)$structural_efficiency <- (
    0.55 * V(g)$effsize_s +
      0.45 * (-1 * V(g)$constraint_s)
  )
  V(g)$structural_efficiency_s <- standardize(V(g)$structural_efficiency)
  
  # Subscale 3: Network Embeddedness (25% of Network Health)
  V(g)$network_embeddedness <- (
    0.60 * V(g)$transitivity_s +
      0.40 * V(g)$coreness_s
  )
  V(g)$network_embeddedness_s <- standardize(V(g)$network_embeddedness)
  
  # Overall Network Health (weights sum to 1.0)
  V(g)$network_health <- (
    0.40 * V(g)$connectivity_quality +
      0.35 * V(g)$structural_efficiency +
      0.25 * V(g)$network_embeddedness
  )
  V(g)$network_health_s <- standardize(V(g)$network_health)
  
  cat("Network Health metric and subscales completed at:",
      format(Sys.time(), "%H:%M:%S"), "
")
  
  # =============================================================
  # INNOVATION POTENTIAL METRIC (Hierarchical with Subscales)
  # =============================================================
  
  # Subscale 1: Brokerage Capacity (45% of Innovation Potential)
  V(g)$brokerage_capacity <- (
    0.60 * V(g)$betweenness_s +
      0.40 * V(g)$effsize_s
  )
  V(g)$brokerage_capacity_s <- standardize(V(g)$brokerage_capacity)
  
  # Subscale 2: Structural Autonomy (30% of Innovation Potential)
  V(g)$structural_autonomy <- (
    0.70 * (-1 * V(g)$constraint_s) +
      0.30 * V(g)$leverage_s
  )
  V(g)$structural_autonomy_s <- standardize(V(g)$structural_autonomy)
  
  # Subscale 3: Information Access (25% of Innovation Potential)
  V(g)$information_access <- (
    0.60 * V(g)$reach_2_s +
      0.40 * V(g)$reach_3_s
  )
  V(g)$information_access_s <- standardize(V(g)$information_access)
  
  # Overall Innovation Potential (weights sum to 1.0)
  V(g)$innovation_potential <- (
    0.45 * V(g)$brokerage_capacity +
      0.30 * V(g)$structural_autonomy +
      0.25 * V(g)$information_access
  )
  V(g)$innovation_potential_s <- standardize(V(g)$innovation_potential)
  
  cat("Innovation Potential metric and subscales completed at:",
      format(Sys.time(), "%H:%M:%S"), "
")
  
  # ============================================================
  # NETWORK ARCHETYPES (BASIC) — computed from basic z-scores
  # ============================================================
  cat("Starting network archetypes classification (basic)...\n")
  
  # Aliases (standardized)
  indeg  <- V(g)$indegree_s
  outdeg <- V(g)$outdegree_s
  btw    <- V(g)$betweenness_s
  pr     <- V(g)$pagerank_s
  ev     <- V(g)$evcent_s
  cons   <- V(g)$constraint_s
  eff    <- V(g)$effsize_s
  tr     <- V(g)$transitivity_s
  deg    <- V(g)$degree_s
  eng    <- V(g)$engagements_s
  r2     <- V(g)$reach_2_s
  r3     <- V(g)$reach_3_s
  
  # Your originals (that only need basic metrics)
  V(g)$network_connector   <- as.integer(z_ge(indeg, 1))
  V(g)$network_gatekeeper  <- as.integer(z_ge(btw, 1) & z_bw(outdeg, -1, 1))
  V(g)$network_specialist  <- as.integer(z_le(btw, 0) & z_le(outdeg, 0) & z_ge(cons, 1))
  V(g)$network_influencer  <- as.integer(z_ge(outdeg, 1) & z_ge(pr, 1))
  V(g)$network_lurker      <- as.integer(z_le(btw, 0) & z_le(pr, 0) & z_le(outdeg, 0))
  V(g)$network_bridges     <- as.integer(z_ge(btw, 0) & z_le(pr, 0))
  
  # Additional basic-sufficient archetypes
  V(g)$network_hub                    <- as.integer(z_ge(deg, 1) & z_ge(eng, 0))
  V(g)$network_broadcaster            <- as.integer(z_ge(outdeg, 1) & z_le(indeg, 0))
  V(g)$network_magnet                 <- as.integer(z_ge(indeg, 1) & z_le(outdeg, 0))
  V(g)$network_reciprocator           <- as.integer(z_ge(indeg, 1) & z_ge(outdeg, 1))
  V(g)$network_structural_hole_broker <- as.integer(z_ge(btw, 1) & z_le(cons, -1))
  V(g)$network_opportunity_broker     <- as.integer(z_ge(eff, 1) & z_le(cons, -1))
  V(g)$network_clique_insider         <- as.integer(z_ge(tr, 1))  # refined later if bridging exists
  V(g)$network_core_insider           <- as.integer(z_ge(ev, 1) & z_ge(pr, 1))
  V(g)$network_peripheral             <- as.integer(z_le(deg, -1) & z_le(eng, -1))
  V(g)$network_reach_amplifier        <- as.integer(z_ge(r2, 1) | z_ge(r3, 1))
  
  # -----------------------------
  # Advanced metrics
  # -----------------------------
  if (include_advanced_metrics) {
    cat("\nStarting advanced metrics calculation...\n")
    
    V(g)$stress_centrality <- sna::stresscent(as.matrix(igraph::as_adjacency_matrix(g)))
    V(g)$stress_centrality_s <- standardize(V(g)$stress_centrality)
    cat("Stress centrality completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    V(g)$eccentricity <- igraph::eccentricity(g)
    V(g)$eccentricity_s <- standardize(V(g)$eccentricity)
    cat("Eccentricity completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    V(g)$subgraph_centrality <- igraph::subgraph_centrality(g)
    V(g)$subgraph_centrality_s <- standardize(V(g)$subgraph_centrality)
    cat("Subgraph centrality completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    E(g)$edge_betweenness <- igraph::edge_betweenness(g)
    E(g)$edge_betweenness_s <- standardize(E(g)$edge_betweenness)
    cat("Edge betweenness completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    V(g)$load_centrality <- sna::loadcent(as.matrix(igraph::as_adjacency_matrix(g)))
    V(g)$load_centrality_s <- standardize(V(g)$load_centrality)
    cat("Load centrality completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    V(g)$information_centrality <- sna::infocent(as.matrix(igraph::as_adjacency_matrix(g)))
    V(g)$information_centrality_s <- standardize(V(g)$information_centrality)
    cat("Information centrality completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    V(g)$bridging <- influenceR::bridging(g)
    V(g)$bridging_s <- standardize(V(g)$bridging)
    cat("Bridging completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    V(g)$communibet <- centiserve::communibet(g)
    V(g)$communibet_s <- standardize(V(g)$communibet)
    cat("Communibet completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    V(g)$crossclique <- centiserve::crossclique(g)
    V(g)$crossclique_s <- standardize(V(g)$crossclique)
    cat("Crossclique completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    V(g)$markovcent <- centiserve::markovcent(g)
    V(g)$markovcent_s <- standardize(V(g)$markovcent)
    cat("Markov centrality completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    # ============================================================
    # NETWORK ARCHETYPES (ADV-DEPENDENT) — now bridging_s exists
    # ============================================================
    br <- V(g)$bridging_s
    
    V(g)$network_boundary_spanner <- as.integer(z_ge(br, 1) & z_ge(btw, 0))
    
    # refine clique-insider if bridging is available
    V(g)$network_clique_insider <- as.integer(z_ge(tr, 1) & z_le(br, 0))
  } else {
    V(g)$network_boundary_spanner <- 0L
  }
  
  # ============================================================
  # Final archetype rollups (always run, after all possible flags)
  # ============================================================
  # Fix negative values in individual archetype columns
  archetype_cols <- grep("^network_", names(igraph::vertex_attr(g)), value = TRUE)
  
  for (col in archetype_cols) {
    values <- vertex_attr(g, col)
    values[is.na(values)] <- 0  # Replace NAs with 0
    vertex_attr(g, col) <- pmax(0, values)  # Floor at 0
  }
  
  # Now calculate the total (all values are non-negative)
  V(g)$network_archetype_count <- as.integer(
    rowSums(sapply(archetype_cols, function(nm) igraph::vertex_attr(g, nm)), na.rm = TRUE)
  )
  
  priority <- c(
    "network_structural_hole_broker",
    "network_boundary_spanner",
    "network_gatekeeper",
    "network_influencer",
    "network_core_insider",
    "network_hub",
    "network_reciprocator",
    "network_connector",
    "network_magnet",
    "network_broadcaster",
    "network_specialist",
    "network_clique_insider",
    "network_reach_amplifier",
    "network_bridges",
    "network_lurker",
    "network_peripheral"
  )
  
  V(g)$network_archetype_primary <- NA_character_
  for (nm in priority) {
    hit <- igraph::vertex_attr(g, nm)
    empty <- is.na(V(g)$network_archetype_primary)
    V(g)$network_archetype_primary[empty & hit == 1] <- nm
  }
  
  cat("Network archetypes completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  cat("\nAll calculations completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  return(g)
}