#' Find Best Friends in a Network
#'
#' Identifies the strongest (highest-weight) connection for each node in an \code{igraph} graph.
#'
#' @param graph An \code{igraph} object representing a network.
#' @return The input \code{igraph} object with two new vertex attributes:
#'   \item{best_friend}{The name of the strongest connection for each node.}
#'   \item{friend_weight}{The weight of the strongest connection.}
#' @details
#' This function extracts the edge list from the given graph, finds the highest-weight connection 
#' for each node, and assigns it as a vertex attribute.
#'
#' - If the graph is undirected, the function ensures edges are treated bidirectionally.
#' - If multiple edges have the same highest weight, only one is selected.
#' - The function uses \pkg{igraph} for network operations and \pkg{dplyr} for data manipulation.
#'
#' @examples
#' \dontrun{
#' library(igraph)
#' g <- make_graph(~ A - B, B - C, C - A, A - D, B - D, D - E, E - F)
#' E(g)$weight <- c(1, 3, 2, 5, 4, 2, 1) # Assign weights
#' g <- find_best_friends(g)
#' print(V(g)$best_friend)
#' }
#'
#' @import igraph
#' @importFrom dplyr rename bind_rows group_by slice_max ungroup
#' @export
run_find_best_friend <- function(graph) {
  # Ensure the graph has a weight attribute
  if (!"weight" %in% igraph::edge_attr_names(graph)) {
    stop("Graph does not have a 'weight' attribute.")
  }
  
  # Extract edge list including weights
  edges_df <- igraph::as_data_frame(graph, what = "edges") %>%
    dplyr::rename(name = from, best_friend = to)
  
  # Create bidirectional edge representation for undirected graphs
  if (!igraph::is_directed(graph)) {
    edges_reversed <- edges_df %>%
      dplyr::rename(name = best_friend, best_friend = name)
    
    # Combine both directions into a single dataframe
    edges_df <- dplyr::bind_rows(edges_df, edges_reversed)
  }
  
  # Find the best friend for each node (highest weight connection)
  best_friends_df <- edges_df %>%
    dplyr::group_by(name) %>%
    dplyr::slice_max(order_by = weight, n = 1, with_ties = FALSE) %>%
    dplyr::ungroup()
  
  # Assign best friends and weights as vertex attributes
  igraph::V(graph)$best_friend <- best_friends_df$best_friend[match(igraph::V(graph)$name, best_friends_df$name)]
  igraph::V(graph)$friend_weight <- best_friends_df$weight[match(igraph::V(graph)$name, best_friends_df$name)]
  
  return(graph)
}
