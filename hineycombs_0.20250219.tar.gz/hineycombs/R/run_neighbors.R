#' Analyze Neighbors Connections in a Network
#'
#' This function analyzes the incoming and outgoing connections for a specified group of nodes 
#' in an \code{igraph} network object. It summarizes the connections based on a specified node 
#' attribute.
#'
#' @param graph An \code{igraph} object representing the network.
#' @param attribute_name A character string specifying the node attribute to filter the group (e.g., "department").
#' @param group_value The value of the \code{attribute_name} that defines the target group of nodes.
#' @param attribute_to_analyze A character string specifying the node attribute to summarize connections (e.g., "role").
#' 
#' @return A data frame summarizing the number and weight of incoming and outgoing connections 
#' by attribute, including their proportions.
#' 
#' @details
#' The function performs the following steps:
#' \itemize{
#'   \item Extracts nodes belonging to the specified group.
#'   \item Identifies edges where the group nodes are either sources (outgoing) or targets (incoming).
#'   \item Retrieves attribute values for connected nodes.
#'   \item Aggregates connection counts and weights, computing proportions.
#' }
#' 
#' If no nodes are found for the specified group, an error is thrown. If no adjacent nodes exist, 
#' a warning is displayed, and \code{NULL} is returned.
#' 
#' @examples
#' \dontrun{
#' library(igraph)
#' g <- make_graph(~ A -+ B, B -+ C, C -+ D, D -+ A)
#' V(g)$department <- c("HR", "HR", "IT", "Finance")
#' V(g)$role <- c("Manager", "Analyst", "Developer", "CFO")
#' E(g)$weight <- c(1, 2, 3, 4)
#'
#' run_neighbors(g, "department", "HR", "role")
#' }
#'
#' @importFrom igraph as_data_frame
#' @importFrom dplyr filter pull select group_by summarise mutate full_join across inner_join
#' @importFrom tidyr replace_na
#' @importFrom janitor clean_names
#' @export
run_neighbors <- function(graph, attribute_name, group_value, attribute_to_analyze) {
  # Step 1: Extract nodes belonging to the specified group
  vertex_df <- igraph::as_data_frame(graph, what = "vertices")
  
  # Filter the dataframe based on the attribute_name and group_value
  group_nodes <- vertex_df %>%
    dplyr::filter(.data[[attribute_name]] == group_value) %>%
    dplyr::pull(name)  # Extract only the node names
  
  if (length(group_nodes) == 0) {
    stop(paste("No nodes found for", attribute_name, "=", group_value))
  }
  
  # Step 2: Extract edges where these nodes are the target (incoming) or source (outgoing)
  edge_df <- igraph::as_data_frame(graph, what = "edges")
  
  incoming_edges <- edge_df %>%
    dplyr::filter(to %in% group_nodes) %>%
    dplyr::select(from, to, weight)
  
  outgoing_edges <- edge_df %>%
    dplyr::filter(from %in% group_nodes) %>%
    dplyr::select(from, to, weight)
  
  incoming_nodes <- unique(incoming_edges$from)
  outgoing_nodes <- unique(outgoing_edges$to)
  
  # Remove nodes that are part of the original group
  incoming_nodes <- setdiff(incoming_nodes, group_nodes)
  outgoing_nodes <- setdiff(outgoing_nodes, group_nodes)
  
  if (length(incoming_nodes) == 0 && length(outgoing_nodes) == 0) {
    warning("No adjacent nodes found.")
    return(NULL)
  }
  
  # Step 3: Extract attribute values for incoming and outgoing nodes
  incoming_attr_df <- vertex_df %>%
    dplyr::filter(name %in% incoming_nodes) %>%
    dplyr::select(name, .data[[attribute_to_analyze]]) %>%
    dplyr::rename(Node = name, Attribute = .data[[attribute_to_analyze]])
  
  outgoing_attr_df <- vertex_df %>%
    dplyr::filter(name %in% outgoing_nodes) %>%
    dplyr::select(name, .data[[attribute_to_analyze]]) %>%
    dplyr::rename(Node = name, Attribute = .data[[attribute_to_analyze]])
  
  # Compute summaries
  incoming_df <- incoming_edges %>%
    dplyr::inner_join(incoming_attr_df, by = c("from" = "Node")) %>%
    dplyr::group_by(Attribute) %>%
    dplyr::summarise(incoming_n = dplyr::n(),
                     incoming_weight = sum(weight, na.rm = TRUE)) %>%
    dplyr::mutate(incoming_n_percent = round(incoming_n / sum(incoming_n, na.rm = TRUE), 4),
                  incoming_weight_percent = round(incoming_weight / sum(incoming_weight, na.rm = TRUE), 4))
  
  outgoing_df <- outgoing_edges %>%
    dplyr::inner_join(outgoing_attr_df, by = c("to" = "Node")) %>%
    dplyr::group_by(Attribute) %>%
    dplyr::summarise(outgoing_n = dplyr::n(),
                     outgoing_weight = sum(weight, na.rm = TRUE)) %>%
    dplyr::mutate(outgoing_n_percent = round(outgoing_n / sum(outgoing_n, na.rm = TRUE), 4),
                  outgoing_weight_percent = round(outgoing_weight / sum(outgoing_weight, na.rm = TRUE), 4))
  
  # Merge incoming and outgoing data
  all_df <- incoming_df %>%
    dplyr::full_join(outgoing_df, by = "Attribute") %>%  
    dplyr::mutate(
      all_n = rowSums(dplyr::across(c(incoming_n, outgoing_n)), na.rm = TRUE),  
      all_weight = rowSums(dplyr::across(c(incoming_weight, outgoing_weight)), na.rm = TRUE)) %>%  
    dplyr::mutate(all_n_percent = round(all_n / sum(all_n, na.rm = TRUE), 4),
                  all_weight_percent = round(all_weight / sum(all_weight, na.rm = TRUE), 4)) %>%
    dplyr::mutate(dplyr::across(dplyr::everything(), ~ tidyr::replace_na(.x, 0)))  
  
  return(all_df)
}
