#' Plot Network with Highlighted Group and Degree-Based Node Sizes
#'
#' This function visualizes a network graph, highlighting a specific group of nodes based on an attribute value,
#' and scales node sizes based on their degrees.
#'
#' @param graph An `igraph` object representing the network.
#' @param attribute_name A character string specifying the vertex attribute to filter on.
#' @param group_value The value of `attribute_name` that determines which nodes to highlight.
#' @param highlight_connections Logical, if `TRUE`, edges connected to highlighted nodes will also be emphasized.
#' @param transparency A numeric value between 0 and 1 specifying the transparency level of the nodes.
#' @param min_size Minimum vertex size (default = 3)
#' @param max_size Maximum vertex size (default = 10)
#'
#' @return A network visualization plot with highlighted nodes and edges, and degree-based node sizes.
#'
#' @examples
#' library(igraph)
#' g <- make_ring(10)
#' V(g)$group <- rep(c("A", "B"), length.out = 10)
#' plot_reach(g, "group", "A")
#'
#' @export
plot_reach <- function(graph, attribute_name, group_value, highlight_connections = TRUE, 
                       transparency = 0.3, min_size = 3, max_size = 10) {
  # Ensure transparency is within [0,1]
  transparency <- max(0, min(transparency, 1))
  
  # Convert transparency to HEX alpha value
  alpha_hex <- sprintf("%02X", round(transparency * 255))
  
  # Set node colors (default is clear, group nodes are red)
  igraph::V(graph)$color <- paste0("#FFFFFF", alpha_hex)  # Transparent white nodes
  igraph::V(graph)$frame.color <- "black"  
  igraph::V(graph)$frame.width <- 2  
  
  # Identify nodes belonging to the specified group
  target_nodes <- igraph::V(graph)[igraph::get.vertex.attribute(graph, attribute_name) == group_value]
  
  # Set target nodes to red (with same transparency level)
  igraph::V(graph)[target_nodes]$color <- paste0("#FF0000", alpha_hex)  # Red with transparency
  
  # Calculate degree and scale vertex sizes
  degrees <- igraph::degree(graph)
  if (length(unique(degrees)) == 1) {
    # If all degrees are the same, use min_size
    vertex_sizes <- rep(min_size, igraph::vcount(graph))
  } else {
    # Scale degrees to be between min_size and max_size
    vertex_sizes <- scales::rescale(degrees, 
                                    to = c(min_size, max_size),
                                    from = range(degrees))
  }
  
  # Default edge properties
  edge_width <- rep(1, igraph::ecount(graph))  # Default edge width
  igraph::E(graph)$color <- "gray80"           # Default all edges to gray
  
  # If highlight_connections is TRUE, highlight edges connected to target nodes
  if (highlight_connections) {
    edge_ids <- igraph::E(graph)[.inc(target_nodes)]
    
    # Highlight edges
    igraph::E(graph)[edge_ids]$color <- "red"
    edge_width[edge_ids] <- 2  # Increase width for highlighted edges
  }
  
  # Plot the graph with the specified layout and parameters
  plot(
    graph,
    layout = igraph::layout_with_mds,  # Use multidimensional scaling layout
    vertex.label = NA,  
    vertex.label.cex = 0.75,  
    vertex.label.color = "black",  
    vertex.size = vertex_sizes,  # Use scaled vertex sizes
    vertex.frame.color = igraph::V(graph)$frame.color,  
    vertex.frame.width = igraph::V(graph)$frame.width,  
    edge.width = edge_width,  
    edge.color = igraph::E(graph)$color,  
    edge.arrow.size = 0.01,  
    edge.arrow.width = 0.01,  
    edge.curved = 0.5,  
    main = paste("Network Visualization: Highlighting Group", group_value) # Add title
  )
  
  # Add a legend
  legend("topright", legend = c(paste("Group:", group_value), 
                                paste("Node size: Degree (", min(degrees), "-", max(degrees), ")")), 
         col = c(paste0("#FF0000", alpha_hex), "black"), 
         pch = c(16, 1), 
         bty = "n", 
         cex = 0.8)
}
