#' Create a Random Network with Node Attributes
#'
#' @description
#' Creates a random network using the Erdős-Rényi model and adds various node attributes 
#' including names, group membership, gender, region, performance scores, job levels, and team assignments.
#' Also adds random weights to edges.
#'
#' @param n Integer. Number of nodes in the network. Default is 500.
#' @param p Numeric. Probability of edge creation between any two nodes. Must be between 0 and 1. Default is 0.1.
#' @param directed Logical. Whether the network should be directed. Default is FALSE.
#' @param seed Integer. Seed for random number generation. Default is 123. Set to NULL for non-reproducible results.
#'
#' @return An igraph object with the following vertex attributes:
#' \itemize{
#'   \item name: Character. Node identifier in format "Node001", "Node002", etc.
#'   \item group: Character. One of A, B, C, or D with probabilities 0.4, 0.3, 0.2, 0.1 respectively.
#'   \item gender: Character. Either "M" or "F" with probabilities 0.52 and 0.48 respectively.
#'   \item region: Character. One of "North", "South", "East", "West", or "Central".
#'   \item performance: Integer. Score from 1 to 5 with probabilities 0.1, 0.2, 0.4, 0.2, 0.1 respectively.
#'   \item job_level: Character. One of "Entry", "Junior", "Senior", "Lead", "Manager", or "Director".
#'   \item team: Character. One of "Alpha", "Beta", "Gamma", "Delta", "Epsilon", or "Omega".
#' }
#' And edge attribute:
#' \itemize{
#'   \item weight: Integer. Random value between 1 and 10.
#' }
#'
#' @examples
#' # Create a network with default parameters
#' g <- create_network()
#'
#' # Create a smaller directed network with higher edge probability
#' g_small <- create_network(n = 100, p = 0.2, directed = TRUE)
#'
#' # Create a network with custom seed
#' g_custom <- create_network(seed = 456)
#'
#' @importFrom igraph sample_gnp V E vcount ecount
#' @export
create_network <- function(n = 500, p = 0.1, directed = FALSE, seed = 123) {
  # Input validation
  if (!is.numeric(n) || n <= 0) stop("n must be a positive number")
  if (!is.numeric(p) || p <= 0 || p >= 1) stop("p must be between 0 and 1")
  if (!is.logical(directed)) stop("directed must be TRUE or FALSE")
  
  # Set seed for reproducibility
  if (!is.null(seed)) set.seed(seed)
  
  # Create random network
  g <- igraph::sample_gnp(n, p = p, directed = directed)
  
  # Add node names
  igraph::V(g)$name <- paste0("Node", sprintf("%03d", 1:n))
  
  # Create unequal group sizes with specific probabilities
  group_probs <- c(0.4, 0.3, 0.2, 0.1)  # A=40%, B=30%, C=20%, D=10%
  igraph::V(g)$group <- sample(LETTERS[1:4], igraph::vcount(g), replace = TRUE, prob = group_probs)
  
  # Add gender
  igraph::V(g)$gender <- sample(c("M", "F"), igraph::vcount(g), replace = TRUE, 
                                prob = c(0.52, 0.48))
  
  # Add region
  regions <- c("North", "South", "East", "West", "Central")
  igraph::V(g)$region <- sample(regions, igraph::vcount(g), replace = TRUE)
  
  # Add performance scores
  igraph::V(g)$performance <- sample(1:5, igraph::vcount(g), replace = TRUE, 
                                     prob = c(0.1, 0.2, 0.4, 0.2, 0.1))
  
  # Add job levels
  job_levels <- c("Entry", "Junior", "Senior", "Lead", "Manager", "Director")
  level_probs <- c(0.2, 0.3, 0.25, 0.15, 0.07, 0.03)
  igraph::V(g)$job_level <- sample(job_levels, igraph::vcount(g), replace = TRUE, 
                                   prob = level_probs)
  
  # Add team names
  team_names <- c("Alpha", "Beta", "Gamma", "Delta", "Epsilon", "Omega")
  igraph::V(g)$team <- sample(team_names, igraph::vcount(g), replace = TRUE)
  
  # Add edge weights
  igraph::E(g)$weight <- sample(1:10, igraph::ecount(g), replace = TRUE)
  
  # Return network object
  return(g)
}
