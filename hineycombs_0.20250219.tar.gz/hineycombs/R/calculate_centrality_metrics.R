#' Calculate and Standardize Network Centrality Metrics
#'
#' @description
#' Calculates various network centrality metrics for vertices and edges, including both 
#' basic and advanced measures. For each metric, both raw and standardized versions are computed.
#'
#' @param g An igraph object. The network to analyze.
#' @param include_advanced_metrics Logical. Whether to calculate computationally intensive 
#'        advanced metrics. Default is FALSE.
#'
#' @return An igraph object with added vertex attributes:
#' \itemize{
#'   \item degree, degree_s: Total degree and standardized
#'   \item indegree, indegree_s: In-degree and standardized
#'   \item outdegree, outdegree_s: Out-degree and standardized
#'   \item strength, strength_s: Node strength and standardized
#'   \item pagerank, pagerank_s: PageRank and standardized
#'   \item leverage, leverage_s: Leverage centrality and standardized
#'   \item evcent, evcent_s: Eigenvector centrality and standardized
#'   \item effsize, effsize_s: Effective size and standardized
#'   \item constraint, constraint_s: Constraint and standardized
#'   \item transitivity, transitivity_s: Local transitivity and standardized
#'   \item stress_centrality, stress_centrality_s: Stress centrality and standardized
#'   \item reach_1, reach_1_s: 1-step reach and standardized
#'   \item reach_2, reach_2_s: 2-step reach and standardized
#'   \item reach_3, reach_3_s: 3-step reach and standardized
#'   \item indemand, indemand_s: Incoming weight sum and standardized
#'   \item chatty, chatty_s: Outgoing weight sum and standardized
#'   \item engagements, engagements_s: Total weight sum and standardized
#' }
#' 
#' If include_advanced_metrics = TRUE, additional attributes:
#' \itemize{
#'   \item eccentricity, eccentricity_s
#'   \item subgraph_centrality, subgraph_centrality_s
#'   \item load_centrality, load_centrality_s
#'   \item information_centrality, information_centrality_s
#'   \item bridging, bridging_s
#'   \item communibet, communibet_s
#'   \item crossclique, crossclique_s
#'   \item markovcent, markovcent_s
#' }
#' And edge attributes:
#' \itemize{
#'   \item betweenness, betweenness_s
#' }
#'
#' @examples
#' \dontrun{
#' # Create a random network
#' g <- igraph::sample_gnp(100, 0.1)
#' 
#' # Calculate basic metrics
#' g_metrics <- calculate_centrality_metrics(g)
#' 
#' # Calculate including advanced metrics
#' g_all_metrics <- calculate_centrality_metrics(g, include_advanced_metrics = TRUE)
#' }
#'
#' @importFrom igraph V E vcount degree page_rank eigen_centrality constraint transitivity
#' @importFrom igraph ego_size incident eccentricity subgraph_centrality edge_betweenness
#' @importFrom sna gilschmidt stresscent loadcent infocent
#' @importFrom influenceR ens bridging
#' @importFrom centiserve leverage communibet crossclique markovcent
#' @importFrom expm %^%
#'
#' @export
calculate_centrality_metrics <- function(g, include_advanced_metrics = FALSE) {
  library(expm)
  cat("Starting basic network metrics calculation...\n")
  
  # Function to standardize values
  standardize <- function(x) {
    if(all(is.na(x)) || length(unique(x)) == 1) return(x)
    (x - mean(x, na.rm = TRUE)) / sd(x, na.rm = TRUE)
  }
  
  # Basic metrics with standardization
  V(g)$degree <- igraph::degree(g, mode = "total")
  V(g)$degree_s <- standardize(V(g)$degree)
  V(g)$indegree <- igraph::degree(g, mode = "in")
  V(g)$indegree_s <- standardize(V(g)$indegree)
  V(g)$outdegree <- igraph::degree(g, mode = "out")
  V(g)$outdegree_s <- standardize(V(g)$outdegree)
  cat("Degree metrics completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$strength <- sna::gilschmidt(as.matrix(as_adjacency_matrix(g)))
  V(g)$strength_s <- standardize(V(g)$strength)
  cat("Strength completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$pagerank <- as.numeric(page_rank(g)$vector)
  V(g)$pagerank_s <- standardize(V(g)$pagerank)
  cat("PageRank completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$leverage <- centiserve::leverage(g)
  V(g)$leverage_s <- standardize(V(g)$leverage)
  cat("Leverage completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$evcent <- igraph::eigen_centrality(g)$vector
  V(g)$evcent_s <- standardize(V(g)$evcent)
  cat("Eigenvector centrality completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$effsize <- influenceR::ens(g)
  V(g)$effsize_s <- standardize(V(g)$effsize)
  cat("Effective size completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$constraint <- igraph::constraint(g)
  V(g)$constraint_s <- standardize(V(g)$constraint)
  cat("Constraint completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$transitivity <- igraph::transitivity(g, type = "local")
  V(g)$transitivity_s <- standardize(V(g)$transitivity)
  cat("Local transitivity completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$stress_centrality <- sna::stresscent(as.matrix(as_adjacency_matrix(g)))
  V(g)$stress_centrality_s <- standardize(V(g)$stress_centrality)
  cat("Stress centrality completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  # Reach calculations with standardization
  V(g)$reach_1 <- igraph::ego_size(g, order = 1)
  V(g)$reach_1_s <- standardize(V(g)$reach_1)
  cat("Reach 1 completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$reach_2 <- igraph::ego_size(g, order = 2)
  V(g)$reach_2_s <- standardize(V(g)$reach_2)
  cat("Reach 2 completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$reach_3 <- igraph::ego_size(g, order = 3)
  V(g)$reach_3_s <- standardize(V(g)$reach_3)
  cat("Reach 3 completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  # Demand and engagement calculations with standardization
  V(g)$indemand <- sapply(1:igraph::vcount(g), function(v) {
    sum(E(g)[igraph::incident(g, v, mode = "in")]$weight)
  })
  V(g)$indemand_s <- standardize(V(g)$indemand)
  cat("Indemand completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$chatty <- sapply(1:igraph::vcount(g), function(v) {
    sum(E(g)[igraph::incident(g, v, mode = "out")]$weight)
  })
  V(g)$chatty_s <- standardize(V(g)$chatty)
  cat("Chatty completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  V(g)$engagements <- V(g)$indemand + V(g)$chatty
  V(g)$engagements_s <- standardize(V(g)$engagements)
  cat("Engagements completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  
  if(include_advanced_metrics) {
    cat("\nStarting advanced metrics calculation...\n")
    
    V(g)$eccentricity <- igraph::eccentricity(g)
    V(g)$eccentricity_s <- standardize(V(g)$eccentricity)
    cat("Eccentricity completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    V(g)$subgraph_centrality <- igraph::subgraph_centrality(g)
    V(g)$subgraph_centrality_s <- standardize(V(g)$subgraph_centrality)
    cat("Subgraph centrality completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    E(g)$betweenness <- igraph::edge_betweenness(g)
    E(g)$betweenness_s <- standardize(E(g)$betweenness)
    cat("Edge betweenness completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    V(g)$load_centrality <- sna::loadcent(as.matrix(as_adjacency_matrix(g)))
    V(g)$load_centrality_s <- standardize(V(g)$load_centrality)
    cat("Load centrality completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    V(g)$information_centrality <- sna::infocent(as.matrix(as_adjacency_matrix(g)))
    V(g)$information_centrality_s <- standardize(V(g)$information_centrality)
    cat("Information centrality completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    V(g)$bridging <- influenceR::bridging(g)
    V(g)$bridging_s <- standardize(V(g)$bridging)
    cat("Bridging completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    V(g)$communibet <- centiserve::communibet(g)
    V(g)$communibet_s <- standardize(V(g)$communibet)
    cat("Communibet completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    V(g)$crossclique <- centiserve::crossclique(g)
    V(g)$crossclique_s <- standardize(V(g)$crossclique)
    cat("Crossclique completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
    
    V(g)$markovcent <- centiserve::markovcent(g)
    V(g)$markovcent_s <- standardize(V(g)$markovcent)
    cat("Markov centrality completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  }
  
  cat("\nAll calculations completed at:", format(Sys.time(), "%H:%M:%S"), "\n")
  return(g)
}
