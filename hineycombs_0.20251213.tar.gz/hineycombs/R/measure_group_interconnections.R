#' Analyze Network Group Interactions
#'
#' @description
#' Performs comprehensive analysis of interactions between two specified groups in a network,
#' including metrics like cross-group edges, density, modularity, and transitivity.
#' Optionally includes permutation testing for statistical significance.
#'
#' @param g An igraph object representing the network
#' @param group_var Character. Name of the vertex attribute containing group memberships
#' @param selected_groups Character vector of length 2. Names of the two groups to analyze
#' @param n_permutations Integer. Number of permutations for statistical testing. Default is 1000
#'
#' @return A list containing three elements:
#'   \item{Metrics}{Data frame of network metrics with explanations and values}
#'   \item{Top_Bridging_Nodes}{Data frame of top 5 nodes with highest betweenness centrality}
#'   \item{Permutation_Results}{List of permutation test results (if n_permutations > 0)}
#'
#' @details
#' Calculates various network metrics including:
#' - Cross-group edge counts and weights
#' - Group densities and interaction patterns
#' - Community detection and overlap
#' - Centrality measures
#' - Transitivity within and between groups
#'
#' @examples
#' \dontrun{
#' # Create a sample network
#' g <- igraph::make_graph("Zachary")
#' igraph::V(g)$group <- sample(c("A", "B"), igraph::vcount(g), replace = TRUE)
#'
#' # Analyze interactions between groups A and B
#' results <- analyze_network_groups(g, "group", c("A", "B"))
#' }
#'
#' @importFrom igraph vertex.attributes V E vcount ecount vertex_attr edge_attr_names
#' @importFrom igraph as_edgelist modularity cluster_walktrap membership betweenness
#' @importFrom igraph degree transitivity induced_subgraph graph.density
#' @export
measure_group_interconnections <- function(g, group_var, selected_groups, n_permutations = 1000) {
  
  # Initial checks
  if (!group_var %in% igraph::vertex_attr_names(g)) {
    stop("The attribute does not exist in the graph.")
  }
  
  # Get group membership directly using vertex_attr
  group_membership <- as.character(igraph::vertex_attr(g, group_var))
  if (!all(selected_groups %in% unique(group_membership))) {
    stop("One or both selected groups do not exist in the graph.")
  }
  
  # Ensure all nodes have a name
  if (is.null(igraph::V(g)$name)) {
    igraph::V(g)$name <- as.character(seq_len(igraph::vcount(g)))
  }

  #Core network analysis
  group_numeric <- as.numeric(as.factor(group_membership))
  mod_score <- igraph::modularity(g, group_numeric)
  
  edges <- igraph::as_edgelist(g, names = FALSE)
  edge_weights <- if ("weight" %in% igraph::edge_attr_names(g)) igraph::E(g)$weight else rep(1, igraph::ecount(g))
  
  #Identify cross-group edges
  cross_edges <- which(
    (group_membership[edges[,1]] == selected_groups[1] & group_membership[edges[,2]] == selected_groups[2]) |
      (group_membership[edges[,1]] == selected_groups[2] & group_membership[edges[,2]] == selected_groups[1])
  )
  
  #Calculate basic metrics
  cross_group_edges <- length(cross_edges)
  cross_group_weight_sum <- sum(edge_weights[cross_edges])
  total_edges <- igraph::ecount(g)
  cross_group_ratio <- ifelse(total_edges > 0, cross_group_edges / total_edges, 0)
  
  #Group identification
  group1_nodes <- which(group_membership == selected_groups[1])
  group2_nodes <- which(group_membership == selected_groups[2])
  num_group1 <- length(group1_nodes)
  num_group2 <- length(group2_nodes)
  
  #Cross-group interactions
  group1_to_group2 <- unique(edges[cross_edges, 1][group_membership[edges[cross_edges, 1]] == selected_groups[1]])
  group2_to_group1 <- unique(edges[cross_edges, 2][group_membership[edges[cross_edges, 2]] == selected_groups[2]])
  
  num_group1_to_group2 <- length(unique(c(group1_to_group2, edges[cross_edges, 2][group_membership[edges[cross_edges, 2]] == selected_groups[1]])))
  num_group2_to_group1 <- length(unique(c(group2_to_group1, edges[cross_edges, 1][group_membership[edges[cross_edges, 1]] == selected_groups[2]])))
  
  #Communication volume
  outgoing_group1_to_group2 <- sum(edge_weights[cross_edges][group_membership[edges[cross_edges, 1]] == selected_groups[1]])
  outgoing_group2_to_group1 <- sum(edge_weights[cross_edges][group_membership[edges[cross_edges, 1]] == selected_groups[2]])
  
  #Community detection
  community_detection <- igraph::cluster_walktrap(g)
  community_membership <- igraph::membership(community_detection)
  community_table <- table(community_membership, group_membership)
  overlapping_communities <- which(rowSums(community_table[, selected_groups]) > 1)
  nodes_in_overlapping_communities <- which(community_membership %in% overlapping_communities)
  num_group1_in_overlap <- sum(group_membership[nodes_in_overlapping_communities] == selected_groups[1])
  num_group2_in_overlap <- sum(group_membership[nodes_in_overlapping_communities] == selected_groups[2])
  
  #E-I Index
  internal_edges <- sum(group_membership[edges[,1]] == group_membership[edges[,2]])
  external_edges <- total_edges - internal_edges
  ei_index <- ifelse(total_edges > 0, (external_edges - internal_edges) / total_edges, NA)
  
  #Density calculations
  adj_matrix <- igraph::as_adjacency_matrix(g, sparse = FALSE)
  density_group1 <- sum(adj_matrix[group1_nodes, group1_nodes]) / (length(group1_nodes) * (length(group1_nodes) - 1))
  density_group2 <- sum(adj_matrix[group2_nodes, group2_nodes]) / (length(group2_nodes) * (length(group2_nodes) - 1))
  density_between <- sum(adj_matrix[group1_nodes, group2_nodes]) / (length(group1_nodes) * length(group2_nodes))
  
  #Centrality metrics
  degree_centrality <- igraph::degree(g)
  group_centrality <- tapply(degree_centrality, group_membership, mean, default = NA)
  betweenness_scores <- igraph::betweenness(g)
  
  #Transitivity calculations
  transitivity_overall <- igraph::transitivity(g, type = "global")
  g1 <- igraph::induced_subgraph(g, group1_nodes)
  g2 <- igraph::induced_subgraph(g, group2_nodes)
  transitivity_group1 <- igraph::transitivity(g1, type = "global")
  transitivity_group2 <- igraph::transitivity(g2, type = "global")
  
  #Bridge identification
  bridge_df <- data.frame(Name = igraph::V(g)$name, Group = group_membership, Betweenness = betweenness_scores)
  bridge_df <- bridge_df[bridge_df$Group %in% selected_groups, ]
  top_bridges <- if(nrow(bridge_df) > 0) head(bridge_df[order(-bridge_df$Betweenness), ], 5) else data.frame()
  
  #Create results dataframe
  metrics_df <- data.frame(
    Metric = c(
      paste("Total Nodes in", selected_groups[1]),
      paste("Total Nodes in", selected_groups[2]),
      "Cross-Group Edges",
      "Cross-Group Edge Weight Sum",
      "Cross-Group Edge Ratio",
      paste("Nodes in", selected_groups[1], "that interacted with", selected_groups[2]),
      paste("Nodes in", selected_groups[2], "that interacted with", selected_groups[1]),
      paste("Outgoing Messages from", selected_groups[1], "to", selected_groups[2]),
      paste("Outgoing Messages from", selected_groups[2], "to", selected_groups[1]),
      paste("Nodes in", selected_groups[1], "in overlapping communities"),
      paste("Nodes in", selected_groups[2], "in overlapping communities"),
      paste("Density of", selected_groups[1]),
      paste("Density of", selected_groups[2]),
      paste("Density Between", selected_groups[1], "and", selected_groups[2]),
      "Modularity Score",
      "E-I Index",
      paste("Avg Degree Centrality of", selected_groups[1]),
      paste("Avg Degree Centrality of", selected_groups[2]),
      "Overall Transitivity",
      paste("Transitivity of", selected_groups[1]),
      paste("Transitivity of", selected_groups[2])
    ),
    Explanation = c(
      "Total number of nodes in the first group.",
      "Total number of nodes in the second group.",
      "Number of edges connecting selected groups.",
      "Total number of messages exchanged between groups.",
      "Proportion of all edges that are cross-group.",
      "Unique nodes in first group that connected to the second group.",
      "Unique nodes in second group that connected to the first group.",
      "Total messages sent from first group to second group.",
      "Total messages sent from second group to first group.",
      "Number of first group members in communities that include second group members.",
      "Number of second group members in communities that include first group members.",
      "Connection density within the first group.",
      "Connection density within the second group.",
      "The proportion of actual connections between two groups relative to possible connections.",
      "Measures community separation; higher = stronger, well-defined groups.",
      "External vs. internal connections; pos = more external, neg = internal.",
      "Average number of connections per node in the first group.",
      "Average number of connections per node in the second group.",
      "Proportion of connected triples that form triangles in entire network",
      "Proportion of connected triples that form triangles in first group",
      "Proportion of connected triples that form triangles in second group"
    ),
    Value = c(
      num_group1, num_group2,
      cross_group_edges, cross_group_weight_sum,
      cross_group_ratio, num_group1_to_group2,
      num_group2_to_group1, outgoing_group1_to_group2,
      outgoing_group2_to_group1, num_group1_in_overlap,
      num_group2_in_overlap, density_group1,
      density_group2, density_between,
      mod_score, ei_index,
      group_centrality[selected_groups[1]],
      group_centrality[selected_groups[2]],
      transitivity_overall,
      transitivity_group1,
      transitivity_group2
    )
  )
  
  #Permutation testing
  if (n_permutations > 0) {
    permuted_stats <- matrix(NA, nrow = n_permutations, ncol = nrow(metrics_df))
    colnames(permuted_stats) <- metrics_df$Metric
    
    for(i in 1:n_permutations) {
      # Create a copy of the original graph
      g_perm <- g
      
      # Shuffle only the group assignments
      current_groups <- igraph::vertex_attr(g, group_var)
      shuffled_groups <- sample(current_groups)
      igraph::vertex_attr(g_perm, group_var) <- shuffled_groups
      
      tryCatch({
        perm_results <- measure_group_interconnections(g_perm, group_var, selected_groups, n_permutations = 0)
        permuted_stats[i,] <- perm_results$Metrics$Value
      }, error = function(e) {
        warning(paste("Permutation", i, "failed:", e$message))
      })
    }
    
    # Calculate statistical measures
    p_values <- sapply(1:ncol(permuted_stats), function(j) {
      observed <- metrics_df$Value[j]
      if(is.numeric(observed)) {
        min(1, 2 * min(
          mean(permuted_stats[,j] >= observed, na.rm = TRUE),
          mean(permuted_stats[,j] <= observed, na.rm = TRUE)
        ))
      } else {
        NA
      }
    })
    
    z_scores <- sapply(1:ncol(permuted_stats), function(j) {
      observed <- metrics_df$Value[j]
      if(is.numeric(observed)) {
        (observed - mean(permuted_stats[,j], na.rm = TRUE)) / sd(permuted_stats[,j], na.rm = TRUE)
      } else {
        NA
      }
    })
    
    ci_lower <- apply(permuted_stats, 2, quantile, probs = 0.025, na.rm = TRUE)
    ci_upper <- apply(permuted_stats, 2, quantile, probs = 0.975, na.rm = TRUE)
    perm_means <- colMeans(permuted_stats, na.rm = TRUE)
    perm_sds <- apply(permuted_stats, 2, sd, na.rm = TRUE)
    
    metrics_df$P_Value <- p_values
    metrics_df$Z_Score <- z_scores
    metrics_df$CI_Lower <- ci_lower
    metrics_df$CI_Upper <- ci_upper
    metrics_df$Null_Mean <- perm_means
    metrics_df$Null_SD <- perm_sds
  }
  
  return(list(
    Metrics = metrics_df,
    Top_Bridging_Nodes = top_bridges,
    Permutation_Results = if(n_permutations > 0) list(
      Permutation_Distribution = permuted_stats,
      Network_Properties = list(
        n_nodes = igraph::vcount(g),
        n_edges = igraph::ecount(g),
        group_sizes = table(igraph::V(g)$group),
        density = igraph::graph.density(g),
        transitivity = transitivity_overall
      )
    ) else NULL
  ))
}

