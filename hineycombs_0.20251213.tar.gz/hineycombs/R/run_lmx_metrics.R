#' Calculate Leader-Member Exchange (LMX) Network Metrics
#'
#' @description
#' Analyzes leader-member exchange patterns in organizational networks by calculating 
#' various metrics of leader-subordinate communication patterns.
#'
#' @param g An igraph object representing the network. Must contain vertex names and 
#'          specified leader attribute.
#' @param leader_attr Character string specifying the vertex attribute containing 
#'                   supervisor IDs. Default is "supervisor_id".
#' @param leaders_are_na Logical indicating if leader positions are marked as NA. 
#'                      Default is FALSE.
#'
#' @return A data frame containing the following columns:
#' \itemize{
#'   \item leader - Name/ID of the leader
#'   \item n_subordinates - Number of subordinates
#'   \item total_outgoing - Total weight of outgoing communications
#'   \item mean_outgoing - Mean weight of outgoing communications
#'   \item sd_outgoing - Standard deviation of outgoing communications
#'   \item cv_outgoing - Coefficient of variation of outgoing communications
#'   \item gini_outgoing - Gini coefficient of outgoing communications
#'   \item most_contacted - Name/ID of most frequently contacted subordinate
#'   \item max_contact_weight - Maximum contact weight with any subordinate
#'   \item cv_interpretation - Interpretation of coefficient of variation
#'   \item gini_interpretation - Interpretation of Gini coefficient
#' }
#'
#' @details
#' The function calculates various metrics to assess the distribution and patterns
#' of leader-member communications:
#' - Coefficient of variation (CV) indicates relative variability in attention
#' - Gini coefficient measures inequality in attention distribution
#' - Additional metrics identify most contacted subordinates and communication volumes
#'
#' @importFrom igraph V vertex_attr as_edgelist edge_attr
#' @importFrom stats sd
#' @importFrom dplyr case_when
#'
#' @examples
#' \dontrun{
#' # Create sample network
#' library(igraph)
#' g <- make_graph("Zachary")
#' V(g)$supervisor_id <- sample(1:5, vcount(g), replace=TRUE)
#' 
#' # Calculate LMX metrics
#' lmx_metrics <- calculate_lmx_metrics_network(g, leader_attr = "supervisor_id")
#' print(lmx_metrics)
#' }
#'
#' @export
run_lmx_metrics <- function(g, leader_attr = "supervisor_id", 
                                                      leaders_are_na = FALSE) {
 
  # Internal Gini function
  calculate_gini <- function(x) {
    x <- sort(x[x > 0])
    n <- length(x)
    if (n <= 1) return(0)
    G <- sum(x * 1:n)
    G <- 2 * G / sum(x) - (n + 1)
    return(G / n)
  }
  
  # Get all vertex names and supervisor IDs
  vertex_names <- V(g)$name
  supervisor_ids <- vertex_attr(g, leader_attr)
  
  # Clean and standardize both vertex names and supervisor IDs
  clean_id <- function(x) {
    # Remove any special characters and standardize format
    x <- gsub("[^[:alnum:]]", "", x)
    return(toupper(x))
  }
  
  # Clean both sets of IDs
  clean_vertex_names <- clean_id(vertex_names)
  clean_supervisor_ids <- clean_id(supervisor_ids)
  
  # Create a mapping between clean and original vertex names
  name_mapping <- setNames(vertex_names, clean_vertex_names)
  
  # Identify leaders - anyone who appears as a supervisor_id
  unique_supervisors <- unique(clean_supervisor_ids[!is.na(clean_supervisor_ids)])
  
  # Find vertices that are supervisors using cleaned IDs
  leaders <- which(clean_vertex_names %in% unique_supervisors)
  
  cat("\nNumber of unique supervisors:", length(unique_supervisors))
  cat("\nNumber of leaders found:", length(leaders))
  
  if(length(leaders) == 0) {
    warning("No leaders found in the network")
    return(data.frame())
  }
  
  # Calculate metrics for each leader
  results <- lapply(leaders, function(leader_idx) {
    # Get leader name (original format)
    leader_name <- vertex_names[leader_idx]
    clean_leader_name <- clean_vertex_names[leader_idx]
    
    # Get subordinates using cleaned IDs
    subordinate_idx <- which(clean_supervisor_ids == clean_leader_name)
    
    if(length(subordinate_idx) == 0) {
      return(NULL)
    }
    
    # Get edges from leader to subordinates
    edge_matrix <- as_edgelist(g)
    edges_to_subordinates <- which(
      edge_matrix[,1] == leader_name & 
        edge_matrix[,2] %in% vertex_names[subordinate_idx]
    )
    
    if(length(edges_to_subordinates) == 0) {
      return(NULL)
    }
    
    # Get weights
    weights <- edge_attr(g, "weight", edges_to_subordinates)
    
    # Get communication frequencies
    comm_freq <- table(edge_matrix[edges_to_subordinates, 2])
    most_contacted <- names(which.max(comm_freq))
    
    # Calculate metrics
    data.frame(
      leader = leader_name,
      n_subordinates = length(subordinate_idx),
      total_outgoing = sum(weights),
      mean_outgoing = mean(weights),
      sd_outgoing = stats::sd(weights),
      cv_outgoing = stats::sd(weights)/mean(weights),
      gini_outgoing = calculate_gini(weights),
      most_contacted = most_contacted,
      max_contact_weight = max(weights)
    )
  })
  
  # Remove NULL results and combine
  results <- results[!sapply(results, is.null)]
  if(length(results) == 0) {
    warning("No valid results found for any leader")
    return(data.frame())
  }
  
  results_df <- do.call(rbind, results)
  
  # Add interpretations
  results_df$cv_interpretation <- dplyr::case_when(
    is.na(results_df$cv_outgoing) ~ NA_character_,
    results_df$cv_outgoing < 0.3 ~ "Low differentiation - equal attention to subordinates",
    results_df$cv_outgoing < 0.6 ~ "Moderate differentiation in attention",
    TRUE ~ "High differentiation - possible favoritism"
  )
  
  results_df$gini_interpretation <- dplyr::case_when(
    is.na(results_df$gini_outgoing) ~ NA_character_,
    results_df$gini_outgoing < 0.2 ~ "Very equal distribution of attention",
    results_df$gini_outgoing < 0.4 ~ "Moderately equal distribution", 
    results_df$gini_outgoing < 0.6 ~ "Unequal distribution of attention",
    TRUE ~ "Highly unequal distribution - strong favoritism"
  )
  
  return(results_df)
}

# # Try running it again
# lmx_chime <- calculate_lmx_metrics_network(g, leader_attr = "supervisor_id")
# print(lmx_chime)
