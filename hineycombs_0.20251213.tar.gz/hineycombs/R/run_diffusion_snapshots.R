#' Simulate and track contagion-style diffusion snapshots with metrics
#'
#' @description
#' Simulates a contagion process over a network and tracks infection metrics
#' while saving static plots and S-curves.
#'
#' @param g An igraph object representing the network.
#' @param attribute Character. Vertex attribute name used to seed infection (threshold-based).
#' @param threshold Numeric in [0,1]. Nodes with attribute > threshold are initial spreaders.
#' @param p Numeric. Probability of infection per neighbor per time step.
#' @param steps Integer. Maximum number of time steps to simulate.
#' @param terminate_pct Numeric in (0,1). Stop simulation early if this % of network is infected.
#' @param cut_points Integer vector. Steps at which to save static network snapshots.
#' @param layout_fun Layout function for plotting (default = layout_with_mds).
#' @param out_prefix Character. Prefix for output PNG files.
#'
#' @return A list with:
#'   \item{graph}{Final igraph object with infection status.}
#'   \item{metrics}{Data frame of infection metrics per step.}
#'   \item{s_curve_plot}{Cumulative infections plot (ggplot object).}
#'   \item{s_percent_plot}{Percent-infected S-curve (ggplot object).}
#' @export
run_diffusion_snapshots <- function(
    g,
    attribute,
    threshold = 0.7,
    p = 0.2,
    steps = 20,
    terminate_pct = 1.00,
    cut_points = c(1, 5, 10, 20),
    layout_fun = igraph::layout_with_mds,
    out_prefix = "diffusion_step"
) {
  stopifnot(igraph::is_igraph(g))
  if (!(attribute %in% igraph::vertex_attr_names(g))) {
    stop(paste("Attribute", attribute, "not found on vertices."))
  }
  
  layout <- layout_fun(g)
  
  vals <- igraph::vertex_attr(g, attribute)
  seeds <- which(vals > threshold)
  if (length(seeds) == 0) stop("No nodes exceed threshold.")
  
  igraph::V(g)$infected <- FALSE
  igraph::V(g)$infected[seeds] <- TRUE
  
  total_nodes <- igraph::vcount(g)
  initial_infected <- length(seeds)
  
  infection_log <- data.frame(
    step = 0,
    new_infections = initial_infected,
    cumulative_infections = initial_infected,
    percent_infected = round(initial_infected / total_nodes * 100, 2),
    reproduction_rate = NA,
    speed_of_spread = round(initial_infected / 1, 3)
  )
  
  update_diffusers <- function(g, p) {
    current <- which(igraph::V(g)$infected)
    newly <- unlist(igraph::neighborhood(g, order = 1, nodes = current, mode = "out"))
    newly <- setdiff(unique(newly), current)
    infect_prob <- runif(length(newly)) < p
    newly <- newly[infect_prob]
    unique(newly)
  }
  
  for (t in seq_len(steps)) {
    newly_infected <- update_diffusers(g, p)
    igraph::V(g)$infected[newly_infected] <- TRUE
    
    cum_inf <- sum(igraph::V(g)$infected)
    new_inf <- length(newly_infected)
    prev_cum_inf <- infection_log$cumulative_infections[nrow(infection_log)]
    
    percent <- round(cum_inf / total_nodes * 100, 2)
    reproduction_rate <- if (prev_cum_inf == 0) NA else round(new_inf / prev_cum_inf, 3)
    speed <- round(cum_inf / (t + 1), 3)
    
    infection_log <- rbind(
      infection_log,
      data.frame(
        step = t,
        new_infections = new_inf,
        cumulative_infections = cum_inf,
        percent_infected = percent,
        reproduction_rate = reproduction_rate,
        speed_of_spread = speed
      )
    )
    
    if (t %in% cut_points) {
      igraph::V(g)$color <- ifelse(igraph::V(g)$infected, "#e74c3c", "#27AE6003")
      grDevices::png(
        filename = paste0(out_prefix, "_t", t, ".png"),
        width = 1200, height = 1200, units = "px"
      )
      igraph::plot.igraph(
        g,
        layout = layout,
        vertex.frame.color = "black",
        vertex.color = igraph::V(g)$color,
        vertex.size = log(igraph::degree(g) + 1),
        vertex.label = NA,
        edge.color = "black",
        edge.curved = 0.5,
        edge.width = 0.1,
        edge.arrow.size = 0.00001,
        main = paste("Diffusion of", attribute, "- Step", t)
      )
      grDevices::dev.off()
    }
    
    if (percent >= terminate_pct * 100) {
      message("✔️ Early termination: ", percent, "% infected at step ", t)
      break
    }
  }
  
  # S-Curve: Cumulative infections
  s_plot <- ggplot2::ggplot(infection_log, ggplot2::aes(x = step, y = cumulative_infections)) +
    ggplot2::geom_line(size = 1.4, color = "#2c3e50") +
    ggplot2::geom_point(size = 2, color = "#e74c3c") +
    ggplot2::labs(
      title = "Contagion Diffusion (S-Curve)",
      x = "Time Step",
      y = "Cumulative Infections"
    ) +
    ggplot2::theme_minimal(base_size = 14)
  
  ggplot2::ggsave(
    filename = paste0(out_prefix, "_s_curve.png"),
    plot = s_plot,
    width = 8, height = 6, dpi = 300
  )
  
  # S-Curve: Percent infected
  s_percent_plot <- ggplot2::ggplot(infection_log, ggplot2::aes(x = step, y = percent_infected)) +
    ggplot2::geom_line(size = 1.4, color = "#2980b9") +
    ggplot2::geom_point(size = 2, color = "#27ae60") +
    ggplot2::labs(
      title = "Percent of Network Infected (S-Curve)",
      x = "Time Step",
      y = "% Infected"
    ) +
    ggplot2::theme_minimal(base_size = 14)
  
  ggplot2::ggsave(
    filename = paste0(out_prefix, "_percent_infected_curve.png"),
    plot = s_percent_plot,
    width = 8, height = 6, dpi = 300
  )
  
  # --- Print key infection milestones ---
  milestones <- c(25, 50, 75, 100)
  milestone_hits <- sapply(milestones, function(pct) {
    which(infection_log$percent_infected >= pct)[1]
  })
  milestone_data <- infection_log[milestone_hits, c("step", "cumulative_infections", "percent_infected", "reproduction_rate", "speed_of_spread")]
  milestone_data$milestone <- paste0(milestones, "%")
  
  # Reorder for clarity
  milestone_data <- milestone_data[, c("milestone", "step", "cumulative_infections", "percent_infected", "reproduction_rate", "speed_of_spread")]
  
  print(milestone_data)
  
  
  message("📈 Saved S-curves and snapshots to disk.")
  invisible(list(
    graph = g,
    metrics = infection_log,
    s_curve_plot = s_plot,
    s_percent_plot = s_percent_plot
  ))
}
