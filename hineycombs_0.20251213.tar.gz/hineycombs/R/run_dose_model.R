#' Compute Dose–Response Exposure Curves From an igraph Network
#'
#' @description
#' `exposure_summary_counts()` computes dose–response exposure curves for one or
#' more vertex attributes in an `igraph` network. For each supplied attribute,
#' the function:
#'
#' * determines which nodes are "high" on that attribute,
#' * counts how many neighbors of each node are also high,
#' * summarizes the percentage of high nodes at each exposure count
#'   (e.g., 0–15 high neighbors),
#' * fits a logistic regression model using the *true* high-neighbor count,
#' * fits a second–order polynomial model using the *true* exposure count,
#' * computes an inflection point and pattern type (U-shape, inverted U, etc.),
#' * and returns a clean tibble with all metrics in a single row per attribute.
#'
#' This function is useful for studying contagion-style effects, social
#' influence, or “dose–response” relationships in organizational networks and
#' other graph structures.
#'
#'
#' @details
#' The key conceptual distinction in this function is between:
#'
#' * **true high-neighbor counts**: used for logistic and polynomial models, and  
#' * **clamped counts** (e.g., 0–15): used only for the exposure table.
#'
#' Regression models require the true count to correctly estimate the marginal
#' effect of one additional high neighbor. The summary exposure table is clamped
#' to the user-supplied `count_range` (e.g., `0:15`) so the output has a fixed,
#' interpretable set of columns (`col_0`, `col_1`, ..., `col_15`).  
#'
#' If a node has a true high-neighbor count above the upper bound of
#' `count_range`, it is retained for regressions but excluded from the exposure
#' table bins.
#'
#'
#' @param g An `igraph` object. Must contain vertex attributes matching the names
#'   supplied in `attributes`.
#'
#' @param attributes A character vector of vertex attribute names to analyze.
#'   Each attribute will produce one row of output summarizing its exposure
#'   curve and regression results.
#'
#' @param high_fn Either:
#'   * a numeric cutoff (e.g., `0.70` meaning _x_ ≥ 0.70 is “high”), or  
#'   * a function of the form `function(x) x >= some_value`.  
#'
#'   If `NULL`, the default uses the 75th percentile of the attribute values.
#'
#' @param count_range An integer vector specifying the exposure bins to include
#'   in the final table. Typically something like `0:15` or `0:20`.  
#'   Exposure values outside this range are still used for regression, but will
#'   appear as `NA` in the summary columns.
#'
#'
#' @return
#' A tibble with one row per input attribute. Columns include:
#'
#' * `attribute` – the attribute name  
#' * `logistic_slope` – coefficient for high-neighbor count  
#' * `logistic_or` – odds ratio (`exp(beta)`)  
#' * `poly_linear`, `poly_quadratic` – polynomial terms  
#' * `inflection_point` – vertex of the quadratic curve  
#' * `pattern` – interpretation of the curve shape  
#' * `col_0`, `col_1`, ..., `col_k` – percentage of high nodes at each exposure
#'   count in `count_range`
exposure_summary_counts <- function(
    g,
    attributes,
    high_fn = NULL,
    count_range = 0:20
) {
  
  # Convert numeric cutoff to function
  if (is.numeric(high_fn)) {
    cutoff_value <- high_fn
    high_fn <- function(x) x >= cutoff_value
  }
  
  # Helper for one attribute
  run_single <- function(attribute) {
    
    x <- igraph::vertex_attr(g, attribute)
    high_flag <- if (is.null(high_fn)) x >= stats::quantile(x, 0.75) else high_fn(x)
    
    g_local <- igraph::set_vertex_attr(g, "high_temp", value = high_flag)
    
    neigh <- igraph::ego(g_local, order = 1, mode = "all")
    
    count_df <- purrr::map2_dfr(
      neigh,
      seq_along(neigh),
      ~{
        neigh_ids <- .x[.x != .y]
        n_high <- ifelse(length(neigh_ids)==0, 0,
                         sum(igraph::vertex_attr(g_local, "high_temp")[neigh_ids]))
        tibble::tibble(id = .y, high_n = n_high)
      }
    )
    
    # -------------------------------------------
    # ENFORCE count_range (this fixes your issue)
    # -------------------------------------------
    min_c <- min(count_range)
    max_c <- max(count_range)
    
    node_df <- tibble::tibble(
      id = seq_len(igraph::vcount(g)),
      focal_value = x,
      focal_high = high_flag
    ) |>
      dplyr::left_join(count_df, by = "id") |>
      dplyr::mutate(
        high_n = dplyr::case_when(
          high_n < min_c ~ NA_integer_,
          high_n > max_c ~ NA_integer_,
          TRUE ~ high_n
        )
      )
    
    # Exposure table within fixed range only
    pct_table <- node_df |>
      dplyr::group_by(high_n) |>
      dplyr::summarise(
        pct_high = mean(focal_high, na.rm = TRUE) * 100,
        .groups = "drop"
      ) |>
      tidyr::complete(high_n = count_range, fill = list(pct_high = NA_real_)) %>% 
      dplyr::filter(!is.na(high_n))
    
    pct_wide <- pct_table |>
      dplyr::mutate(high_n = paste0("col_", high_n)) |>
      tidyr::pivot_wider(names_from = high_n, values_from = pct_high)
    
    # Logistic regression
    # Logistic regression using the TRUE high_n
    log_result <- tryCatch({
      
      fit <- stats::glm(
        focal_high ~ high_n,
        data = node_df,
        family = stats::binomial()
      )
      
      coef_row <- broom::tidy(fit) %>%
        dplyr::filter(term == "high_n") %>%
        dplyr::select(estimate) %>%
        dplyr::rename(logistic_slope = estimate)
      
      # Odds ratio
      logistic_or <- exp(coef_row$logistic_slope)
      
      # Confidence intervals (may fail if separation or non-convergence)
      ci_vals <- tryCatch(
        exp(stats::confint(fit)["high_n", ]),
        error = function(e) c(NA, NA)
      )
      
      logistic_or_lower <- ci_vals[1]
      logistic_or_upper <- ci_vals[2]
      
      dplyr::bind_cols(
        coef_row,
        tibble::tibble(
          logistic_or        = logistic_or#,
          # logistic_or_lower  = logistic_or_lower,
          # logistic_or_upper  = logistic_or_upper
        )
      )
      
    }, error = function(e) {
      tibble::tibble(
        logistic_slope = NA_real_,
        logistic_or = NA_real_,
        logistic_or_lower = NA_real_,
        logistic_or_upper = NA_real_
      )
    })
    
    
    # Polynomial
    poly_fit <- stats::lm(focal_high ~ poly(high_n, 2, raw = TRUE), data = node_df)
    poly_terms <- broom::tidy(poly_fit) |>
      dplyr::filter(term != "(Intercept)") |>
      dplyr::select(term, estimate) |>
      dplyr::mutate(
        term = recode(
          term,
          "poly(high_n, 2, raw = TRUE)1" = "poly_linear",
          "poly(high_n, 2, raw = TRUE)2" = "poly_quadratic"
        )
      ) |>
      tidyr::pivot_wider(names_from = term, values_from = estimate)
    
    b1 <- poly_terms$poly_linear
    b2 <- poly_terms$poly_quadratic
    inflection_point <- ifelse(b2 != 0, -b1/(2*b2), NA_real_)
    
    pattern <- dplyr::case_when(
      is.na(b1) | is.na(b2) ~ NA_character_,
      b2 > 0 & b1 < 0 ~ "U-shape",
      b2 < 0 & b1 > 0 ~ "Inverted U-shape",
      abs(b2) < 1e-6 & b1 > 0 ~ "Positive linear",
      abs(b2) < 1e-6 & b1 < 0 ~ "Negative linear",
      TRUE ~ "Complex"
    )
    
    # Final table
    dplyr::bind_cols(
      tibble::tibble(attribute = attribute),
      log_result,
      poly_terms,
      tibble::tibble(inflection_point, pattern),
      pct_wide
    )
  }
  
  purrr::map_dfr(attributes, run_single)
}