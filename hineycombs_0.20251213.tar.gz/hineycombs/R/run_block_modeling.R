#' Perform Signed Block Modeling on a Graph
#'
#' This function applies signed block modeling to an input \code{igraph} graph and clusters nodes into blocks.
#' It returns a list containing node membership and block summary dataframes, and visualizes both the full 
#' network with block colors and the reduced block network.
#'
#' @param g An \code{igraph} graph object.
#' @param k The number of blocks for clustering. Defaults to 8.
#' @param alpha The alpha parameter for signed block modeling. Defaults to 0.5.
#' @param annealing Logical; whether to use annealing. Defaults to \code{TRUE}.
#' @param min_size Minimum vertex size for node visualization (default = 3).
#' @param max_size Maximum vertex size for node visualization (default = 15).
#' @param min_block_size Minimum vertex size for reduced block network (default = 10).
#' @param max_block_size Maximum vertex size for reduced block network (default = 30).
#'
#' @return A list containing:
#' \itemize{
#'   \item \code{membership_df}: A dataframe with node names and their respective block memberships.
#'   \item \code{block_summary_df}: A summary dataframe showing block membership distribution.
#' }
#'
#' @details
#' The function performs the following:
#' \itemize{
#'   \item Applies signed block modeling to cluster nodes
#'   \item Scales node sizes based on degree centrality
#'   \item Creates two visualizations: full network and reduced block network
#'   \item Returns detailed membership information
#' }
#'
#' @import igraph
#' @import signnet
#' @import blockmodeling
#' @import MetBrewer
#' @importFrom janitor tabyl adorn_totals
#' @importFrom dplyr arrange
#' @importFrom grDevices rainbow
#' @importFrom scales rescale
#'
#' @examples
#' \dontrun{
#' library(igraph)
#' g <- erdos.renyi.game(50, p = 0.1, directed = FALSE)
#' igraph::E(g)$weight <- sample(c(-1, 1), ecount(g), replace = TRUE)
#' block_results <- run_block_modeling(g, k = 5)
#' }
#'
#' @export
run_block_modeling <- function(g, k = 8, alpha = 0.5, annealing = TRUE,
                               min_size = 3, max_size = 15,
                               min_block_size = 10, max_block_size = 30) {
  # Input validation
  if (!"weight" %in% names(igraph::edge.attributes(g))) {
    stop("Graph must have an edge weight attribute.")
  }
  
  library(MetBrewer)
  
  # Convert edge weights into signed values
  igraph::E(g)$sign <- ifelse(igraph::E(g)$weight > 0, 1, -1)
  
  # Perform Signed Block Modeling
  cat("Running Signed Block Modeling...\n")
  clu_simple <- signnet::signed_blockmodel(g, k = k, alpha = alpha, annealing = annealing)
  
  # Extract node block memberships
  membership <- clu_simple$membership
  node_ids <- igraph::V(g)$name
  
  # Create a dataframe of node memberships
  df_membership <- data.frame(node = node_ids, block = membership) %>% dplyr::arrange(block)
  print(head(df_membership))
  
  # Assign block memberships to nodes in the graph
  V(g)$block_general <- membership
  
  # Summarize block membership distribution
  block_summary <- igraph::as_data_frame(g, what = "vertices") %>%
    janitor::tabyl(block_general) %>%
    janitor::adorn_totals()
  print(block_summary)
  
  # Generate colors
  num_blocks <- length(unique(membership))
  palette_name <- "Hokusai1"
  block_colors <- MetBrewer::met.brewer(palette_name, num_blocks)
  node_colors <- block_colors[membership]
  
  # Calculate degree and scale vertex sizes for full network
  degree_values <- igraph::degree(g)
  if (length(unique(degree_values)) == 1) {
    vertex_sizes <- rep(min_size, igraph::vcount(g))
  } else {
    vertex_sizes <- scales::rescale(degree_values, 
                                    to = c(min_size, max_size),
                                    from = range(degree_values))
  }
  
  # Generate layout for plotting
  laycords <- igraph::layout_with_mds(g)
  
  # Plot full graph with block colors and scaled vertex sizes
  par(bg = "white")
  plot(
    igraph::as_undirected(g), 
    vertex.label = NA,
    vertex.color = node_colors, 
    vertex.size = vertex_sizes,  # Use scaled sizes
    layout = laycords, 
    main = "Block Modeling",  
    vertex.label.cex = 0.75,
    vertex.label.color = "black",
    vertex.frame.width = 2,
    edge.width = 1.15,
    edge.curved = 0.5
  )
  
  # Add legend for node sizes
  legend("bottomright", 
         title = "Node Degree Range",
         legend = paste(min(degree_values), "to", max(degree_values)),
         bty = "n")
  
  # Reduce the network to blocks
  g_reduced <- igraph::contract(g, membership, vertex.attr.comb = list(weight = "sum", "ignore"))
  g_reduced <- igraph::simplify(g_reduced, edge.attr.comb = list(weight = "sum"))
  
  # Calculate and scale vertex sizes for reduced network based on block sizes
  block_sizes <- table(membership)
  if (length(unique(block_sizes)) == 1) {
    reduced_vertex_sizes <- rep(min_block_size, length(block_sizes))
  } else {
    reduced_vertex_sizes <- scales::rescale(block_sizes,
                                            to = c(min_block_size, max_block_size),
                                            from = range(block_sizes))
  }
  
  # Assign colors to reduced blocks
  V(g_reduced)$color <- block_colors[unique(membership)]
  
  # Plot the reduced block network
  par(bg = "white")
  plot(
    g_reduced,
    layout = igraph::layout_with_mds(g_reduced),
    vertex.size = reduced_vertex_sizes,  # Use scaled block sizes
    edge.color = "black",
    vertex.label = igraph::V(g_reduced)$name,
    edge.width = igraph::E(g_reduced)$weight * 0.005,
    vertex.color = igraph::V(g_reduced)$color,
    main = "Reduced Network of Blocks"
  )
  
  # Add legend for block sizes
  legend("bottomright", 
         title = "Block Size Range",
         legend = paste(min(block_sizes), "to", max(block_sizes), "nodes"),
         bty = "n")
  
  return(list(
    membership_df = df_membership,
    block_summary_df = block_summary
  ))
}
