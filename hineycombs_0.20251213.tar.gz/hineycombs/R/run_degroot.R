#' Run DeGroot Learning/Diffusion on Vertex Attributes
#'
#' @description
#' Iteratively applies the DeGroot update
#' \deqn{x_{t+1} = \alpha x_t + (1-\alpha)\,D^{-1} A\,x_t}
#' to each supplied vertex attribute, where \eqn{A} is the (possibly directed)
#' adjacency matrix (sparse), and \eqn{D} is its row-sum diagonal.
#' Results are returned per node (long and wide formats) and summarized per
#' attribute. When multiple attributes are provided, an omnibus comparison
#' (ANOVA or Kruskal–Wallis) is performed on the final opinions.
#'
#' You can also write the final values back to the graph (with a suffix or
#' overwriting the original), and optionally treat missing values as true
#' "no opinion yet" via \code{na_impute = "ignore"} so a node only changes
#' after exposure to at least one neighbor with a value.
#'
#' @param g An \code{igraph} graph.
#' @param attribute_names Character vector of vertex attribute names to diffuse.
#'   Each attribute is diffused independently.
#' @param method One of \code{"anova"}, \code{"kruskal"}, or \code{"none"} for
#'   the omnibus test across attributes (if length(attribute_names) > 1).
#' @param max_iter Integer maximum iterations (default 1000).
#' @param tol Convergence tolerance on the max absolute change between
#'   successive iterations (default 1e-6).
#' @param self_weight Numeric \eqn{\alpha \in [0,1)} self-trust weight (default 0.1).
#'   Isolates (zero degree) retain their own value via this weight.
#' @param directed_mode \code{"in"}, \code{"out"}, or \code{"undirected"} (default "in").
#'   For directed graphs, \code{"in"} means a node averages its in-neighbors (listeners view),
#'   \code{"out"} averages out-neighbors; undirected symmetrizes the adjacency.
#' @param use_sparse Logical; use \pkg{Matrix} sparse ops (default TRUE).
#' @param na_impute One of \code{"mean"}, \code{"zero"}, or \code{"ignore"}.
#'   With \code{"ignore"}, nodes with \code{NA} are treated as having no opinion
#'   (ignored in neighbors' averages) and only take on a value once exposed.
#'   Default \code{"mean"} for backward-compatibility.
#' @param restrict_to_reachable Logical; if \code{TRUE}, for each attribute restrict
#'   the diffusion to nodes reachable from the nonzero, non-\code{NA} seed set
#'   (out-reachability when \code{directed_mode != "undirected"}; all-neighborhood otherwise).
#'   Nodes outside the reachable set retain their initial values. Default \code{FALSE}.
#' @param write_back One of \code{"none"} (default), \code{"suffix"}, \code{"overwrite"}.
#'   If \code{"suffix"}, final values are written as \code{<attr>_dg_final}.
#'   If \code{"overwrite"}, final values replace the original \code{<attr>}.
#' @param suffix Character suffix used when \code{write_back="suffix"} (default "_dg_final").
#'
#' @details
#' \strong{Implementation notes:}
#' \itemize{
#' \item We compute \eqn{x_{t+1} = \alpha x_t + (1-\alpha) D^{-1}(A x_t)} directly (no explicit W).
#' \item For \code{directed_mode="in"}, the adjacency is transposed so each row lists alters being averaged.
#' \item Row-stochasticity is ensured via left-multiplication by \eqn{D^{-1}}.
#' \item With \code{na_impute="ignore"}, we ignore \code{NA} neighbors in the average; a node with \code{NA}
#'       stays \code{NA} until at least one neighbor has a value; isolates with \code{NA} remain \code{NA}.
#' }
#'
#' @return A list with:
#' \describe{
#'   \item{\code{node_level}}{Long table: \code{node}, \code{attribute}, \code{final_opinion}.}
#'   \item{\code{node_wide}}{Wide table: one row per node; columns for each attribute's final value.}
#'   \item{\code{attribute_summary}}{Per-attribute summary with columns:
#'         \code{attribute}, \code{initial_mean}, \code{mean_final_opinion},
#'         \code{sd_final_opinion}, \code{shift_from_initial_mean},
#'         \code{iterations_to_converge}.}
#'   \item{\code{test_result}}{ANOVA or Kruskal–Wallis object (or \code{NULL}).}
#'   \item{\code{posthoc}}{Tukey HSD object if \code{method="anova"} and multiple attributes (else \code{NULL}).}
#'   \item{\code{graph}}{Graph with final values written back (if \code{write_back != "none"}).}
#' }
#'
#' @export
run_degroot <- function(
    g,
    attribute_names,
    method = c("anova","kruskal","none"),
    max_iter = 1000,
    tol = 1e-6,
    self_weight = 0.1,
    directed_mode = c("in","out","undirected"),
    use_sparse = TRUE,
    na_impute = c("mean","zero","ignore"),
    restrict_to_reachable = FALSE,
    write_back = c("none","suffix","overwrite"),
    suffix = "_dg_final"
){
  method <- match.arg(method)
  directed_mode <- match.arg(directed_mode)
  na_impute <- match.arg(na_impute)
  write_back <- match.arg(write_back)
  
  if (!igraph::is_igraph(g)) stop("g must be an igraph.")
  if (length(attribute_names) < 1) stop("Provide at least one attribute name.")
  
  # --- Build adjacency (sparse by default) ---
  A <- igraph::as_adjacency_matrix(g, sparse = use_sparse)
  # Orient rows to list alters to average
  if (igraph::is_directed(g)) {
    if (directed_mode == "in") {
      A <- Matrix::t(A)
    } else if (directed_mode == "out") {
      A <- A
    } else {
      A <- (A + Matrix::t(A)) / 2
    }
  } else {
    A <- (A + Matrix::t(A)) / 2
  }
  
  n <- igraph::vcount(g)
  vnames <- igraph::V(g)$name
  if (is.null(vnames)) vnames <- as.character(seq_len(n))
  
  # Precompute row sums and D^{-1}
  rs <- Matrix::rowSums(A)
  inv_rs <- 1 / rs
  inv_rs[!is.finite(inv_rs)] <- 0
  if (use_sparse) {
    Dinv <- Matrix::Diagonal(n = n, x = inv_rs)
  } else {
    Dinv <- diag(inv_rs)
  }
  
  # --- DeGroot steps ---
  .degroot_step <- function(x, alpha = self_weight) {
    # standard: all nodes numeric
    alpha * x + (1 - alpha) * as.numeric(Dinv %*% (A %*% x))
  }
  
  .degroot_step_ignore <- function(x, alpha = self_weight, A_mat = A) {
    # x may contain NA: treat NA as "no opinion", ignore in neighbor averages
    m <- !is.na(x)                         # who currently has an opinion
    x_noNA <- x
    x_noNA[!m] <- 0                        # for matrix ops
    
    Ax <- as.numeric(A_mat %*% x_noNA)     # neighbor sum of values
    Ac <- as.numeric(A_mat %*% as.numeric(m))  # number of contributing neighbors
    
    y <- Ax / Ac                           # neighbor mean (undefined if Ac==0)
    y[Ac == 0] <- NA_real_
    
    out <- x
    idx_has <- which(m)
    # nodes that already have a value: convex combo with neighbor mean if available
    out[idx_has] <- ifelse(
      is.na(y[idx_has]), x[idx_has], alpha * x[idx_has] + (1 - alpha) * y[idx_has]
    )
    # nodes with no value yet: take neighbor mean when available, else stay NA
    idx_na <- which(!m)
    out[idx_na] <- ifelse(is.na(y[idx_na]), NA_real_, y[idx_na])
    
    out
  }
  
  # Iterate until convergence or max_iter
  .iterate <- function(x0, alpha = self_weight, tol = tol, max_iter = max_iter, na_mode = na_impute) {
    x <- x0
    it <- 0
    repeat {
      x_new <- if (na_mode == "ignore") .degroot_step_ignore(x, alpha, A) else .degroot_step(x, alpha)
      it <- it + 1
      if (max(abs(x_new - x), na.rm = TRUE) < tol || it >= max_iter) break
      x <- x_new
    }
    list(x = as.numeric(x_new), it = it)
  }
  
  # Subgraph iterator when restrict_to_reachable = TRUE
  .iterate_sub_builder <- function(A_sub, na_mode) {
    if (use_sparse) {
      rs_sub <- Matrix::rowSums(A_sub)
    } else {
      rs_sub <- rowSums(A_sub)
    }
    inv_rs_sub <- 1 / rs_sub
    inv_rs_sub[!is.finite(inv_rs_sub)] <- 0
    Dinv_sub <- if (use_sparse) Matrix::Diagonal(n = nrow(A_sub), x = inv_rs_sub) else diag(inv_rs_sub)
    
    .degroot_step_sub <- function(x, alpha = self_weight) {
      alpha * x + (1 - alpha) * as.numeric(Dinv_sub %*% (A_sub %*% x))
    }
    .degroot_step_ignore_sub <- function(x, alpha = self_weight) {
      m <- !is.na(x)
      x_noNA <- x; x_noNA[!m] <- 0
      Ax <- as.numeric(A_sub %*% x_noNA)
      Ac <- as.numeric(A_sub %*% as.numeric(m))
      y <- Ax / Ac; y[Ac == 0] <- NA_real_
      out <- x
      idx_has <- which(m)
      out[idx_has] <- ifelse(is.na(y[idx_has]), x[idx_has], alpha * x[idx_has] + (1 - alpha) * y[idx_has])
      idx_na <- which(!m)
      out[idx_na] <- ifelse(is.na(y[idx_na]), NA_real_, y[idx_na])
      out
    }
    
    function(x0, alpha = self_weight, tol = tol, max_iter = max_iter) {
      x <- x0; it <- 0
      repeat {
        x_new <- if (na_mode == "ignore") .degroot_step_ignore_sub(x, alpha) else .degroot_step_sub(x, alpha)
        it <- it + 1
        if (max(abs(x_new - x), na.rm = TRUE) < tol || it >= max_iter) break
        x <- x_new
      }
      list(x = as.numeric(x_new), it = it)
    }
  }
  
  # Reachable set helper
  .reachable_indices <- function(seed_idx) {
    if (!restrict_to_reachable || length(seed_idx) == 0) {
      return(seq_len(n))
    }
    if (!igraph::is_directed(g) || directed_mode == "undirected") {
      reach <- unique(unlist(igraph::neighborhood(g, order = Inf, nodes = seed_idx, mode = "all")))
    } else if (directed_mode == "in") {
      reach <- unique(unlist(igraph::neighborhood(g, order = Inf, nodes = seed_idx, mode = "out")))
    } else {
      reach <- unique(unlist(igraph::neighborhood(g, order = Inf, nodes = seed_idx, mode = "out")))
    }
    as.integer(reach)
  }
  
  all_results <- list()
  summary_table <- utils::head(data.frame(), 0)
  posthoc_result <- NULL
  test_result <- NULL
  
  for (attr in attribute_names) {
    if (!(attr %in% igraph::vertex_attr_names(g))) {
      warning(paste("Attribute", attr, "not found — skipping"))
      next
    }
    initial <- igraph::vertex_attr(g, attr)
    
    # Impute NAs or keep as NA for "ignore"
    if (anyNA(initial) && na_impute != "ignore") {
      if (na_impute == "mean") {
        m <- mean(initial, na.rm = TRUE)
        initial[is.na(initial)] <- m
      } else if (na_impute == "zero") {
        initial[is.na(initial)] <- 0
      }
    }
    initial <- as.numeric(initial)
    names(initial) <- vnames
    
    # Seeds: non-NA and nonzero values (for reachability)
    if (na_impute == "ignore") {
      seeds <- which(!is.na(initial) & initial != 0 & is.finite(initial))
    } else {
      seeds <- which(initial != 0 & is.finite(initial))
    }
    
    # Restrict if requested
    idx <- .reachable_indices(seeds)
    
    if (length(idx) < n) {
      # Build submatrices
      A_sub <- A[idx, idx, drop = FALSE]
      iter_sub <- .iterate_sub_builder(A_sub, na_mode = na_impute)
      x0_sub <- initial[idx]
      res <- iter_sub(x0_sub, alpha = self_weight, tol = tol, max_iter = max_iter)
      
      # Preserve initial values outside reachable set
      final_full <- initial
      final_full[idx] <- res$x
      iters <- res$it
      final <- final_full
    } else {
      res <- .iterate(initial, alpha = self_weight, tol = tol, max_iter = max_iter, na_mode = na_impute)
      final <- res$x
      iters <- res$it
    }
    
    initial_mean <- mean(initial, na.rm = TRUE)
    all_results[[attr]] <- data.frame(
      node = vnames,
      attribute = attr,
      final_opinion = final,
      stringsAsFactors = FALSE
    )
    
    summary_table <- rbind(
      summary_table,
      data.frame(
        attribute = attr,
        initial_mean = initial_mean,
        mean_final_opinion = mean(final, na.rm = TRUE),
        sd_final_opinion = stats::sd(final, na.rm = TRUE),
        shift_from_initial_mean = abs(mean(final, na.rm = TRUE) - initial_mean),
        iterations_to_converge = iters,
        stringsAsFactors = FALSE
      )
    )
  }
  
  long_results <- dplyr::bind_rows(all_results)
  
  # Omnibus test if desired
  if (length(unique(long_results$attribute)) > 1 && method != "none") {
    if (method == "anova") {
      test_result <- stats::aov(final_opinion ~ attribute, data = long_results)
      utils::capture.output(print(summary(test_result)))
      posthoc_result <- stats::TukeyHSD(test_result)
      utils::capture.output(print(posthoc_result))
    } else if (method == "kruskal") {
      test_result <- stats::kruskal.test(final_opinion ~ attribute, data = long_results)
      utils::capture.output(print(test_result))
      posthoc_result <- NULL
    }
  } else {
    posthoc_result <- NULL
    test_result <- NULL
  }
  
  # Wide table for easy per-node access
  node_wide <- tidyr::pivot_wider(
    long_results,
    id_cols = node,
    names_from = attribute,
    values_from = final_opinion
  )
  
  # Write final values back to the graph if requested
  g_out <- g
  if (write_back != "none") {
    for (attr in unique(long_results$attribute)) {
      sub  <- long_results[long_results$attribute == attr, c("node","final_opinion")]
      vals <- sub$final_opinion[match(vnames, sub$node)]
      if (write_back == "overwrite") {
        g_out <- igraph::set_vertex_attr(g_out, name = attr, value = vals)
      } else if (write_back == "suffix") {
        new_name <- paste0(attr, suffix)
        g_out <- igraph::set_vertex_attr(g_out, name = new_name, value = vals)
      }
    }
  }
  
  list(
    node_level = long_results,
    node_wide = node_wide,
    attribute_summary = summary_table,
    test_result = test_result,
    posthoc = posthoc_result,
    graph = g_out
  )
}
