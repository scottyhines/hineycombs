#' Create a Synthetic Organizational Network
#'
#' @description
#' Generates a reproducible synthetic network with both categorical and numeric
#' vertex attributes. Useful for testing DeGroot diffusion, network metrics, or
#' simulation workflows.
#'
#' @param n Number of nodes (default = 500).
#' @param p Edge probability for Erdős–Rényi model (default = 0.1).
#' @param directed Logical; whether to create a directed graph. Default = FALSE.
#' @param seed Optional integer seed for reproducibility. Default = 123.
#'
#' @details
#' Adds several categorical attributes (group, gender, region, performance,
#' job_level, team) and numeric ones (psych_safety, risk_taking, innovation,
#' collaboration_quality). Numeric variables are drawn from truncated normal
#' distributions with modest intercorrelations.
#'
#' @return An \code{igraph} object with both vertex and edge attributes.
#' @export
create_network <- function(n = 500, p = 0.1, directed = FALSE, seed = 123) {
  if (!is.numeric(n) || n <= 0)
    stop("n must be a positive number")
  if (!is.numeric(p) || p <= 0 || p >= 1)
    stop("p must be between 0 and 1")
  if (!is.logical(directed))
    stop("directed must be TRUE or FALSE")
  
  if (!is.null(seed)) set.seed(seed)
  
  g <- igraph::sample_gnp(n, p = p, directed = directed)
  igraph::V(g)$name <- paste0("Node", sprintf("%03d", 1:n))
  
  # ----------------------------
  # Categorical attributes
  # ----------------------------
  group_probs <- c(0.4, 0.3, 0.2, 0.1)
  igraph::V(g)$group <- sample(LETTERS[1:4], n, replace = TRUE, prob = group_probs)
  
  igraph::V(g)$gender <- sample(c("M", "F"), n, replace = TRUE, prob = c(0.52, 0.48))
  
  regions <- c("North", "South", "East", "West", "Central")
  igraph::V(g)$region <- sample(regions, n, replace = TRUE)
  
  igraph::V(g)$performance <- sample(1:5, n, replace = TRUE, prob = c(0.1, 0.2, 0.4, 0.2, 0.1))
  
  job_levels <- c("Entry", "Junior", "Senior", "Lead", "Manager", "Director")
  level_probs <- c(0.2, 0.3, 0.25, 0.15, 0.07, 0.03)
  igraph::V(g)$job_level <- sample(job_levels, n, replace = TRUE, prob = level_probs)
  
  team_names <- c("Alpha", "Beta", "Gamma", "Delta", "Epsilon", "Omega")
  igraph::V(g)$team <- sample(team_names, n, replace = TRUE)
  
  # ----------------------------
  # Numeric attributes (scaled 0–1)
  # ----------------------------
  psych_safety <- pmin(pmax(stats::rnorm(n, mean = 0.65, sd = 0.15), 0), 1)
  risk_taking  <- pmin(pmax(0.7 - psych_safety + stats::rnorm(n, 0, 0.15), 0), 1)
  innovation   <- pmin(pmax((psych_safety * 0.4 + risk_taking * 0.6) + stats::rnorm(n, 0, 0.1), 0), 1)
  collaboration_quality <- pmin(pmax((psych_safety * 0.6 + innovation * 0.3) + stats::rnorm(n, 0, 0.1), 0), 1)
  
  igraph::V(g)$psych_safety <- psych_safety
  igraph::V(g)$risk_taking <- risk_taking
  igraph::V(g)$innovation <- innovation
  igraph::V(g)$collaboration_quality <- collaboration_quality
  
  # ----------------------------
  # Edge weights
  # ----------------------------
  igraph::E(g)$weight <- sample(1:10, igraph::ecount(g), replace = TRUE)
  
  return(g)
}
