#' Identify Node–Edge Mismatches in a Network
#'
#' @description
#' `find_edge_node_mismatches()` diagnoses inconsistencies between a node list
#' and an edge list by identifying all vertex names that appear in the edge list
#' but do **not** appear in the node data frame. This is especially useful when
#' preparing network data for packages like **igraph**, which require all
#' referenced vertices in the edge list to exist in the vertex table.
#'
#' @details
#' The function checks that the specified node ID column exists in the node
#' data frame and that the `from` and `to` columns exist in the edge list. It
#' then identifies:
#' 
#' * all unique node identifiers in the node table  
#' * all unique names referenced in edges  
#' * any edge endpoints missing from the node table  
#' * all edge rows that contain these missing node names  
#'
#' This helps pinpoint data quality issues such as inconsistent casing,
#' trailing whitespace, alternative spellings, or incomplete node metadata.
#'
#' @param nodes A data frame containing node attributes. Must include a
#'   column containing unique node identifiers.
#' @param edges A data frame containing edge relationships. Must include
#'   `from` and `to` columns (or equivalents specified via `from_col`
#'   and `to_col`).
#' @param node_id_col A string specifying the column name in `nodes` that
#'   contains vertex identifiers. Defaults to `"name"`.
#' @param from_col A string specifying the column name in `edges` that
#'   represents the source node. Defaults to `"from"`.
#' @param to_col A string specifying the column name in `edges` that
#'   represents the target node. Defaults to `"to"`.
#'
#' @return
#' A list with the following elements:
#' \describe{
#'   \item{summary}{A data frame summarizing the total number of nodes in
#'                 the node table, unique node names referenced in edges,
#'                 and the count of missing nodes.}
#'   \item{missing_nodes}{A character vector of node names appearing in the
#'                        edge list but not in the node list.}
#'   \item{problematic_edges}{A data frame containing only the edges that
#'                            reference missing nodes.}
#' }
#'
#' @examples
#' \dontrun{
#' # Example node table
#' nodes <- data.frame(
#'   name = c("A", "B", "C")
#' )
#'
#' # Example edges with one invalid endpoint
#' edges <- data.frame(
#'   from = c("A", "B", "X"),
#'   to   = c("B", "C", "C")
#' )
#'
#' find_edge_node_mismatches(nodes, edges)
#' }
#'
#' @export
find_edge_node_mismatches <- function(nodes, edges,
                                      node_id_col = "name",
                                      from_col = "from",
                                      to_col = "to") {
  
  # Ensure columns exist
  if (!node_id_col %in% names(nodes)) {
    stop(paste0("Node ID column '", node_id_col, "' not found in nodes."))
  }
  if (!from_col %in% names(edges) || !to_col %in% names(edges)) {
    stop("Check your edge list: from/to columns not found.")
  }
  
  # Known node names
  node_names <- unique(nodes[[node_id_col]])
  
  # All node names referenced in the edges
  edge_nodes <- unique(c(edges[[from_col]], edges[[to_col]]))
  
  # Which nodes appear in edges but not in nodes?
  missing_nodes <- setdiff(edge_nodes, node_names)
  
  # Get edges involving these missing nodes
  problematic_edges <- edges[edges[[from_col]] %in% missing_nodes |
                               edges[[to_col]] %in% missing_nodes, ]
  
  # Return a structured result
  list(
    summary = data.frame(
      total_nodes_in_nodes = length(node_names),
      total_unique_edge_nodes = length(edge_nodes),
      num_missing_nodes = length(missing_nodes)
    ),
    missing_nodes = missing_nodes,
    problematic_edges = problematic_edges
  )
}
