#' Calculate Network-Level Metrics
#'
#' @description
#' Calculates various network metrics including basic statistics, centralization measures,
#' community structure, and assortativity. Returns results as a single-row data frame.
#'
#' @param g An igraph object. The network to analyze.
#' @param assortivity_vars Character vector. Names of vertex attributes to calculate 
#'        assortativity for. Default is NULL.
#'
#' @return A data frame with one row containing the following columns:
#' \itemize{
#'   \item vcount: Number of vertices
#'   \item ecount: Number of edges
#'   \item diameter: Network diameter
#'   \item density: Network density
#'   \item average_path_length: Mean distance between vertices
#'   \item small_world: Small-world index (if calculable)
#'   \item modularity: Network modularity (if calculable)
#'   \item transitivity: Global transitivity coefficient
#'   \item centralization_betweenness: Betweenness centralization
#'   \item centralization_degree: Degree centralization
#'   \item centralization_closeness: Closeness centralization
#'   \item centralization_eigen: Eigenvector centralization
#'   \item number_of_components: Number of connected components
#'   \item max_component_size: Size of largest component
#'   \item assortativity_*: Assortativity for specified variables (if requested)
#' }
#'
#' @examples
#' # Create a random network
#' g <- igraph::sample_gnp(100, 0.1)
#' 
#' # Calculate basic metrics
#' metrics <- calculate_network_metrics(g)
#' 
#' # Calculate metrics including assortativity for specific attributes
#' g_attr <- igraph::set_vertex_attr(g, "type", value = sample(1:3, 100, replace = TRUE))
#' metrics_with_assort <- calculate_network_metrics(g, assortivity_vars = "type")
#'
#' @importFrom igraph vcount ecount diameter edge_density mean_distance transitivity
#' @importFrom igraph cluster_fast_greedy modularity components vertex_attr_names vertex_attr
#' @importFrom igraph centr_betw centr_degree centr_clo centr_eigen assortativity_nominal
#' @importFrom qgraph smallworldIndex
#' @export
calculate_network_metrics <- function(g, assortivity_vars = NULL, intensive_calc = FALSE) {
  metrics <- list()
  cat("Starting network metrics calculation...\n")
  
  # Basic metrics (always calculated)
  metrics$vcount <- igraph::vcount(g)
  print("Calculated: vcount")
  metrics$ecount <- igraph::ecount(g)
  print("Calculated: ecount")
  metrics$density <- igraph::edge_density(g)
  print("Calculated: density")
  
  # Intensive calculations (optional)
  if(intensive_calc) {
    metrics$diameter <- igraph::diameter(g, directed = FALSE, 
                                         unconnected = TRUE)
    print("Calculated: diameter")
    metrics$average_path_length <- igraph::mean_distance(g)
    print("Calculated: average path length")
    metrics$centralization_betweenness <- tryCatch(igraph::centr_betw(g)$centralization, 
                                                   error = function(e) NA)
    print("Calculated: betweenness centralization")
    # Small world calculation
    tryCatch({
      calc_small_world <- qgraph::smallworldIndex(g)
      metrics$small_world <- calc_small_world$index
      print("Calculated: small world index")
    }, error = function(e) {
      metrics$small_world <- NA
      print("Failed to calculate: small world index")
    })
  } else {
    metrics$diameter <- NA
    metrics$average_path_length <- NA
    metrics$centralization_betweenness <- NA
    metrics$small_world <- NA
    print("Skipped intensive calculations (diameter, average path length, betweenness centralization, small world index)")
  }
  
  # Other metrics
  tryCatch({
    comm <- igraph::cluster_fast_greedy(igraph::as_undirected(g))
    metrics$modularity <- igraph::modularity(comm)
    print("Calculated: modularity")
  }, error = function(e) {
    metrics$modularity <- NA
    print("Failed to calculate: modularity")
  })
  
  metrics$transitivity <- igraph::transitivity(g, type = "global")
  print("Calculated: transitivity")
  metrics$centralization_degree <- tryCatch(igraph::centr_degree(g, 
                                                                 mode = "total")$centralization, error = function(e) NA)
  print("Calculated: degree centralization")
  metrics$centralization_closeness <- tryCatch(igraph::centr_clo(g)$centralization, 
                                               error = function(e) NA)
  print("Calculated: closeness centralization")
  metrics$centralization_eigen <- tryCatch(igraph::centr_eigen(g)$centralization, 
                                           error = function(e) NA)
  print("Calculated: eigenvector centralization")
  
  # Assortivity calculations
  if (!is.null(assortivity_vars)) {
    for (var in assortivity_vars) {
      if (var %in% igraph::vertex_attr_names(g)) {
        metrics[[paste0("assortativity_", var)]] <- tryCatch(igraph::assortativity_nominal(g, 
                                                                                           types = igraph::vertex_attr(g, var)), error = function(e) NA)
        print(paste("Calculated: assortativity for", var))
      }
      else {
        metrics[[paste0("assortativity_", var)]] <- NA
        print(paste("Skipped: assortativity for", var, "(attribute not found)"))
      }
    }
  }
  
  # Component analysis
  comp <- igraph::components(g)
  metrics$number_of_components <- comp$no
  metrics$max_component_size <- max(comp$csize)
  print("Calculated: number of components and max component size")
  
  print("Network metrics calculation completed.")
  return(as.data.frame(metrics))
}