setwd("/Users/scotthines/Dropbox/@projects/01_analytic_projects/hineycombs")
library(roxygen2)
devtools::document()  # generates NAMESPACE with export(create_network)
devtools::load_all()  # reloads the package so hineycombs::create_network is available
devtools::check()
# build ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
devtools::build()
# install package ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#install.packages("/Users/scotthines/Dropbox/@projects/01_analytic_projects/hineycombs_0.20251120.tar.gz", repos = NULL, type = "source")
install.packages("/Users/scotthines/Dropbox/@projects/01_analytic_projects/hineycombs_0.20251213.tar.gz", repos = NULL, type = "source")

# test functions ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
library(hineycombs)
library(scottyhines)
# create network ~~~~~~~~~~~~~
g <- hineycombs::create_network(n = 240, p = .2, directed = F)
igraph::vertex_attr_names(g)
igraph::vertex.attributes(g)
plot(g)

g <- calculate_centrality_metrics(g, include_advanced_metrics = F)
g <- calculate_centrality_metrics(g, include_advanced_metrics = T)
# calcuatte metrics ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
hineycombs::calculate_centrality_metrics(g, include_advanced_metrics = F)
# Network-Wide~~~~~~~~~~~~~~~
hineycombs::calculate_network_metrics(g, assortivity_vars = "performance")
# Mixing Matrix ~~~~~~~~~~~~~
hineycombs::run_mixing_matrix(g, 10, attribute_name = "group", type = "connections", percentage = T, exclude_diagonal = T)
# Run Neighbors ~~~~~~~~~~~~~
hineycombs::run_neighbors(g, attribute_name = "name", group_value = "Node001", attribute_to_analyze = "region")
# cross group interactions ~~
temp_groups = c("Alpha", "Omega")
hineycombs::measure_group_interconnections(g, group_var = "team", selected_groups = temp_groups, n_permutations = 500)
# find best friend ~~~~~~~~~~
hineycombs::run_find_best_friend(g)
# node removal ~~~~~~~~~~~~~
nodes_to_go <- c("Node001", "Node002")
hineycombs::run_node_removal_impact(g, nodes_to_remove = nodes_to_go)  # or whatever the correct format is
# block modeling ~~~~~~~~~~~~
hineycombs::run_block_modeling(g, k = 8)
# Kcore  ~~~~~~~~~~~~~~~~~~~~
hineycombs::run_kcore(g)
# cliques ~~~~~~~~~~~~~~~~~~~
hineycombs::run_cliques(g)
# link prediction ~~~~~~~~~~~
out <- run_link_prediction(g, group_var = "region", return_group_summary = TRUE, top_n = 100)
out$predicted_links # View predicted links
out$group_summary # View group-to-group summary
# run degroot ~~~~~~~~~~~~~~~
out_degroot <- hineycombs::run_degroot(g, attribute_names = c("psych_safety", "risk_taking", "innovation", "collaboration_quality", "performance"), na_impute = "ignore")
out_degroot$test_result
out_degroot$posthoc
out_degroot$attribute_summary
x <- out_degroot$node_wide

# ossilation ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
g1 <- hineycombs::create_network(n = 300, p = .1, directed = T, seed = 123)
g2 <- hineycombs::create_network(n = 300, p = .1, directed = T, seed = 124)
g3 <- hineycombs::create_network(n = 300, p = .1, directed = T, seed = 125)
g1 <- hineycombs::calculate_centrality_metrics(g1, include_advanced_metrics = F)
g2 <- hineycombs::calculate_centrality_metrics(g2, include_advanced_metrics = F)
g3 <- hineycombs::calculate_centrality_metrics(g3, include_advanced_metrics = F)
node1 <- hineycombs::pull_data(g1, "nodes") %>% dplyr::mutate(time = "timee1")
node2 <- hineycombs::pull_data(g2, "nodes") %>% dplyr::mutate(time = "timee2")
node3 <- hineycombs::pull_data(g3, "nodes") %>% dplyr::mutate(time = "timee3")
wd <- dplyr::bind_rows(node1, node2, node3)
out_ossilation <- hineycombs::calculate_oscillation_metrics(wd, variables = "degree", id_col = "name")
out_ossilation$individual_scores

# Plots ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# basic~~~~~~~~~~~~~~~~~~~~~~~
hineycombs::plot_network(g, group_var = "region", min_size = 5, max_size = 8)
hineycombs::plot_network(g, group_var = "performance")
# reach ~~~~~~~~~~~~~~~~~~~~~~
hineycombs::plot_reach(g, attribute_name = "group", group_value = "A", highlight_connections = F, transparency = .5, min_size = 5, max_size = 10)
hineycombs::plot_reach(g, attribute_name = "group", group_value = "A", highlight_connections = T, transparency = .5, min_size = 5, max_size = 10)
# communities~~~~~~~~~~~~~~~~~
hineycombs::plot_communities(g, algorithms = c("walktrap"), min_size = 5, max_size = 12)
# group interactions ~~~~~~~~~
temp_groups = c("Alpha", "Omega")
plot_group_interconnections(g, group_var = "team", selected_groups = temp_groups)
# Suseptable-infected
out_si <- hineycombs::run_diffusion_snapshots(g, attribute = "innovation", threshold = .6)
out_si$metrics
out_si$s_percent_plot












# usethis::use_test("square_number")
# usethis::use_test("run_t_test")
# usethis::use_test("run_hierarchical_regression")
# usethis::use_test("run_linear_regression")
# usethis::use_test("run_logistic_regression")
# usethis::use_test("run_network_analysis")
#usethis::use_test("create_fake_data")



#devtools::install("~/scottyhines")
#install.packages("//Users/hinessco/scottyhines/scottyhines_0.20241227.tar.gz", repos = NULL, type = "source")

# test functions ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

library(scottyhines)
library(dplyr)
library(discrim)

# create fake data ~~~~~~~~~~~~~~~~~~
df <- scottyhines::create_fake_data(5000) %>% dplyr::mutate(id = as.factor(id))
df %>% dplyr::mutate(quartile_group = scottyhines::quartile_categorize(demo_tenure)) %>%
  dplyr::mutate(quartile_group = as.factor(quartile_group)) %>% glimpse()

# set outcomes and predictors ~~~~~~~
outcomes <- c("attitude_work_ethic", "attitude_adaptability", "attitude_creativity")
vars_of_interest <- c("attitude_teamwork", "attitude_communication", "attitude_persistence")

# statifed sampling ~~~~~~~~~~~~~~~~~
out <- scottyhines::create_stratified_sample(df, c("demo_job_level", "demo_region_code", "demo_attrition"), 100)
out$sample
out$proportionality_check

# build tables ~~~~~~~~~~~~~~~~~~~~~~
scottyhines::build_means_table(df, group_var = "demo_region_code", vars = outcomes, include_sd = T)
scottyhines::build_frequency_table(df, group_var = "demo_performance", vars = "demo_region_code", include_percentage = T)
scottyhines::build_correlation_table(data = df, outcome_vars = outcomes, interest_vars = vars_of_interest)

# data viz ~~~~~~~~~~~~~~~~~~~~~~~~~~
scottyhines::dataviz_scatter_item_function(df, grouping_var = "demo_region_code", item_score_var = "attitude_persistence")
scottyhines::calculate_basis_points(start = 4.76, end = 4.54)

# run statistical analyses ~~~~~~~~~~
scottyhines::run_ttest(df, outcome_vars = outcomes, group_var = "demo_attrition", paired = F)
scottyhines::run_one_sample_ttest_with_overall_mean(df, item_col = "demo_attrition", response_col = "attitude_persistence")
out_anova <- scottyhines::run_anova_with_contrasts(df, group_var = "demo_region_code", outcome_vars = outcomes, control_variables = NULL)
out_anova$anova
out_anova$contrasts
out_anova$group_means
scottyhines::run_linear_regression(df, outcome_var = outcomes, control_vars = "attitude_leadership", interest_vars = vars_of_interest)
scottyhines::run_logistic_regression(df, outcome_var = "demo_attrition", control_vars = c("attitude_leadership", "attitude_innovation"), interest_vars = vars_of_interest)
scottyhines::run_hierarchical_regression(df, outcome_var = outcomes, control_vars = c("demo_tenure", "demo_region_code"), interest_vars = vars_of_interest, group_var = "demo_job_level")
scottyhines::run_regularized_regression(df, outcome_vars = outcomes, control_vars = NULL, interest_vars = vars_of_interest, alpha = 1)
scottyhines::run_network_analysis(df, outcome_var = "demo_performance", control_vars = "attitude_leadership", interest_vars = c("network_degree", "network_betweenness", "network_closeness", "network_eigenvector"), group_var = "demo_job_level", num_permutations = 500)
scottyhines::run_heartbeat(df, outcomes)
scottyhines::run_causal_attitude_network(df, gamma = .5, threshold = F)
scottyhines::run_mixed_effects_model(df, outcome_vars = c("attitude_work_ethic", "attitude_adaptability"), control_vars = c("attitude_teamwork"), interest_vars = c("attitude_communication"), random_effects = "+ attitude_leadership * demo_job_level + (1 | demo_job_level)")
scottyhines::run_psychometrics(df, items = c(outcomes, vars_of_interest), factors = 2)

out <- scottyhines::lda_analysis(df, predictor_vars = vars_of_interest, metric = "demo_region_code")
out$plot
out$accuracy
out$group_means

out <- scottyhines::xgboost_analysis_with_holdout(df, predictor_vars = vars_of_interest, metric = "demo_region_code")
out$fit
out$prediction_plot

statements <- c(
  "In today's rapidly evolving business landscape, it is crucial to",
  "The implementation of cutting-edge technologies has revolutionized the way we",
  "Effective communication and collaboration are essential components for success in",
  "As organizations strive for innovation and growth, they must consider",
  "The integration of artificial intelligence and machine learning has significantly impacted",
  "optimize processes and streamline operations for maximum efficiency and productivity.",
  "adapt to changing market conditions and meet customer expectations effectively.",
  "foster a culture of continuous improvement and knowledge sharing across teams.",
  "the long-term implications of their strategic decisions on various stakeholders.",
  "various industries, from healthcare and finance to manufacturing and retail.",
  "The Quantum Computing Revolution is poised to transform cryptography and complex problem-solving in ways we can barely imagine today.",
  "Biometric authentication using DNA sequencing could become the next frontier in personal security and access control systems.",
  "Neuroplasticity-based learning algorithms may soon enable machines to adapt and learn like human brains, revolutionizing artificial intelligence.",
  "The integration of nanotechnology in medicine is opening up possibilities for targeted drug delivery and microscopic surgical procedures.",
  "Vertical farming coupled with AI-driven climate control could be the solution to sustainable urban food production in the future.",
  "The exploration of Mars continues to captivate scientists and the public alike, with new discoveries shaping our understanding of the Red Planet.",
  "Advancements in propulsion technology are bringing us closer to achieving interstellar travel and exploring distant star systems.",
  "The development of space-based solar power could revolutionize our approach to sustainable energy production on Earth.",
  "Asteroid mining has the potential to provide vast resources and reshape the global economy in unprecedented ways.",
  "The search for extraterrestrial intelligence (SETI) is entering a new era with more sophisticated detection methods and expanded search parameters.",
  "Space tourism is on the brink of becoming a reality, with private companies racing to offer commercial flights to low Earth orbit.",
  "The establishment of lunar bases could serve as a stepping stone for deep space exploration and resource utilization.",
  "Satellite constellations are transforming global communication networks and internet accessibility in remote areas of the world.",
  "The study of exoplanets is yielding new insights into the potential for life beyond our solar system.",
  "Space debris management is becoming increasingly crucial as we continue to launch more satellites and spacecraft into Earth's orbit.",
  "The rise of remote work has transformed traditional office dynamics and necessitated new approaches to team management and collaboration.",
  "Ergonomic office design is gaining importance as companies prioritize employee well-being and productivity in the workplace.",
  "Digital project management tools are streamlining workflows and enhancing team coordination in modern office environments.",
  "The concept of hot-desking is challenging traditional notions of personal workspace and promoting more flexible office arrangements.",
  "Workplace diversity and inclusion initiatives are becoming integral to corporate culture and talent acquisition strategies.",
  "The implementation of artificial intelligence in office automation is revolutionizing administrative tasks and data processing.",
  "Corporate sustainability practices are expanding beyond recycling to include energy-efficient technologies and green building design.",
  "The integration of virtual and augmented reality in office settings is opening new possibilities for training and collaborative work.",
  "Mindfulness and wellness programs are being incorporated into office cultures to combat stress and improve employee mental health.",
  "The evolution of office communication platforms is facilitating seamless interaction between in-office and remote team members.")

# Create the dataframe
df <- data.frame(
  id = 1:length(statements),
  text = statements,
  stringsAsFactors = FALSE
)
print(df)
# Print the dataframe
x <- scottyhines::run_cosine_similarity_with_attrs(df, text_col = "text", node_id_col = "id")
x$dissimilarity_ranking



hineycombs::run_lmx_metrics()




