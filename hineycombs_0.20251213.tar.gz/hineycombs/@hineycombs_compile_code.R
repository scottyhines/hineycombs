setwd("/Users/hinessco/@amazon/@_RandD/@syntax_library/hineycombs")
library(roxygen2)
devtools::document()
devtools::check()
# build ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
devtools::build()
# install package ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
install.packages("/Users/hinessco/@amazon/@_RandD/@syntax_library/hineycombs_0.20250228.tar.gz", repos = NULL, type = "source")

# test functions ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
library(hineycombs)
library(scottyhines)
# create network ~~~~~~~~~~~~~
g <- hineycombs::create_network(n = 300, p = .1, directed = T)
igraph::vertex_attr_names(g)
#igraph::vertex.attributes(g)
#plot(g)
# baic plot ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
hineycombs::plot_network(g, group_var = "region", show_labels = T)
hineycombs::plot_network(g, group_var = "performance")
hineycombs::plot_network(g, group_var = "job_level")
# network-wide metrics ~~~~~~~~~~~~~~~
out_network_wide <- hineycombs::calculate_network_metrics(g)
out_network_wide <- hineycombs::calculate_network_metrics(g, c("performance", "region"))
out_network_wide
# calcuatte metrics ~~~~~~~~~~~~~~~~~~~
g <- hineycombs::calculate_centrality_metrics(g, include_advanced_metrics = F)
igraph::vertex_attr_names(g)
igraph::vertex.attributes(g)
# Mixing Matrix ~~~~~~~~~~~~~~~~~~~~~~~~
out_1_mix <- hineycombs::run_mixing_matrix(g, 10, attribute_name = "job_level", type = "connections", percentage = T, exclude_diagonal = T)
# Run Neighbors ~~~~~~~~~~~~~~~~~~~~~~~~
hineycombs::run_neighbors(g, attribute_name = "group", group_value = "A", attribute_to_analyze = "region")
# plot reach ~~~~~~~~~~~~~~~~~~~~~~~~~~~
plot_reach(g, attribute_name = "group", group_value = "A", highlight_connections = F)
# block Modeling ~~~~~~~~~~~~~~~~~~~~~~
hineycombs::run_block_modeling(g, k = 6)
# cliques and Kcore ~~~~~~~~~~~~~~~~~~~~~~
hineycombs::run_clique_core(g, method = "cliques")
hineycombs::run_clique_core(g, method = "kcore")
hineycombs::plot_communities(g, algorithms = "walktrap")
# cross group interactions ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
temp_groups = c("M", "F")
out_group <- hineycombs::measure_group_interconnections(g, group_var = "gender", selected_groups = temp_groups, n_permutations = 500)
out_group$Metrics
temp_groups = c("Lead", "Manager")
out_group <- hineycombs::measure_group_interconnections(g, group_var = "job_level", selected_groups = temp_groups, n_permutations = 500)
out_group$Metrics
# plot group interactions ~~~~~~~~~~~~~
temp_groups = c("Lead", "Manager")
p <- hineycombs::plot_group_interconnections(g, group_var = "job_level", selected_groups = temp_groups)
# pull data ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Get edges
edges_df <- hineycombs::pull_data(g, "edges")
# Get nodes
nodes_df <- hineycombs::pull_data(g, "nodes")

# ossilation ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
g1 <- hineycombs::create_network(n = 300, p = .1, directed = T, seed = 123)
g2 <- hineycombs::create_network(n = 300, p = .1, directed = T, seed = 124)
g3 <- hineycombs::create_network(n = 300, p = .1, directed = T, seed = 125)
g1 <- hineycombs::calculate_centrality_metrics(g1, include_advanced_metrics = F)
g2 <- hineycombs::calculate_centrality_metrics(g2, include_advanced_metrics = F)
g3 <- hineycombs::calculate_centrality_metrics(g3, include_advanced_metrics = F)
node1 <- hineycombs::pull_data(g1, "nodes") %>% dplyr::mutate(time = "timee1")
node2 <- hineycombs::pull_data(g2, "nodes") %>% dplyr::mutate(time = "timee2")
node3 <- hineycombs::pull_data(g3, "nodes") %>% dplyr::mutate(time = "timee3")
wd <- dplyr::bind_rows(node1, node2, node3)
out_ossilation <- hineycombs::calculate_oscillation_metrics(wd, variables = "pagerank", id_col = "name")
out_ossilation$individual_scores

