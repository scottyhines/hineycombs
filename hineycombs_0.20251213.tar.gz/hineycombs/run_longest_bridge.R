#' Identify Important Inter-Community Edges in a Network
#'
#' Finds edges that span across different communities within a network, based on a specified community detection algorithm.
#' These inter-community edges are optionally ranked by either the distance between nodes if the edge were removed,
#' or by edge betweenness centrality. These are useful for identifying bridges that tie clusters together.
#'
#' @param g An `igraph` object representing the network.
#' @param method Character string. The community detection method to use. Options are `"louvain"` (default) or `"walktrap"`.
#' @param sort_by Character string. How to rank inter-community edges. Options are:
#'   - `"distance"`: Computes how far apart the nodes would be if the edge were removed (default).
#'   - `"betweenness"`: Ranks by edge betweenness centrality.
#'
#' @return A data frame of inter-community edges with ranking information.
#'
#' @importFrom igraph cluster_louvain cluster_walktrap membership as_data_frame distances edge_betweenness
#' @export
find_key_intercommunity_edges <- function(g, method = "louvain", sort_by = "distance") {
  if (method == "louvain") {
    com <- igraph::cluster_louvain(g)
  } else {
    com <- igraph::cluster_walktrap(g)
  }
  
  membership <- igraph::membership(com)
  edges <- igraph::as_data_frame(g, what = "edges")
  edges$from_comm <- membership[edges$from]
  edges$to_comm <- membership[edges$to]
  
  # Filter for inter-community edges
  inter_edges <- subset(edges, from_comm != to_comm)
  
  if (sort_by == "distance") {
    inter_edges$dist <- apply(inter_edges, 1, function(row) {
      # Temporarily remove the edge and calculate new distance
      g_tmp <- igraph::delete_edges(g, igraph::E(g, P = c(row["from"], row["to"])))
      dist_val <- igraph::distances(g_tmp, v = row["from"], to = row["to"])
      return(dist_val[1, 1])
    })
    
    inter_edges <- inter_edges[order(-inter_edges$dist), ]
    
  } else if (sort_by == "betweenness") {
    eb <- igraph::edge_betweenness(g)
    edge_df <- igraph::as_data_frame(g, what = "edges")
    edge_df$betweenness <- eb
    inter_edges <- merge(inter_edges, edge_df, by = c("from", "to"))
    inter_edges <- inter_edges[order(-inter_edges$betweenness), ]
  }
  
  return(inter_edges)
}
