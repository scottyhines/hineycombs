# Script to knit the hineycombs function reference to HTML
# Run this in RStudio or R console

# Install rmarkdown if needed
if (!require("rmarkdown")) {
  install.packages("rmarkdown")
}

# Knit the document
rmarkdown::render(
  "hineycombs_function_reference.Rmd",
  output_format = "html_document",
  output_file = "hineycombs_function_reference.html"
)

cat("HTML file created: hineycombs_function_reference.html\n")
