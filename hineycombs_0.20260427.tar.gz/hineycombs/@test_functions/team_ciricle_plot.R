
# ─────────────────────────────────────────────────────────────────────────────
# plot_team_network_circle()
#
# Directed circular network plot where:
#   - Nodes are sized by degree (in + out)
#   - Leader node is highlighted at 12 o'clock
#   - Directed edges with arrowheads
#   - Bidirectional pairs shown as two separate arrows (both directions)
#   - Weak edges filtered before plotting
#   - Straight lines
#
# Required packages: igraph
# ─────────────────────────────────────────────────────────────────────────────

plot_team_network_circle <- function(
    edge_df,                    # data.frame: from, to, weight
    leader         = NULL,      # character: name of leader node
    node_df        = NULL,      # optional data.frame with column 'name'
    title          = "Team Interaction Network",
    leader_color   = "#E63946", # leader node fill color
    member_color   = "#457B9D", # member node fill color
    edge_color     = "#888888", # edge line color
    bg_color       = "white",
    min_node_size  = 15,        # smallest node (lowest degree)
    max_node_size  = 50,        # largest node (highest degree)
    min_edge_width = 0.5,       # thinnest edge line
    max_edge_width = 5,         # thickest edge line
    weak_edge_pct  = 0.25,      # remove bottom X% of edges by weight (0 = keep all)
    arrow_size     = 0.4,       # arrowhead size
    arrow_width    = 1.5,       # arrowhead width
    show_edge_labels = FALSE,   # show weight values on edges
    seed           = 123456
) {
  library(igraph)
  set.seed(seed)
  
  # ── Filter weak edges ────────────────────────────────────────────────────────
  if (weak_edge_pct > 0 && nrow(edge_df) > 1) {
    threshold <- quantile(edge_df$weight, probs = weak_edge_pct, na.rm = TRUE)
    edge_df   <- edge_df[edge_df$weight >= threshold, ]
  }
  
  # ── Build DIRECTED graph ─────────────────────────────────────────────────────
  g <- graph_from_data_frame(edge_df, directed = TRUE, vertices = node_df)
  
  # ── Circular layout with leader at top ───────────────────────────────────────
  node_names <- V(g)$name
  n          <- length(node_names)
  angles     <- seq(0, 2 * pi, length.out = n + 1)[-(n + 1)]
  
  if (!is.null(leader) && leader %in% node_names) {
    leader_idx <- which(node_names == leader)
    offset     <- pi / 2 - angles[leader_idx]
    angles     <- angles + offset
  }
  
  layout_mat <- cbind(cos(angles), sin(angles))
  
  # ── Node size by total degree (in + out) ─────────────────────────────────────
  deg <- degree(g, mode = "total")
  if (length(unique(deg)) > 1) {
    node_sizes <- min_node_size +
      (deg - min(deg)) / (max(deg) - min(deg)) * (max_node_size - min_node_size)
  } else {
    node_sizes <- rep((min_node_size + max_node_size) / 2, n)
  }
  
  # Leader gets at least max size
  if (!is.null(leader) && leader %in% node_names) {
    node_sizes[node_names == leader] <- max(node_sizes[node_names == leader],
                                            max_node_size)
  }
  
  # ── Node colors ───────────────────────────────────────────────────────────────
  node_colors <- ifelse(node_names == leader, leader_color, member_color)
  
  # ── Edge width scaling ────────────────────────────────────────────────────────
  weights <- E(g)$weight
  if (length(weights) > 1 && length(unique(weights)) > 1) {
    scaled_widths <- min_edge_width +
      (weights - min(weights)) / (max(weights) - min(weights)) *
      (max_edge_width - min_edge_width)
  } else {
    scaled_widths <- rep((min_edge_width + max_edge_width) / 2, length(weights))
  }
  
  # ── Detect bidirectional pairs and apply slight curve to separate arrows ──────
  # For each edge A→B, check if B→A also exists; if so, curve both slightly
  # so the two arrows don't overlap and both arrowheads are visible
  el          <- as_edgelist(g)
  edge_curves <- numeric(nrow(el))
  
  for (i in seq_len(nrow(el))) {
    a <- el[i, 1]
    b <- el[i, 2]
    # Check if reverse edge exists
    reverse_exists <- any(el[, 1] == b & el[, 2] == a)
    if (reverse_exists) {
      edge_curves[i] <- 0.25   # slight curve to separate bidirectional arrows
    } else {
      edge_curves[i] <- 0      # straight for one-way edges
    }
  }
  
  # ── Plot ──────────────────────────────────────────────────────────────────────
  par(bg = bg_color, mar = c(2, 2, 3, 2))
  
  plot(
    g,
    layout             = layout_mat,
    vertex.color       = node_colors,
    vertex.size        = node_sizes,
    vertex.label       = node_names,
    vertex.label.color = "white",
    vertex.label.cex   = 0.7,
    vertex.label.font  = 2,
    vertex.frame.color = NA,
    edge.width         = scaled_widths,
    edge.color         = edge_color,
    edge.arrow.size    = arrow_size,
    edge.arrow.width   = arrow_width,
    edge.curved        = edge_curves,   # straight for one-way, slight curve for bidirectional
    edge.label         = if (show_edge_labels) round(weights, 1) else NA,
    edge.label.cex     = 0.55,
    edge.label.color   = "#555555",
    main               = title
  )
  
  # ── Legend ────────────────────────────────────────────────────────────────────
  if (!is.null(leader)) {
    legend(
      "bottomright",
      legend   = c(paste0(leader, " (Leader)"), "Team Member"),
      pch      = 21,
      pt.bg    = c(leader_color, member_color),
      col      = "white",
      pt.cex   = 1.8,
      bty      = "n",
      text.col = "black",
      cex      = 0.8
    )
  }
  
  invisible(g)
}


# ─────────────────────────────────────────────────────────────────────────────
# EXAMPLE USAGE — directed edge list (A→B and B→A are separate rows)
# ─────────────────────────────────────────────────────────────────────────────

edges <- data.frame(
  from   = c("Alice", "Bob",   "Alice", "Carol", "Bob",   "Dave",  "Eve",   "Carol", "Bob"),
  to     = c("Bob",   "Alice", "Carol", "Alice", "Carol", "Alice", "Alice", "Dave",  "Eve"),
  weight = c(10,      8,       5,       4,       12,      7,       3,       6,       9)
)

# Alice ↔ Bob (bidirectional), Alice ↔ Carol (bidirectional), others one-way
plot_team_network_circle(
  edge_df       = edges,
  leader        = "Alice",
  title         = "Alice's Team Interaction Network",
  weak_edge_pct = 0.20
)

