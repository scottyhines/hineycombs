#' Assess Organizational Change Readiness from Network Structure
#'
#' @description
#' Analyzes a network to produce actionable intelligence for organizational change
#' initiatives. The function identifies optimal change agents, resistance-prone
#' clusters, diffusion bottlenecks, and simulates adoption under different seeding
#' strategies.
#'
#' Change does not spread through org charts — it spreads through networks. This
#' function answers: where should you seed a change initiative, who are the risks,
#' and what structural barriers exist?
#'
#' Theoretically grounded in Valente's network thresholds and critical mass theory,
#' Burt's structural holes and brokerage, and Rogers' diffusion of innovations.
#' Change agents are selected not just for reach (degree) but for credibility
#' (local embeddedness via transitivity) combined with cross-group bridging
#' (betweenness), reflecting research showing that trusted brokers are the most
#' effective seeds for behavioral change.
#'
#' @param g An \code{igraph} graph object. If centrality metrics (degree, betweenness,
#'   transitivity, etc.) are already computed as vertex attributes (e.g., via
#'   \code{calculate_centrality_metrics}), they will be reused. Otherwise, they are
#'   computed on the fly.
#' @param group_attr Character. Name of the vertex attribute defining organizational
#'   groups (e.g., \code{"department"}, \code{"team"}, \code{"region"}). Used for
#'   community-aware analysis. If \code{NULL}, algorithmic community detection is used.
#' @param community_method Character. Community detection algorithm when
#'   \code{group_attr} is \code{NULL}. One of \code{"louvain"} (default) or
#'   \code{"walktrap"}.
#' @param n_change_agents Integer. Number of recommended change agents to return.
#'   Default is 10.
#' @param resistance_threshold Numeric. Ratio of internal to total ties above which
#'   a community is flagged as resistance-prone. Default is 0.80 (80\% of ties are
#'   internal).
#' @param run_simulation Logical. If \code{TRUE}, runs adoption diffusion simulations
#'   comparing seeding strategies. Default is \code{TRUE}.
#' @param sim_steps Integer. Number of time steps for diffusion simulation. Default 20.
#' @param sim_p Numeric. Per-neighbor adoption probability per step. Default 0.15.
#' @param sim_seeds Integer. Number of seed nodes per strategy in simulation. Default 5.
#' @param sim_seed Integer. Random seed for reproducibility of the random seeding
#'   strategy. Default 42. Set to \code{NULL} to use the current RNG state.
#' @param verbose Logical. Print progress messages. Default \code{TRUE}.
#'
#' @return A list with the following components:
#' \describe{
#'   \item{change_agents}{Data frame of top change agent candidates ranked by a
#'     composite score combining cross-group reach, local trust, and visibility.
#'     Columns: \code{name}, \code{group}, \code{degree}, \code{betweenness},
#'     \code{transitivity}, \code{communities_reached}, \code{cross_group_ties},
#'     \code{change_agent_score}, \code{reason}.}
#'   \item{resistance_pockets}{Data frame of communities at risk of resisting change
#'     due to high insularity. Columns: \code{community}, \code{size},
#'     \code{internal_tie_ratio}, \code{external_ties}, \code{bridge_count},
#'     \code{risk_level}, \code{recommendation}.}
#'   \item{bottlenecks}{Data frame of nodes whose non-adoption would block diffusion
#'     to downstream subgroups. Columns: \code{name}, \code{group},
#'     \code{betweenness}, \code{communities_bridged}, \code{downstream_reach},
#'     \code{is_articulation_point}, \code{risk_description}.}
#'   \item{diffusion_forecast}{List of simulation results (if \code{run_simulation = TRUE}).
#'     Contains a data frame \code{curves} with adoption trajectories per strategy,
#'     and a summary \code{comparison} of time-to-50\% and time-to-80\% adoption.
#'     \code{NULL} if simulation is skipped.}
#'   \item{summary}{Character vector with a plain-English executive summary of findings.}
#' }
#'
#' @details
#' \strong{Change Agent Scoring:}
#' The composite score weights betweenness (cross-group reach, 30\%), local
#' transitivity (trust/credibility, 25\%), number of distinct communities reached
#' within 2 hops (diffusion breadth, 25\%), and degree (visibility, 20\%). Nodes
#' that are both locally embedded and externally connected score highest.
#'
#' \strong{Resistance Pocket Detection:}
#' Communities are flagged when their internal tie ratio exceeds
#' \code{resistance_threshold} AND they have fewer than 2 bridge nodes connecting
#' them to the rest of the network. These are structurally isolated clusters where
#' change is unlikely to penetrate organically.
#'
#' \strong{Diffusion Simulation:}
#' Compares four seeding strategies: (1) recommended change agents, (2) highest
#' degree nodes, (3) highest betweenness nodes, and (4) random selection. Each
#' strategy seeds the same number of nodes and runs a stochastic threshold model.
#'
#' @examples
#' \dontrun{
#' library(igraph)
#' library(hineycombs)
#'
#' g <- create_network(n = 200, p = 0.08, directed = FALSE)
#' g <- calculate_centrality_metrics(g)
#'
#' out <- run_insights_change_readiness(g, group_attr = "team")
#'
#' # View top change agents
#' head(out$change_agents)
#'
#' # Check resistance pockets
#' out$resistance_pockets
#'
#' # View diffusion comparison
#' out$diffusion_forecast$comparison
#'
#' # Executive summary
#' cat(out$summary, sep = "\n")
#' }
#'
#' @importFrom igraph vcount ecount vertex_attr vertex_attr_names edge_attr_names
#' @importFrom igraph V E degree betweenness transitivity neighbors ego_size
#' @importFrom igraph cluster_louvain cluster_walktrap membership as_undirected
#' @importFrom igraph is_directed articulation_points induced_subgraph edge_density
#' @importFrom igraph as_edgelist components neighborhood
#' @importFrom stats median sd setNames quantile runif
#'
#' @export
special_run_identify_change_readiness <- function(
    g,
    group_attr = NULL,
    community_method = c("louvain", "walktrap"),
    n_change_agents = 10,
    resistance_threshold = 0.80,
    run_simulation = TRUE,
    sim_steps = 20,
    sim_p = 0.15,
    sim_seeds = 5,
    sim_seed = 42,
    verbose = TRUE
) {

  if (!inherits(g, "igraph")) stop("g must be an igraph object.")
  community_method <- match.arg(community_method)

  n <- igraph::vcount(g)
  if (n == 0) stop("Graph has no vertices.")

  v_names <- igraph::V(g)$name
  if (is.null(v_names)) v_names <- as.character(seq_len(n))

  # --- Helper: safe z-score ---
  zscore <- function(x) {
    s <- stats::sd(x, na.rm = TRUE)
    if (is.na(s) || s == 0) return(rep(0, length(x)))
    (x - mean(x, na.rm = TRUE)) / s
  }

  # ================================================================
  # 1. Extract or compute centrality metrics
  # ================================================================
  if (verbose) cat("Preparing centrality metrics...\n")

  has_attr <- function(a) a %in% igraph::vertex_attr_names(g)

  v_degree <- if (has_attr("degree")) {
    igraph::vertex_attr(g, "degree")
  } else {
    igraph::degree(g, mode = "total")
  }

  v_betweenness <- if (has_attr("betweenness")) {
    igraph::vertex_attr(g, "betweenness")
  } else {
    igraph::betweenness(g, directed = igraph::is_directed(g))
  }

  v_transitivity <- if (has_attr("transitivity")) {
    igraph::vertex_attr(g, "transitivity")
  } else {
    igraph::transitivity(g, type = "local")
  }
  # Replace NaN with 0 for isolates
  v_transitivity[is.na(v_transitivity)] <- 0

  # ================================================================
  # 2. Determine community membership
  # ================================================================
  if (verbose) cat("Determining community structure...\n")

  if (!is.null(group_attr)) {
    if (!has_attr(group_attr)) stop("group_attr '", group_attr, "' not found on vertices.")
    comm_membership <- as.character(igraph::vertex_attr(g, group_attr))
  } else {
    g_und <- if (igraph::is_directed(g)) igraph::as_undirected(g, mode = "collapse") else g
    comm_obj <- if (community_method == "louvain") {
      igraph::cluster_louvain(g_und)
    } else {
      igraph::cluster_walktrap(g_und)
    }
    comm_membership <- as.character(igraph::membership(comm_obj))
  }

  comm_labels <- unique(comm_membership)
  n_communities <- length(comm_labels)
  if (verbose) cat("  Found", n_communities, "communities\n")

  # ================================================================
  # 3. Compute cross-group reach (distinct communities within 2 hops)
  # ================================================================
  if (verbose) cat("Computing cross-group reach...\n")

  communities_reached_2hop <- vapply(seq_len(n), function(v) {
    ego_nodes <- unlist(igraph::neighborhood(g, order = 2, nodes = v, mode = "all"))
    ego_nodes <- setdiff(ego_nodes, v)
    if (length(ego_nodes) == 0) return(0L)
    length(unique(comm_membership[ego_nodes]))
  }, integer(1))

  # Count direct cross-group ties
  cross_group_ties <- vapply(seq_len(n), function(v) {
    nbrs <- as.integer(igraph::neighbors(g, v, mode = "all"))
    if (length(nbrs) == 0) return(0L)
    sum(comm_membership[nbrs] != comm_membership[v])
  }, integer(1))

  # ================================================================
  # 4. Score and rank change agents
  # ================================================================
  if (verbose) cat("Scoring change agent candidates...\n")

  z_btw <- zscore(v_betweenness)
  z_trans <- zscore(v_transitivity)
  z_comm_reach <- zscore(as.numeric(communities_reached_2hop))
  z_deg <- zscore(v_degree)

  # Composite: betweenness 30%, transitivity 25%, community reach 25%, degree 20%
  change_agent_score <- (0.30 * z_btw) + (0.25 * z_trans) +
    (0.25 * z_comm_reach) + (0.20 * z_deg)

  # Build reason strings
  med_btw <- stats::median(v_betweenness, na.rm = TRUE)
  med_trans <- stats::median(v_transitivity, na.rm = TRUE)
  med_deg <- stats::median(v_degree, na.rm = TRUE)

  agent_reasons <- vapply(seq_len(n), function(v) {
    parts <- c()
    if (v_betweenness[v] > med_btw) parts <- c(parts, "strong cross-group broker")
    if (v_transitivity[v] > med_trans) parts <- c(parts, "locally trusted (high clustering)")
    if (communities_reached_2hop[v] >= max(2, n_communities * 0.5)) {
      parts <- c(parts, paste0("reaches ", communities_reached_2hop[v], " communities within 2 hops"))
    }
    if (v_degree[v] > med_deg) parts <- c(parts, "high visibility (well-connected)")
    if (length(parts) == 0) parts <- "moderate overall profile"
    paste(parts, collapse = "; ")
  }, character(1))

  agent_df <- data.frame(
    name = v_names,
    group = comm_membership,
    degree = v_degree,
    betweenness = round(v_betweenness, 2),
    transitivity = round(v_transitivity, 3),
    communities_reached = communities_reached_2hop,
    cross_group_ties = cross_group_ties,
    change_agent_score = round(change_agent_score, 3),
    reason = agent_reasons,
    stringsAsFactors = FALSE
  )

  agent_df <- agent_df[order(-agent_df$change_agent_score), ]
  rownames(agent_df) <- NULL
  top_agents <- utils::head(agent_df, n_change_agents)

  # ================================================================
  # 5. Detect resistance pockets
  # ================================================================
  if (verbose) cat("Detecting resistance-prone communities...\n")

  edgelist <- igraph::as_edgelist(g, names = FALSE)

  resistance_rows <- lapply(comm_labels, function(cl) {
    members <- which(comm_membership == cl)
    if (length(members) < 2) return(NULL)

    # Count internal vs external edges
    member_set <- members
    internal <- sum(
      (edgelist[, 1] %in% member_set) & (edgelist[, 2] %in% member_set)
    )
    total_incident <- sum(
      (edgelist[, 1] %in% member_set) | (edgelist[, 2] %in% member_set)
    )
    external <- total_incident - internal

    internal_ratio <- if (total_incident > 0) internal / total_incident else 0

    # Count bridge nodes: members with at least one cross-group tie
    bridge_count <- sum(cross_group_ties[members] > 0)

    # Risk assessment
    risk <- if (internal_ratio >= resistance_threshold && bridge_count <= 1) {
      "High"
    } else if (internal_ratio >= resistance_threshold && bridge_count <= 3) {
      "Medium"
    } else {
      "Low"
    }

    recommendation <- if (risk == "High") {
      "Critical: seed at least one change agent inside this group or create new cross-group ties"
    } else if (risk == "Medium") {
      "Monitor: limited external connectivity — ensure bridge nodes are engaged early"
    } else {
      "Low risk: adequate external connectivity for organic diffusion"
    }

    data.frame(
      community = cl,
      size = length(members),
      internal_tie_ratio = round(internal_ratio, 3),
      external_ties = external,
      bridge_count = bridge_count,
      risk_level = risk,
      recommendation = recommendation,
      stringsAsFactors = FALSE
    )
  })

  resistance_df <- do.call(rbind, Filter(Negate(is.null), resistance_rows))
  if (!is.null(resistance_df)) {
    resistance_df <- resistance_df[order(
      factor(resistance_df$risk_level, levels = c("High", "Medium", "Low")),
      -resistance_df$internal_tie_ratio
    ), ]
    rownames(resistance_df) <- NULL
  } else {
    resistance_df <- data.frame(
      community = character(0), size = integer(0),
      internal_tie_ratio = numeric(0), external_ties = integer(0),
      bridge_count = integer(0), risk_level = character(0),
      recommendation = character(0), stringsAsFactors = FALSE
    )
  }

  # ================================================================
  # 6. Identify diffusion bottlenecks
  # ================================================================
  if (verbose) cat("Identifying diffusion bottlenecks...\n")

  art_points <- tryCatch(
    as.integer(igraph::articulation_points(g)),
    error = function(e) integer(0)
  )

  # Communities bridged by each node
  communities_bridged <- vapply(seq_len(n), function(v) {
    nbrs <- as.integer(igraph::neighbors(g, v, mode = "all"))
    if (length(nbrs) == 0) return(0L)
    nbr_comms <- unique(comm_membership[nbrs])
    # Count communities OTHER than the node's own
    sum(nbr_comms != comm_membership[v])
  }, integer(1))

  # Downstream reach: how many nodes are reachable within 3 hops
  downstream_reach <- igraph::ego_size(g, order = 3, mode = "all") - 1L

  # Bottleneck criteria: high betweenness + bridges multiple communities
  btw_threshold <- stats::quantile(v_betweenness, 0.75, na.rm = TRUE)
  is_bottleneck <- (v_betweenness >= btw_threshold) & (communities_bridged >= 2)

  bottleneck_idx <- which(is_bottleneck)

  bottleneck_df <- data.frame(
    name = v_names[bottleneck_idx],
    group = comm_membership[bottleneck_idx],
    betweenness = round(v_betweenness[bottleneck_idx], 2),
    communities_bridged = communities_bridged[bottleneck_idx],
    downstream_reach = downstream_reach[bottleneck_idx],
    is_articulation_point = bottleneck_idx %in% art_points,
    stringsAsFactors = FALSE
  )

  bottleneck_df$risk_description <- vapply(seq_len(nrow(bottleneck_df)), function(i) {
    parts <- c()
    if (bottleneck_df$is_articulation_point[i]) {
      parts <- c(parts, "articulation point — removal disconnects the network")
    }
    parts <- c(parts, paste0("bridges ", bottleneck_df$communities_bridged[i], " external communities"))
    parts <- c(parts, paste0("reaches ", bottleneck_df$downstream_reach[i], " nodes within 3 hops"))
    paste(parts, collapse = "; ")
  }, character(1))

  bottleneck_df <- bottleneck_df[order(-bottleneck_df$betweenness), ]
  rownames(bottleneck_df) <- NULL

  # ================================================================
  # 7. Diffusion simulation (optional)
  # ================================================================
  diffusion_forecast <- NULL

  if (run_simulation) {
    if (verbose) cat("Running diffusion simulations...\n")

    actual_seeds <- min(sim_seeds, n - 1)

    # Define seeding strategies
    idx_recommended <- utils::head(order(-change_agent_score), actual_seeds)
    idx_degree <- utils::head(order(-v_degree), actual_seeds)
    idx_betweenness <- utils::head(order(-v_betweenness), actual_seeds)
    if (!is.null(sim_seed)) set.seed(sim_seed)
    idx_random <- sample(seq_len(n), actual_seeds)

    strategies <- list(
      recommended = idx_recommended,
      high_degree = idx_degree,
      high_betweenness = idx_betweenness,
      random = idx_random
    )

    # Simple threshold diffusion model
    run_diffusion <- function(seed_nodes) {
      adopted <- rep(FALSE, n)
      adopted[seed_nodes] <- TRUE
      trajectory <- numeric(sim_steps + 1)
      trajectory[1] <- sum(adopted) / n * 100

      for (t in seq_len(sim_steps)) {
        current_adopters <- which(adopted)
        candidates <- unique(unlist(
          igraph::neighborhood(g, order = 1, nodes = current_adopters, mode = "all")
        ))
        candidates <- setdiff(candidates, current_adopters)

        if (length(candidates) > 0) {
          adopt_prob <- stats::runif(length(candidates)) < sim_p
          adopted[candidates[adopt_prob]] <- TRUE
        }

        trajectory[t + 1] <- sum(adopted) / n * 100
      }

      trajectory
    }

    # Run each strategy
    sim_results <- lapply(strategies, function(seeds) {
      run_diffusion(seeds)
    })

    # Build curves dataframe
    curves <- data.frame(step = 0:sim_steps)
    for (nm in names(sim_results)) {
      curves[[nm]] <- round(sim_results[[nm]], 2)
    }

    # Time-to-milestone comparison
    milestones <- c(50, 80)
    comparison_rows <- lapply(names(sim_results), function(strat) {
      traj <- sim_results[[strat]]
      t50 <- which(traj >= 50)[1]
      t80 <- which(traj >= 80)[1]
      data.frame(
        strategy = strat,
        final_adoption_pct = round(utils::tail(traj, 1), 1),
        steps_to_50pct = if (!is.na(t50)) t50 - 1L else NA_integer_,
        steps_to_80pct = if (!is.na(t80)) t80 - 1L else NA_integer_,
        stringsAsFactors = FALSE
      )
    })
    comparison <- do.call(rbind, comparison_rows)
    rownames(comparison) <- NULL

    diffusion_forecast <- list(
      curves = curves,
      comparison = comparison
    )

    if (verbose) {
      cat("  Simulation complete. Strategy comparison:\n")
      print(comparison)
    }
  }

  # ================================================================
  # 8. Executive summary
  # ================================================================
  if (verbose) cat("Generating executive summary...\n")

  n_high_risk <- sum(resistance_df$risk_level == "High")
  n_med_risk <- sum(resistance_df$risk_level == "Medium")
  n_bottlenecks <- nrow(bottleneck_df)
  n_art <- sum(bottleneck_df$is_articulation_point)

  summary_lines <- c(
    "=== Change Readiness Assessment ===",
    "",
    paste0("Network: ", n, " nodes, ", igraph::ecount(g), " edges, ", n_communities, " communities"),
    ""
  )

  # Change agents
  if (nrow(top_agents) > 0) {
    top3 <- utils::head(top_agents$name, 3)
    summary_lines <- c(summary_lines,
      paste0("CHANGE AGENTS: Top recommended seeds are ", paste(top3, collapse = ", "), "."),
      paste0("  These individuals combine cross-group bridging with local trust — ",
             "they are credible messengers who can reach multiple communities.")
    )
  }

  # Resistance
  if (n_high_risk > 0) {
    high_comms <- resistance_df$community[resistance_df$risk_level == "High"]
    summary_lines <- c(summary_lines, "",
      paste0("RESISTANCE RISK: ", n_high_risk, " community(ies) flagged as high-risk ",
             "(", paste(high_comms, collapse = ", "), ")."),
      "  These groups have >80% internal ties and very few bridge connections.",
      "  Change is unlikely to reach them organically — direct seeding is recommended."
    )
  } else if (n_med_risk > 0) {
    summary_lines <- c(summary_lines, "",
      paste0("RESISTANCE RISK: No high-risk pockets, but ", n_med_risk,
             " community(ies) have limited external connectivity. Monitor closely.")
    )
  } else {
    summary_lines <- c(summary_lines, "",
      "RESISTANCE RISK: No structurally isolated communities detected. Good connectivity."
    )
  }

  # Bottlenecks
  if (n_bottlenecks > 0) {
    summary_lines <- c(summary_lines, "",
      paste0("BOTTLENECKS: ", n_bottlenecks, " node(s) identified as diffusion chokepoints."),
      if (n_art > 0) paste0("  ", n_art, " of these are articulation points — their disengagement ",
                            "could disconnect parts of the network.") else NULL,
      "  Prioritize early engagement with these individuals."
    )
  }

  # Simulation
  if (!is.null(diffusion_forecast)) {
    best <- comparison[which.min(comparison$steps_to_50pct), ]
    summary_lines <- c(summary_lines, "",
      paste0("DIFFUSION FORECAST: The '", best$strategy, "' seeding strategy reaches 50% adoption ",
             "fastest (step ", best$steps_to_50pct, ")."),
      paste0("  Final adoption rates range from ",
             min(comparison$final_adoption_pct), "% to ",
             max(comparison$final_adoption_pct), "% across strategies.")
    )
  }

  if (verbose) cat(paste(summary_lines, collapse = "\n"), "\n")

  # ================================================================
  # Return
  # ================================================================
  list(
    change_agents = top_agents,
    resistance_pockets = resistance_df,
    bottlenecks = bottleneck_df,
    diffusion_forecast = diffusion_forecast,
    summary = summary_lines
  )
}
