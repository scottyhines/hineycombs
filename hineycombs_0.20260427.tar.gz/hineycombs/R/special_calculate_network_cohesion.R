#' Calculate network cohesion and fragmentation metrics
#'
#' @description
#' Measures how connected and cohesive a network is. Cohesive networks have strong
#' internal connections and resist fragmentation. Fragmented networks have weak
#' connections and break into isolated groups easily.
#'
#' Practical uses:
#' \itemize{
#'   \item Assess team integration and collaboration
#'   \item Identify isolated groups or silos
#'   \item Measure organizational unity vs fragmentation
#'   \item Track cohesion changes over time
#'   \item Compare cohesion across departments
#' }
#'
#' @param g An igraph object. Must have a \code{name} vertex attribute.
#' @param weight_var Optional edge attribute name for weights.
#' @param team_attr Optional vertex attribute for team-level analysis.
#'
#' @return A list containing:
#' \describe{
#'   \item{cohesion_metrics}{Overall network cohesion scores}
#'   \item{fragmentation_metrics}{Fragmentation and isolation measures}
#'   \item{component_analysis}{Details about connected components}
#'   \item{cohesive_subgroups}{Identification of tightly-knit groups}
#'   \item{team_cohesion}{Team-level cohesion (if team_attr provided)}
#'   \item{interpretation}{Plain English interpretation}
#' }
#'
#' @details
#' Cohesion metrics:
#'
#' \strong{Density (0-1):} Proportion of possible connections that exist.
#' Higher = more connected.
#'
#' \strong{Compactness (0-1):} Average reachability between nodes.
#' 1 = everyone can reach everyone, 0 = completely fragmented.
#'
#' \strong{Fragmentation (0-1):} Proportion of node pairs that cannot reach each other.
#' 0 = fully connected, 1 = completely fragmented.
#'
#' \strong{Cohesion Index (0-1):} Composite measure combining density, compactness,
#' and clustering. Higher = more cohesive.
#'
#' \strong{Average Distance:} Average shortest path length. Lower = more cohesive.
#'
#' \strong{Clustering Coefficient (0-1):} Tendency to form triangles.
#' Higher = more cohesive local neighborhoods.
#'
#' Fragmentation indicators:
#' \itemize{
#'   \item Number of components (1 = connected, >1 = fragmented)
#'   \item Size of largest component
#'   \item Number of isolates (nodes with no connections)
#'   \item Bridges (edges whose removal disconnects the network)
#'   \item Cut vertices (nodes whose removal disconnects the network)
#' }
#'
#' @examples
#' \dontrun{
#' # Basic cohesion analysis
#' cohesion <- calculate_network_cohesion(g)
#' print(cohesion$interpretation)
#'
#' # Compare team cohesion
#' cohesion <- calculate_network_cohesion(
#'   g,
#'   team_attr = "department"
#' )
#' print(cohesion$team_cohesion)
#'
#' # Identify fragmented groups
#' print(cohesion$component_analysis)
#' }
#'
#' @importFrom igraph vcount ecount edge_density components distances
#' @importFrom igraph transitivity diameter articulation_points bridges
#' @importFrom igraph induced_subgraph V E degree
#' @importFrom dplyr group_by summarise arrange desc
#' @importFrom tibble tibble
#'
#' @export
special_calculate_network_cohesion <- function(g,
                                       weight_var = NULL,
                                       team_attr = NULL) {
  
  if (!inherits(g, "igraph")) {
    stop("`g` must be an igraph object.")
  }
  
  if (!"name" %in% igraph::vertex_attr_names(g)) {
    stop("Graph must have a 'name' vertex attribute.")
  }
  
  cat("Calculating network cohesion metrics...\n")
  
  n <- igraph::vcount(g)
  m <- igraph::ecount(g)
  node_names <- igraph::V(g)$name
  
  # Handle weights
  weights <- NULL
  if (!is.null(weight_var) && weight_var %in% igraph::edge_attr_names(g)) {
    weights <- igraph::E(g)[[weight_var]]
  }
  
  # === COHESION METRICS ===
  
  # 1. Density
  density <- igraph::edge_density(g)
  
  # 2. Compactness (average reachability)
  dists <- igraph::distances(g, weights = weights)
  reachable <- is.finite(dists)
  diag(reachable) <- FALSE
  compactness <- sum(reachable) / (n * (n - 1))
  
  # 3. Average distance (among reachable pairs)
  finite_dists <- dists[is.finite(dists) & dists > 0]
  avg_distance <- if (length(finite_dists) > 0) mean(finite_dists) else Inf
  
  # 4. Clustering coefficient
  clustering <- igraph::transitivity(g, type = "global")
  if (is.na(clustering)) clustering <- 0
  
  # 5. Diameter
  diameter <- tryCatch(
    igraph::diameter(g, weights = weights),
    error = function(e) Inf
  )
  
  # 6. Cohesion index (composite measure)
  cohesion_index <- (density + compactness + clustering) / 3
  
  cohesion_metrics <- list(
    density = density,
    compactness = compactness,
    fragmentation = 1 - compactness,
    avg_distance = avg_distance,
    diameter = diameter,
    clustering = clustering,
    cohesion_index = cohesion_index
  )
  
  # === FRAGMENTATION METRICS ===
  
  cat("Analyzing network fragmentation...\n")
  
  # Components
  comp <- igraph::components(g)
  
  # Isolates
  deg <- igraph::degree(g)
  n_isolates <- sum(deg == 0)
  
  # Bridges (edges whose removal disconnects network)
  bridges_list <- igraph::bridges(g)
  n_bridges <- length(bridges_list)
  
  # Articulation points (cut vertices)
  cut_vertices <- igraph::articulation_points(g)
  n_cut_vertices <- length(cut_vertices)
  
  fragmentation_metrics <- list(
    n_components = comp$no,
    largest_component_size = max(comp$csize),
    largest_component_pct = max(comp$csize) / n,
    n_isolates = n_isolates,
    n_bridges = n_bridges,
    n_cut_vertices = n_cut_vertices
  )
  
  # === COMPONENT ANALYSIS ===
  
  component_analysis <- tibble::tibble(
    component_id = 1:comp$no,
    size = comp$csize,
    pct_of_network = comp$csize / n
  )
  component_analysis <- dplyr::arrange(component_analysis, dplyr::desc(size))
  
  # Add member lists for small components
  component_analysis$members <- lapply(1:comp$no, function(i) {
    members <- node_names[comp$membership == i]
    if (length(members) <= 10) {
      paste(members, collapse = ", ")
    } else {
      paste0(paste(head(members, 10), collapse = ", "), ", ...")
    }
  })
  
  # === COHESIVE SUBGROUPS ===
  
  cat("Identifying cohesive subgroups...\n")
  
  # Find k-cores
  coreness <- igraph::coreness(g)
  max_core <- max(coreness)
  
  cohesive_subgroups <- tibble::tibble(
    type = character(),
    description = character(),
    n_members = numeric(),
    members = character()
  )
  
  # K-core
  if (max_core >= 3) {
    core_members <- node_names[coreness >= 3]
    cohesive_subgroups <- rbind(
      cohesive_subgroups,
      tibble::tibble(
        type = "k-core",
        description = paste0(max_core, "-core (highly interconnected)"),
        n_members = length(core_members),
        members = if (length(core_members) <= 10) {
          paste(core_members, collapse = ", ")
        } else {
          paste0(paste(head(core_members, 10), collapse = ", "), ", ...")
        }
      )
    )
  }
  
  # High clustering neighborhoods
  local_clustering <- igraph::transitivity(g, type = "local")
  high_clustering <- node_names[local_clustering > 0.7 & !is.na(local_clustering)]
  
  if (length(high_clustering) > 0) {
    cohesive_subgroups <- rbind(
      cohesive_subgroups,
      tibble::tibble(
        type = "high_clustering",
        description = "Nodes in tightly-knit neighborhoods",
        n_members = length(high_clustering),
        members = if (length(high_clustering) <= 10) {
          paste(high_clustering, collapse = ", ")
        } else {
          paste0(paste(head(high_clustering, 10), collapse = ", "), ", ...")
        }
      )
    )
  }
  
  # === TEAM COHESION ===
  
  team_cohesion <- NULL
  if (!is.null(team_attr)) {
    cat("Calculating team-level cohesion...\n")
    team_cohesion <- calculate_team_cohesion_metrics(g, team_attr, weights)
  }
  
  # === INTERPRETATION ===
  
  interpretation <- interpret_cohesion(cohesion_metrics, fragmentation_metrics, 
                                       component_analysis, team_cohesion)
  
  output <- list(
    cohesion_metrics = cohesion_metrics,
    fragmentation_metrics = fragmentation_metrics,
    component_analysis = component_analysis,
    cohesive_subgroups = cohesive_subgroups,
    team_cohesion = team_cohesion,
    interpretation = interpretation,
    n_nodes = n,
    n_edges = m
  )
  
  class(output) <- c("network_cohesion", "list")
  return(output)
}

# Helper: Calculate team cohesion
calculate_team_cohesion_metrics <- function(g, team_attr, weights) {
  nodes <- igraph::as_data_frame(g, what = "vertices")
  edges <- igraph::as_data_frame(g, what = "edges")
  
  if (!team_attr %in% names(nodes)) {
    stop("team_attr '", team_attr, "' not found in vertex attributes.")
  }
  
  nodes$team <- nodes[[team_attr]]
  teams <- unique(nodes$team[!is.na(nodes$team)])
  
  team_results <- lapply(teams, function(team) {
    team_members <- nodes$name[nodes$team == team]
    team_idx <- which(igraph::V(g)$name %in% team_members)
    
    if (length(team_idx) < 2) {
      return(NULL)
    }
    
    # Internal cohesion (within team)
    g_team <- igraph::induced_subgraph(g, team_idx)
    internal_density <- igraph::edge_density(g_team)
    internal_clustering <- igraph::transitivity(g_team, type = "global")
    if (is.na(internal_clustering)) internal_clustering <- 0
    
    # External connections (to other teams)
    edges$from_team <- nodes$team[match(edges$from, nodes$name)]
    edges$to_team <- nodes$team[match(edges$to, nodes$name)]
    
    external_edges <- edges[
      (edges$from_team == team & edges$to_team != team) |
      (edges$to_team == team & edges$from_team != team),
    ]
    
    n_external <- nrow(external_edges)
    n_internal <- igraph::ecount(g_team)
    
    # E-I index (external-internal)
    ei_index <- if (n_external + n_internal > 0) {
      (n_external - n_internal) / (n_external + n_internal)
    } else {
      0
    }
    
    tibble::tibble(
      team = team,
      n_members = length(team_members),
      internal_density = internal_density,
      internal_clustering = internal_clustering,
      n_internal_edges = n_internal,
      n_external_edges = n_external,
      ei_index = ei_index,
      cohesion_score = (internal_density + internal_clustering) / 2
    )
  })
  
  team_results <- team_results[!sapply(team_results, is.null)]
  result <- do.call(rbind, team_results)
  dplyr::arrange(result, dplyr::desc(cohesion_score))
}

# Helper: Interpret cohesion
interpret_cohesion <- function(cohesion_metrics, fragmentation_metrics, 
                               component_analysis, team_cohesion) {
  interp <- character()
  
  # Overall cohesion
  coh_idx <- cohesion_metrics$cohesion_index
  
  if (coh_idx > 0.7) {
    interp <- c(interp, "=== HIGHLY COHESIVE NETWORK ===")
    interp <- c(interp, "Network is well-connected and integrated")
  } else if (coh_idx > 0.4) {
    interp <- c(interp, "=== MODERATELY COHESIVE NETWORK ===")
    interp <- c(interp, "Network has reasonable connectivity")
  } else {
    interp <- c(interp, "=== LOW COHESION / FRAGMENTED NETWORK ===")
    interp <- c(interp, "Network has weak connections and potential silos")
  }
  
  interp <- c(interp, "")
  
  # Detailed metrics
  interp <- c(interp, sprintf("Density: %.3f (%.1f%% of possible connections exist)",
                              cohesion_metrics$density,
                              cohesion_metrics$density * 100))
  
  interp <- c(interp, sprintf("Compactness: %.3f (%.1f%% of pairs can reach each other)",
                              cohesion_metrics$compactness,
                              cohesion_metrics$compactness * 100))
  
  interp <- c(interp, sprintf("Fragmentation: %.3f (%.1f%% of pairs are disconnected)",
                              cohesion_metrics$fragmentation,
                              cohesion_metrics$fragmentation * 100))
  
  if (is.finite(cohesion_metrics$avg_distance)) {
    interp <- c(interp, sprintf("Average distance: %.2f steps between connected nodes",
                                cohesion_metrics$avg_distance))
  }
  
  interp <- c(interp, sprintf("Clustering: %.3f (%.1f%% of triangles are closed)",
                              cohesion_metrics$clustering,
                              cohesion_metrics$clustering * 100))
  
  interp <- c(interp, "")
  
  # Fragmentation issues
  if (fragmentation_metrics$n_components > 1) {
    interp <- c(interp, "⚠ FRAGMENTATION DETECTED:")
    interp <- c(interp, sprintf("  • %d disconnected components", 
                                fragmentation_metrics$n_components))
    interp <- c(interp, sprintf("  • Largest component: %d nodes (%.1f%%)",
                                fragmentation_metrics$largest_component_size,
                                fragmentation_metrics$largest_component_pct * 100))
  }
  
  if (fragmentation_metrics$n_isolates > 0) {
    interp <- c(interp, sprintf("  • %d isolated nodes (no connections)",
                                fragmentation_metrics$n_isolates))
  }
  
  if (fragmentation_metrics$n_cut_vertices > 0) {
    interp <- c(interp, sprintf("  • %d critical nodes (removal would disconnect network)",
                                fragmentation_metrics$n_cut_vertices))
  }
  
  if (fragmentation_metrics$n_bridges > 0) {
    interp <- c(interp, sprintf("  • %d bridge connections (removal would disconnect network)",
                                fragmentation_metrics$n_bridges))
  }
  
  interp <- c(interp, "")
  
  # Recommendations
  interp <- c(interp, "=== RECOMMENDATIONS ===")
  
  if (cohesion_metrics$cohesion_index < 0.4) {
    interp <- c(interp, "• PRIORITY: Increase connectivity between groups")
    interp <- c(interp, "• Create cross-functional teams or projects")
    interp <- c(interp, "• Establish regular inter-group communication")
  }
  
  if (fragmentation_metrics$n_components > 1) {
    interp <- c(interp, "• Connect isolated components through bridge roles")
    interp <- c(interp, "• Identify why groups are disconnected")
  }
  
  if (fragmentation_metrics$n_isolates > 0) {
    interp <- c(interp, "• Integrate isolated individuals into the network")
    interp <- c(interp, "• Assign mentors or buddies to isolated nodes")
  }
  
  if (fragmentation_metrics$n_cut_vertices > 5) {
    interp <- c(interp, "• Reduce dependency on critical nodes")
    interp <- c(interp, "• Create redundant connections around bottlenecks")
  }
  
  if (cohesion_metrics$cohesion_index > 0.7) {
    interp <- c(interp, "• Network is healthy - maintain current connectivity")
    interp <- c(interp, "• Monitor for over-clustering (echo chambers)")
  }
  
  # Team comparison
  if (!is.null(team_cohesion)) {
    interp <- c(interp, "")
    interp <- c(interp, "=== TEAM COHESION ===")
    
    most_cohesive <- team_cohesion[which.max(team_cohesion$cohesion_score), ]
    least_cohesive <- team_cohesion[which.min(team_cohesion$cohesion_score), ]
    
    interp <- c(interp, sprintf("Most cohesive: %s (score: %.3f)",
                                most_cohesive$team, most_cohesive$cohesion_score))
    interp <- c(interp, sprintf("Least cohesive: %s (score: %.3f)",
                                least_cohesive$team, least_cohesive$cohesion_score))
    
    # Identify insular teams (high internal, low external)
    insular <- team_cohesion[team_cohesion$ei_index < -0.5, ]
    if (nrow(insular) > 0) {
      interp <- c(interp, "")
      interp <- c(interp, "⚠ Insular teams (high internal, low external connections):")
      for (i in 1:min(3, nrow(insular))) {
        interp <- c(interp, sprintf("  • %s (E-I index: %.2f)",
                                    insular$team[i], insular$ei_index[i]))
      }
    }
  }
  
  interp
}

# Print method
#' @export
print.network_cohesion <- function(x, ...) {
  cat("=== Network Cohesion & Fragmentation Analysis ===\n\n")
  cat("Network size:", x$n_nodes, "nodes,", x$n_edges, "edges\n\n")
  
  cat(paste(x$interpretation, collapse = "\n"))
  
  if (nrow(x$component_analysis) > 1) {
    cat("\n\n=== Component Breakdown ===\n")
    print(x$component_analysis[, c("component_id", "size", "pct_of_network")])
  }
  
  if (nrow(x$cohesive_subgroups) > 0) {
    cat("\n=== Cohesive Subgroups ===\n")
    print(x$cohesive_subgroups)
  }
  
  if (!is.null(x$team_cohesion)) {
    cat("\n=== Team Cohesion Scores ===\n")
    print(x$team_cohesion[, c("team", "n_members", "cohesion_score", 
                              "internal_density", "ei_index")])
  }
  
  invisible(x)
}
