#' Create a Team-Wide “Replacement Map” for Bridge-Like Connection Patterns
#'
#' @description
#' Given a network where each vertex belongs to a team/group (via a vertex attribute),
#' this function finds, for every focal person, the most similar potential "replacement"
#' based on a *bridge signature* of their connections.
#'
#' The bridge signature is computed as a vector of proportions describing how a person's
#' ties distribute across all groups in the network (as defined by `group_attr`).
#' Similarity is computed using cosine similarity between these vectors.
#' 
#' The run_insights_backfill_connections() function assesses structural redundancy in organizational networks by identifying whether individuals have viable “replacements” who exhibit similar cross-group connection patterns. For each person, the function constructs a bridge signature—a normalized vector representing the proportion of that individual’s ties to each formal group (e.g., supervisor, department). It then uses cosine similarity to identify the most structurally similar colleague within the same team and across the broader organization. Rather than focusing on raw degree or centrality alone, this approach evaluates where connections go, capturing whether someone else connects to the same external groups in similar proportions. The output therefore indicates whether a structurally comparable actor exists and flags potential single points of failure.
#' Theoretically, this method is grounded in research on brokerage and structural holes (Ronald Burt), which shows that actors who span disconnected groups control information flow and often drive innovation and influence. However, brokerage can also create organizational vulnerability if concentrated in a single individual. By assessing structural similarity—an idea linked to role equivalence and centrality theory (Linton Freeman)—the function moves beyond identifying who is central to evaluating whether that structural role is distributed or redundant. In doing so, it provides a theoretically grounded diagnostic of resilience: teams with high internal similarity are structurally robust, whereas low similarity suggests dependence on unique brokers whose departure could fragment collaboration networks.
#'
#' The function returns *two* replacement candidates for each focal person:
#' \itemize{
#'   \item \strong{Same-team replacement}: best match among members of the focal person's own team
#'   \item \strong{Org-wide replacement}: best match among all other vertices in the network
#' }
#'
#' This is useful for assessing redundancy in bridging roles: if a key bridge node leaves,
#' does someone else in the team (or the org) have a similar external connection footprint?
#'
#' @param g An \code{igraph} graph object (directed or undirected).
#' @param group_attr Character scalar. Name of the vertex attribute defining team/group membership
#'   (e.g., \code{"reports_to_supervisor_login"}, \code{"department"}, \code{"org"}).
#' @param team_value Optional. If provided, restricts the focal set to vertices whose \code{group_attr}
#'   equals \code{team_value}. If \code{NULL} (default), computes results for all vertices.
#' @param mode Character scalar. Neighbor mode passed to \code{\link[igraph]{neighbors}}:
#'   \code{"all"} (default), \code{"out"}, or \code{"in"}.
#'   Use \code{"out"} for outgoing ties and \code{"in"} for incoming ties in directed networks.
#' @param min_similarity Numeric. Minimum cosine similarity threshold used to set the
#'   \code{*_exists} flags (default = 0.20). A higher value is stricter.
#' @param include_playbook Logical. If TRUE, generates a connection playbook for each
#'   focal person — a prioritized list of the incumbent's contacts with coaching guidance
#'   for a replacement. Default is FALSE.
#' @param verbose Logical. Print progress messages. Default \code{TRUE}.
#'
#' @return If \code{include_playbook = FALSE} (default), a \code{data.frame} with one row
#' per focal person and the following columns:
#' \itemize{
#'   \item \code{person_name}: Vertex name (or index coerced to character if \code{name} is missing)
#'   \item \code{team_value}: The person's group value from \code{group_attr}
#'   \item \code{same_team_replacement}: Best within-team replacement's name (or \code{NA})
#'   \item \code{same_team_similarity}: Cosine similarity to the within-team replacement
#'   \item \code{same_team_exists}: Logical; TRUE if \code{same_team_similarity >= min_similarity}
#'   \item \code{all_org_replacement}: Best org-wide replacement's name (or \code{NA})
#'   \item \code{all_org_similarity}: Cosine similarity to the org-wide replacement
#'   \item \code{all_org_exists}: Logical; TRUE if \code{all_org_similarity >= min_similarity}
#' }
#'
#' The output is sorted by ascending \code{same_team_similarity} to highlight lower redundancy cases first.
#'
#' If \code{include_playbook = TRUE}, returns a \code{list} with:
#' \itemize{
#'   \item \code{replacement_map}: The data.frame described above.
#'   \item \code{connection_playbook}: A named list of data.frames (one per focal person).
#'     Each playbook data.frame contains one row per contact of the departing person with:
#'     \itemize{
#'       \item \code{contact_name}: Who to connect with
#'       \item \code{contact_group}: The contact's group membership
#'       \item \code{tie_strength}: Edge weight to the incumbent (1 if unweighted)
#'       \item \code{contact_degree}: Contact's degree centrality
#'       \item \code{contact_betweenness}: Contact's betweenness centrality
#'       \item \code{is_cross_group}: Whether the contact is in a different group than the focal person
#'       \item \code{is_bridge}: Whether the contact has above-median betweenness (information broker)
#'       \item \code{is_hub}: Whether the contact has above-median degree (well-connected)
#'       \item \code{priority}: Integer 1-3 (1 = connect first). Based on cross-group bridging value,
#'         tie strength, and contact centrality
#'       \item \code{reason}: Plain-English explanation of why this contact matters
#'       \item \code{suggested_action}: Practical onboarding suggestion
#'     }
#' }
#'
#' @details
#' \strong{Bridge signature construction:}
#' For each node, the function counts neighbors by group membership (according to \code{group_attr}),
#' then normalizes counts to proportions (summing to 1). This representation focuses on
#' \emph{where} connections go, not simply how many.
#'
#' \strong{Similarity:}
#' Cosine similarity ranges from 0 to 1 when vectors are nonnegative. Higher values indicate
#' more similar distributions of ties across groups.
#'
#' \strong{Performance notes:}
#' Signatures are precomputed for all vertices once per function call for speed. For very large
#' networks, consider restricting with \code{team_value} or filtering the graph first.
#'
#' @examples
#' \dontrun{
#' library(igraph)
#'
#' # Example: compute replacement map for a single team
#' out_team <- run_insights_backfill_connections(
#'   g,
#'   group_attr = "reports_to_supervisor_login",
#'   team_value = "mgr_123",
#'   mode = "all",
#'   min_similarity = 0.25
#' )
#'
#' # Example: compute replacement map for all vertices
#' out_all <- run_insights_backfill_connections(
#'   g,
#'   group_attr = "reports_to_supervisor_login",
#'   team_value = NULL,
#'   mode = "out"
#' )
#' }
#'
#' @importFrom igraph edge_attr_names edge_attr get_edge_ids
#' @importFrom stats median setNames
#' @export
run_recommend_backfill <- function(
    g,
    group_attr = "reports_to_supervisor_login",
    team_value = NULL,
    mode = c("all","out","in"),
    min_similarity = 0.20,
    include_playbook = FALSE,
    verbose = TRUE
){
  mode <- match.arg(mode)
  
  grp <- igraph::vertex_attr(g, group_attr)
  if (is.null(grp)) stop("group_attr not found on vertices: ", group_attr)
  
  v_names <- igraph::V(g)$name
  if (is.null(v_names)) v_names <- as.character(seq_len(igraph::vcount(g)))
  
  groups <- sort(unique(grp[!is.na(grp)]))
  group_index <- stats::setNames(seq_along(groups), groups)
  
  # --- Neighbor getter ---
  nbrs_of <- function(v) igraph::neighbors(g, v, mode = mode)
  
  # --- Signature (proportion of ties to each group) ---
  signature <- function(v) {
    nbrs <- nbrs_of(v)
    if (length(nbrs) == 0) return(rep(0, length(groups)))
    nbrs <- as.integer(nbrs)
    nbr_groups <- grp[nbrs]
    # Remove NAs and empty strings from neighbor groups before tabulating
    nbr_groups <- nbr_groups[!is.na(nbr_groups) & nchar(as.character(nbr_groups)) > 0]
    if (length(nbr_groups) == 0) return(rep(0, length(groups)))
    tab <- base::table(nbr_groups)
    vec <- rep(0, length(groups))
    # Only assign for groups that exist in group_index and produce valid indices
    for (nm in names(tab)) {
      idx <- group_index[nm]
      if (!is.na(idx)) {
        vec[idx] <- as.numeric(tab[nm])
      }
    }
    if (sum(vec) > 0) vec <- vec / sum(vec)
    vec
  }
  
  cosine_sim <- function(a, b) {
    denom <- sqrt(sum(a*a)) * sqrt(sum(b*b))
    if (denom == 0) return(NA_real_)
    sum(a*b) / denom
  }
  
  # --- Determine focal nodes ---
  if (!is.null(team_value)) {
    focal <- which(grp == team_value)
    if (length(focal) == 0)
      stop("No vertices found for team_value = ", team_value)
  } else {
    focal <- seq_len(igraph::vcount(g))
  }
  
  # --- Precompute signatures ---
  if (verbose) cat("Computing bridge signatures for", igraph::vcount(g), "nodes...\n")
  sigs <- lapply(seq_len(igraph::vcount(g)), signature)
  
  if (verbose) cat("Finding replacements for", length(focal), "focal nodes...\n")
  if (verbose) pb <- txtProgressBar(min = 0, max = length(focal), style = 3)
  
  rows <- vector("list", length(focal))
  
  for (i in seq_along(focal)) {
    v <- focal[i]
    
    # SAME TEAM candidates
    cand_same <- setdiff(which(grp == grp[v]), v)
    
    sims_same <- if (length(cand_same) > 0)
      vapply(cand_same, function(cj) cosine_sim(sigs[[v]], sigs[[cj]]), numeric(1))
    else numeric(0)
    
    if (length(sims_same) > 0 && any(!is.na(sims_same))) {
      best_same <- cand_same[which.max(sims_same)]
      best_same_sim <- max(sims_same, na.rm = TRUE)
    } else {
      best_same <- NA_integer_
      best_same_sim <- NA_real_
    }
    
    # ALL ORG candidates
    cand_all <- setdiff(seq_len(igraph::vcount(g)), v)
    
    sims_all <- vapply(cand_all, function(cj) cosine_sim(sigs[[v]], sigs[[cj]]), numeric(1))
    
    if (length(sims_all) > 0 && any(!is.na(sims_all))) {
      best_all <- cand_all[which.max(sims_all)]
      best_all_sim <- max(sims_all, na.rm = TRUE)
    } else {
      best_all <- NA_integer_
      best_all_sim <- NA_real_
    }
    
    rows[[i]] <- data.frame(
      person_name = v_names[v],
      team_value = grp[v],
      
      same_team_replacement = if (!is.na(best_same)) v_names[best_same] else NA_character_,
      same_team_similarity = best_same_sim,
      same_team_exists = !is.na(best_same_sim) && best_same_sim >= min_similarity,
      
      all_org_replacement = if (!is.na(best_all)) v_names[best_all] else NA_character_,
      all_org_similarity = best_all_sim,
      all_org_exists = !is.na(best_all_sim) && best_all_sim >= min_similarity,
      
      stringsAsFactors = FALSE
    )
    
    if (verbose) setTxtProgressBar(pb, i)
  }
  
  if (verbose) close(pb)
  if (verbose) cat("\nReplacement analysis completed!\n")
  
  out <- do.call(rbind, rows)
  
  # Sort: lowest same-team similarity first (risk view)
  out <- out[order(out$same_team_similarity), ]
  rownames(out) <- NULL
  
  # --- Connection Playbook ---
  if (include_playbook) {
    if (verbose) cat("Generating connection playbooks...\n")
    
    # Pre-extract centrality metrics if available
    has_degree <- "degree" %in% igraph::vertex_attr_names(g)
    has_betweenness <- "betweenness" %in% igraph::vertex_attr_names(g)
    
    v_degree <- if (has_degree) igraph::vertex_attr(g, "degree") else igraph::degree(g, mode = "total")
    v_betweenness <- if (has_betweenness) igraph::vertex_attr(g, "betweenness") else igraph::betweenness(g)
    
    median_degree <- stats::median(v_degree, na.rm = TRUE)
    median_betweenness <- stats::median(v_betweenness, na.rm = TRUE)
    
    has_weight <- "weight" %in% igraph::edge_attr_names(g)
    
    playbooks <- stats::setNames(vector("list", length(focal)), v_names[focal])
    
    if (verbose) pb2 <- txtProgressBar(min = 0, max = length(focal), style = 3)
    
    for (i in seq_along(focal)) {
      v <- focal[i]
      nbrs <- as.integer(nbrs_of(v))
      
      if (length(nbrs) == 0) {
        playbooks[[i]] <- data.frame(
          contact_name = character(0), contact_group = character(0),
          tie_strength = numeric(0), contact_degree = numeric(0),
          contact_betweenness = numeric(0), is_cross_group = logical(0),
          is_bridge = logical(0), is_hub = logical(0),
          priority = integer(0), reason = character(0),
          suggested_action = character(0), stringsAsFactors = FALSE
        )
        if (verbose) setTxtProgressBar(pb2, i)
        next
      }
      
      focal_group <- grp[v]
      
      # Get tie weights for each neighbor
      tie_weights <- vapply(nbrs, function(nb) {
        eid <- igraph::get_edge_ids(g, c(v, nb))
        if (eid == 0) eid <- igraph::get_edge_ids(g, c(nb, v))
        if (eid == 0 || !has_weight) return(1)
        w <- igraph::edge_attr(g, "weight", eid)
        if (is.na(w)) 1 else w
      }, numeric(1))
      
      contact_groups <- grp[nbrs]
      contact_deg <- v_degree[nbrs]
      contact_btw <- v_betweenness[nbrs]
      # Handle NA in group comparisons
      is_cross <- !is.na(contact_groups) & !is.na(focal_group) & (contact_groups != focal_group)
      is_bridge <- !is.na(contact_btw) & (contact_btw > median_betweenness)
      is_hub <- !is.na(contact_deg) & (contact_deg > median_degree)
      
      # Score for priority: cross-group bridges with strong ties first
      tw_range <- range(tie_weights, na.rm = TRUE)
      tw_rescaled <- if (tw_range[2] > tw_range[1]) {
        (tie_weights - tw_range[1]) / (tw_range[2] - tw_range[1]) * 2
      } else {
        rep(1, length(tie_weights))
      }
      score <- (is_cross * 3) + (is_bridge * 2) + (is_hub * 1) + tw_rescaled
      
      priority <- ifelse(score >= 5, 1L, ifelse(score >= 3, 2L, 3L))
      
      # Build reason strings
      reason <- vapply(seq_along(nbrs), function(j) {
        parts <- c()
        if (isTRUE(is_cross[j])) parts <- c(parts, paste0("cross-group link to ", contact_groups[j]))
        if (isTRUE(is_bridge[j])) parts <- c(parts, "information broker")
        if (isTRUE(is_hub[j])) parts <- c(parts, "well-connected hub")
        if (length(parts) == 0) parts <- "team cohesion contact"
        paste(parts, collapse = "; ")
      }, character(1))
      
      # Build suggested actions
      action <- vapply(seq_along(nbrs), function(j) {
        if (priority[j] == 1L) {
          if (isTRUE(is_cross[j])) return("Schedule 1:1 intro in first week — critical cross-group bridge")
          return("Schedule 1:1 intro in first week — key connector")
        }
        if (priority[j] == 2L) {
          return("Request introduction within first two weeks")
        }
        "Build relationship organically over first month"
      }, character(1))
      
      pb_df <- data.frame(
        contact_name = v_names[nbrs],
        contact_group = contact_groups,
        tie_strength = tie_weights,
        contact_degree = contact_deg,
        contact_betweenness = round(contact_btw, 2),
        is_cross_group = is_cross,
        is_bridge = is_bridge,
        is_hub = is_hub,
        priority = priority,
        reason = reason,
        suggested_action = action,
        stringsAsFactors = FALSE
      )
      
      playbooks[[i]] <- pb_df[order(pb_df$priority, -pb_df$tie_strength), ]
      rownames(playbooks[[i]]) <- NULL
      
      if (verbose) setTxtProgressBar(pb2, i)
    }
    
    if (verbose) close(pb2)
    if (verbose) cat("\nConnection playbooks generated!\n")
    
    return(list(
      replacement_map = out,
      connection_playbook = playbooks
    ))
  }
  
  out
}