#' Plot Network Graph
#'
#' Creates a visualization of a network graph using a selectable layout, with optional
#' group-based node coloring and degree-based vertex sizing.
#'
#' @param g An igraph object representing the network to be plotted.
#' @param group_var Character string specifying the vertex attribute name for grouping.
#'   If NULL (default), all nodes will be colored the same.
#' @param min_size Minimum vertex size (default = 5).
#' @param max_size Maximum vertex size (default = 15).
#' @param show_labels Logical. If TRUE, displays vertex labels. Default is FALSE.
#' @param title Optional character string for the plot title. If NULL (default),
#'   uses "Network Plot (<layout>)".
#' @param layout Layout specification. One of:
#'   \itemize{
#'     \item A character string naming a built-in layout: \code{"mds"} (default),
#'           \code{"kk"}, \code{"fr"}, \code{"lgl"}, \code{"circle"}.
#'     \item A function that accepts \code{g} and returns a two-column numeric matrix of
#'           XY coordinates (one row per vertex), e.g. \code{igraph::layout_with_fr}.
#'     \item A numeric matrix of XY coordinates with \code{nrow(layout) == vcount(g)}
#'           and \code{ncol(layout) == 2}.
#'   }
#'
#' @details
#' The function creates a network visualization using the chosen layout.
#' Vertex sizes are scaled based on node degree between \code{min_size} and \code{max_size}.
#' If \code{group_var} is provided, nodes are colored by group membership using the
#' MetBrewer \code{"Johnson"} palette and a legend is added.
#'
#' @return Invisibly returns \code{NULL}. Called for its side effect of producing a plot.
#'
#' @examples
#' \dontrun{
#' # Default (MDS)
#' plot_network(g)
#'
#' # Switch layout via string
#' plot_network(g, layout = "kk")
#' plot_network(g, layout = "fr")
#'
#' # Pass a layout function (must return an XY matrix)
#' plot_network(g, layout = igraph::layout_with_fr)
#'
#' # Pass a precomputed layout matrix
#' coords <- igraph::layout_with_kk(g)
#' plot_network(g, layout = coords)
#'
#' # Group coloring + labels
#' plot_network(g, group_var = "team", show_labels = TRUE, layout = "lgl")
#' }
#'
#' @export
plot_network <- function(
    g,
    group_var = NULL,
    min_size = 5,
    max_size = 15,
    show_labels = FALSE,
    layout = "mds",
    title = NULL
) {
  edge_arrow_size  <- 0.01
  edge_arrow_width <- 0.01
  default_vertex_color <- "gray70"
  default_edge_color   <- "gray80"
  
  # ---------------------------
  # Vertex sizing (by degree)
  # ---------------------------
  degrees <- igraph::degree(g)
  
  if (length(unique(degrees)) == 1) {
    vertex_sizes <- rep(min_size, length(degrees))
  } else {
    vertex_sizes <- scales::rescale(
      degrees,
      to   = c(min_size, max_size),
      from = range(degrees)
    )
  }
  
  # ---------------------------
  # Layout handling
  # ---------------------------
  layout_matrix <- NULL
  
  if (is.character(layout)) {
    
    layout_matrix <- switch(
      layout,
      "mds"    = igraph::layout_with_mds(g),
      "kk"     = igraph::layout_with_kk(g),
      "fr"     = igraph::layout_with_fr(g),
      "lgl"    = igraph::layout_with_lgl(g),
      "circle" = igraph::layout_in_circle(g),
      stop("Unsupported layout type. Try: 'mds', 'kk', 'fr', 'lgl', 'circle'")
    )
    
    layout_name <- toupper(layout)
    
  } else if (is.function(layout)) {
    
    layout_matrix <- layout(g)
    layout_name   <- "Custom Function"
    
  } else if (is.matrix(layout)) {
    
    layout_matrix <- layout
    layout_name   <- "Custom Matrix"
    
  } else {
    stop("layout must be a character string, function, or matrix.")
  }
  
  # ---------------------------
  # Labels
  # ---------------------------
  if (show_labels) {
    vertex_labels <- igraph::V(g)$name
    if (is.null(vertex_labels)) {
      vertex_labels <- as.character(1:igraph::vcount(g))
    }
  } else {
    vertex_labels <- NA
  }
  
  # ---------------------------
  # Group coloring
  # ---------------------------
  if (!is.null(group_var)) {
    
    if (!group_var %in% igraph::vertex_attr_names(g)) {
      stop(paste("Group variable", group_var, "not found in vertex attributes"))
    }
    
    group_membership <- igraph::vertex_attr(g, group_var)
    unique_groups    <- unique(group_membership)
    
    palette <- MetBrewer::met.brewer(
      "Johnson",
      n = length(unique_groups)
    )
    
    node_colors <- palette[match(group_membership, unique_groups)]
    
    plot(
      g,
      layout              = layout_matrix,
      vertex.color        = node_colors,
      vertex.size         = vertex_sizes,
      edge.arrow.size     = edge_arrow_size,
      edge.arrow.width    = edge_arrow_width,
      vertex.label        = vertex_labels,
      vertex.label.dist   = 0.5,
      vertex.label.color  = "black",
      edge.color          = default_edge_color,
      main                = if (!is.null(title)) title else paste0("Network Plot (", layout_name, ")")
    )
    
    legend(
      "topright",
      legend = unique_groups,
      col    = palette,
      pch    = 16,
      bty    = "n",
      cex    = 0.8
    )
    
  } else {
    
    plot(
      g,
      layout              = layout_matrix,
      vertex.color        = default_vertex_color,
      vertex.size         = vertex_sizes,
      edge.arrow.size     = edge_arrow_size,
      edge.arrow.width    = edge_arrow_width,
      vertex.label        = vertex_labels,
      vertex.label.dist   = 0.5,
      vertex.label.color  = "black",
      edge.color          = default_edge_color,
      main                = if (!is.null(title)) title else paste0("Network Plot (", layout_name, ")")
    )
  }
}