#' Analyze network resilience to node/edge removal
#'
#' @description
#' Assesses how robust a network is to disruption from node or edge removal.
#' Simulates random failures vs targeted attacks to understand vulnerability.
#'
#' Practical uses:
#' \itemize{
#'   \item Assess impact of employee turnover
#'   \item Identify critical employees whose loss would fragment the network
#'   \item Plan for succession and knowledge transfer
#'   \item Evaluate team redundancy and backup capacity
#'   \item Compare resilience across departments/teams
#' }
#'
#' @param g An igraph object. Must have a \code{name} vertex attribute.
#' @param removal_type Character: "nodes" (default) or "edges". What to remove.
#' @param attack_strategy Character: "random", "degree", "betweenness", or "all".
#'   \itemize{
#'     \item random: Remove nodes/edges randomly (simulates random turnover)
#'     \item degree: Remove highest degree nodes first (lose most connected people)
#'     \item betweenness: Remove highest betweenness nodes first (lose key bridges)
#'     \item all: Run all strategies and compare
#'   }
#' @param removal_fraction Numeric vector of fractions to remove (e.g., c(0.1, 0.2, 0.3)).
#'   Default is seq(0.05, 0.5, 0.05) - remove 5% to 50% in 5% increments.
#' @param n_simulations Number of random simulations to run. Default is 100.
#' @param metrics Character vector of metrics to track. Options:
#'   "size" (largest component size), "components" (number of components),
#'   "efficiency" (network efficiency), "diameter" (network diameter),
#'   "clustering" (clustering coefficient). Default is all.
#' @param team_attr Optional vertex attribute for team-level analysis.
#' @param critical_threshold Fraction of network that must remain connected
#'   to be considered "functional". Default is 0.8 (80%).
#'
#' @return A list containing:
#' \describe{
#'   \item{resilience_curves}{Data frame with metrics at each removal fraction}
#'   \item{critical_points}{Removal fraction where network fragments}
#'   \item{vulnerability_ranking}{Nodes ranked by their impact on network}
#'   \item{comparison}{Comparison of random vs targeted attack}
#'   \item{team_resilience}{Team-level resilience scores (if team_attr provided)}
#'   \item{recommendations}{Actionable recommendations to improve resilience}
#' }
#'
#' @details
#' Resilience metrics:
#'
#' \strong{Largest Component Size:} Fraction of nodes in the largest connected component.
#' Drops sharply when network fragments.
#'
#' \strong{Network Efficiency:} Average inverse distance between all node pairs.
#' Measures how easily information flows.
#'
#' \strong{Number of Components:} How many disconnected pieces exist.
#' Increases as network fragments.
#'
#' \strong{Critical Threshold:} The removal fraction where the largest component
#' drops below the critical_threshold (default 80%). This is when the network
#' "breaks" and can no longer function effectively.
#'
#' Random removal simulates natural turnover or random failures. Targeted removal
#' simulates strategic attacks or loss of key personnel.
#'
#' A resilient network maintains connectivity even after significant node removal.
#' Vulnerable networks fragment quickly, especially under targeted attacks.
#'
#' @examples
#' \dontrun{
#' # Basic resilience analysis
#' resilience <- run_insights_network_resilience(g)
#' plot(resilience)
#'
#' # Compare random vs targeted attacks
#' resilience <- run_insights_network_resilience(
#'   g,
#'   attack_strategy = "all",
#'   n_simulations = 200
#' )
#'
#' # Team-level resilience
#' resilience <- run_insights_network_resilience(
#'   g,
#'   team_attr = "department",
#'   critical_threshold = 0.75
#' )
#' }
#'
#' @importFrom igraph vcount ecount delete_vertices delete_edges components
#' @importFrom igraph degree betweenness distances V E
#' @importFrom stats quantile
#' @importFrom dplyr group_by summarise arrange desc
#' @importFrom tibble tibble
#'
#' @export
run_resilience_network <- function(g,
                                           removal_type = c("nodes", "edges"),
                                           attack_strategy = c("random", "degree", 
                                                              "betweenness", "all"),
                                           removal_fraction = seq(0.05, 0.5, 0.05),
                                           n_simulations = 100,
                                           metrics = c("size", "components", "efficiency", 
                                                      "diameter", "clustering"),
                                           team_attr = NULL,
                                           critical_threshold = 0.8) {
  
  if (!inherits(g, "igraph")) {
    stop("`g` must be an igraph object.")
  }
  
  if (!"name" %in% igraph::vertex_attr_names(g)) {
    stop("Graph must have a 'name' vertex attribute.")
  }
  
  removal_type <- match.arg(removal_type)
  attack_strategy <- match.arg(attack_strategy)
  
  cat("=== Network Resilience Analysis ===\n")
  cat("Removal type:", removal_type, "\n")
  cat("Attack strategy:", attack_strategy, "\n\n")
  
  # Run analysis based on strategy
  if (attack_strategy == "all") {
    strategies <- c("random", "degree", "betweenness")
  } else {
    strategies <- attack_strategy
  }
  
  all_results <- list()
  
  for (strat in strategies) {
    cat("Running", strat, "removal simulations...\n")
    
    if (strat == "random") {
      results <- simulate_random_removal(g, removal_type, removal_fraction, 
                                        n_simulations, metrics)
    } else {
      results <- simulate_targeted_removal(g, removal_type, removal_fraction, 
                                          strat, metrics)
    }
    
    all_results[[strat]] <- results
  }
  
  # Combine results
  resilience_curves <- combine_results(all_results, removal_fraction)
  
  # Find critical points
  cat("Identifying critical failure points...\n")
  critical_points <- find_critical_points(resilience_curves, critical_threshold)
  
  # Rank node vulnerability
  cat("Ranking node vulnerability...\n")
  vulnerability_ranking <- rank_node_vulnerability(g, removal_type)
  
  # Compare strategies
  comparison <- compare_strategies(all_results, critical_points)
  
  # Team-level analysis
  team_resilience <- NULL
  if (!is.null(team_attr)) {
    cat("Calculating team-level resilience...\n")
    team_resilience <- calculate_team_resilience(g, team_attr, vulnerability_ranking)
  }
  
  # Generate recommendations
  recommendations <- generate_resilience_recommendations(
    critical_points, vulnerability_ranking, comparison, team_resilience
  )
  
  output <- list(
    resilience_curves = resilience_curves,
    critical_points = critical_points,
    vulnerability_ranking = vulnerability_ranking,
    comparison = comparison,
    team_resilience = team_resilience,
    recommendations = recommendations,
    baseline_metrics = calculate_baseline_metrics(g)
  )
  
  class(output) <- c("network_resilience", "list")
  return(output)
}

# Helper: Simulate random removal
simulate_random_removal <- function(g, removal_type, removal_fraction, n_simulations, metrics) {
  n_total <- if (removal_type == "nodes") igraph::vcount(g) else igraph::ecount(g)
  
  results <- list()
  
  pb <- txtProgressBar(min = 0, max = length(removal_fraction) * n_simulations, style = 3)
  counter <- 0
  
  for (frac in removal_fraction) {
    n_remove <- round(n_total * frac)
    
    sim_results <- replicate(n_simulations, {
      counter <<- counter + 1
      setTxtProgressBar(pb, counter)
      
      # Random removal
      if (removal_type == "nodes") {
        to_remove <- sample(igraph::vcount(g), n_remove)
        g_temp <- igraph::delete_vertices(g, to_remove)
      } else {
        to_remove <- sample(igraph::ecount(g), n_remove)
        g_temp <- igraph::delete_edges(g, to_remove)
      }
      
      calculate_resilience_metrics(g_temp, metrics)
    }, simplify = FALSE)
    
    # Average across simulations
    results[[as.character(frac)]] <- average_metrics(sim_results)
  }
  
  close(pb)
  results
}

# Helper: Simulate targeted removal
simulate_targeted_removal <- function(g, removal_type, removal_fraction, strategy, metrics) {
  n_total <- if (removal_type == "nodes") igraph::vcount(g) else igraph::ecount(g)
  
  # Calculate targeting metric
  if (removal_type == "nodes") {
    if (strategy == "degree") {
      scores <- igraph::degree(g)
    } else if (strategy == "betweenness") {
      scores <- igraph::betweenness(g)
    }
    order_remove <- order(-scores)  # Highest first
  } else {
    if (strategy == "degree") {
      # Edge betweenness
      scores <- igraph::edge_betweenness(g)
    } else {
      scores <- igraph::edge_betweenness(g)
    }
    order_remove <- order(-scores)
  }
  
  results <- list()
  
  for (frac in removal_fraction) {
    n_remove <- round(n_total * frac)
    to_remove <- order_remove[1:n_remove]
    
    if (removal_type == "nodes") {
      g_temp <- igraph::delete_vertices(g, to_remove)
    } else {
      g_temp <- igraph::delete_edges(g, to_remove)
    }
    
    results[[as.character(frac)]] <- calculate_resilience_metrics(g_temp, metrics)
  }
  
  results
}

# Helper: Calculate resilience metrics
calculate_resilience_metrics <- function(g, metrics) {
  result <- list()
  
  if (igraph::vcount(g) == 0) {
    return(list(
      size = 0,
      components = 0,
      efficiency = 0,
      diameter = Inf,
      clustering = 0
    ))
  }
  
  if ("size" %in% metrics) {
    comp <- igraph::components(g)
    result$size <- max(comp$csize) / igraph::vcount(g)
  }
  
  if ("components" %in% metrics) {
    comp <- igraph::components(g)
    result$components <- comp$no
  }
  
  if ("efficiency" %in% metrics) {
    if (igraph::vcount(g) > 1) {
      dists <- igraph::distances(g)
      dists[is.infinite(dists)] <- 0
      dists[dists == 0] <- NA
      result$efficiency <- mean(1 / dists, na.rm = TRUE)
    } else {
      result$efficiency <- 0
    }
  }
  
  if ("diameter" %in% metrics) {
    result$diameter <- tryCatch(
      igraph::diameter(g),
      error = function(e) Inf
    )
  }
  
  if ("clustering" %in% metrics) {
    result$clustering <- igraph::transitivity(g, type = "global")
    if (is.na(result$clustering)) result$clustering <- 0
  }
  
  result
}

# Helper: Average metrics across simulations
average_metrics <- function(sim_results) {
  metric_names <- names(sim_results[[1]])
  
  result <- lapply(metric_names, function(metric) {
    values <- sapply(sim_results, function(x) x[[metric]])
    list(
      mean = mean(values, na.rm = TRUE),
      sd = sd(values, na.rm = TRUE),
      q25 = quantile(values, 0.25, na.rm = TRUE),
      q75 = quantile(values, 0.75, na.rm = TRUE)
    )
  })
  
  names(result) <- metric_names
  result
}

# Helper: Combine results
combine_results <- function(all_results, removal_fraction) {
  rows <- list()
  
  for (strategy in names(all_results)) {
    for (frac in as.character(removal_fraction)) {
      metrics <- all_results[[strategy]][[frac]]
      
      row <- tibble::tibble(
        strategy = strategy,
        removal_fraction = as.numeric(frac),
        largest_component = metrics$size$mean,
        n_components = metrics$components$mean,
        efficiency = metrics$efficiency$mean,
        diameter = metrics$diameter$mean,
        clustering = metrics$clustering$mean
      )
      
      rows[[length(rows) + 1]] <- row
    }
  }
  
  do.call(rbind, rows)
}

# Helper: Find critical points
find_critical_points <- function(resilience_curves, threshold) {
  strategies <- unique(resilience_curves$strategy)
  
  critical <- lapply(strategies, function(strat) {
    data <- resilience_curves[resilience_curves$strategy == strat, ]
    
    # Find where largest component drops below threshold
    below_threshold <- data$largest_component < threshold
    
    if (any(below_threshold)) {
      critical_frac <- min(data$removal_fraction[below_threshold])
    } else {
      critical_frac <- NA
    }
    
    tibble::tibble(
      strategy = strat,
      critical_fraction = critical_frac,
      interpretation = if (is.na(critical_frac)) {
        "Network remains connected even at 50% removal"
      } else {
        paste0("Network fragments at ", round(critical_frac * 100), "% removal")
      }
    )
  })
  
  do.call(rbind, critical)
}

# Helper: Rank node vulnerability
rank_node_vulnerability <- function(g, removal_type) {
  if (removal_type == "edges") {
    return(NULL)
  }
  
  n <- igraph::vcount(g)
  node_names <- igraph::V(g)$name
  
  # Calculate impact of removing each node
  impacts <- sapply(1:n, function(i) {
    g_temp <- igraph::delete_vertices(g, i)
    comp <- igraph::components(g_temp)
    1 - (max(comp$csize) / igraph::vcount(g_temp))
  })
  
  result <- tibble::tibble(
    node = node_names,
    fragmentation_impact = impacts,
    degree = igraph::degree(g),
    betweenness = igraph::betweenness(g)
  )
  
  dplyr::arrange(result, dplyr::desc(fragmentation_impact))
}

# Helper: Compare strategies
compare_strategies <- function(all_results, critical_points) {
  if (length(all_results) == 1) {
    return(NULL)
  }
  
  tibble::tibble(
    comparison = "Random vs Targeted",
    finding = if (nrow(critical_points) > 1) {
      random_crit <- critical_points$critical_fraction[critical_points$strategy == "random"]
      targeted_crit <- min(critical_points$critical_fraction[critical_points$strategy != "random"], na.rm = TRUE)
      
      if (is.na(random_crit) && is.na(targeted_crit)) {
        "Network is highly resilient to both random and targeted attacks"
      } else if (!is.na(random_crit) && !is.na(targeted_crit)) {
        ratio <- random_crit / targeted_crit
        paste0("Network is ", round(ratio, 1), "x more vulnerable to targeted attacks than random failures")
      } else if (is.na(random_crit)) {
        "Network is resilient to random failures but vulnerable to targeted attacks"
      } else {
        "Network is vulnerable to random failures"
      }
    } else {
      "Only one strategy analyzed"
    }
  )
}

# Helper: Calculate team resilience
calculate_team_resilience <- function(g, team_attr, vulnerability_ranking) {
  if (is.null(vulnerability_ranking)) {
    return(NULL)
  }
  
  nodes <- igraph::as_data_frame(g, what = "vertices")
  nodes$team <- nodes[[team_attr]]
  
  vulnerability_ranking$team <- nodes$team[match(vulnerability_ranking$node, nodes$name)]
  
  team_stats <- dplyr::group_by(vulnerability_ranking, team)
  team_stats <- dplyr::summarise(
    team_stats,
    n_members = dplyr::n(),
    avg_impact = mean(fragmentation_impact, na.rm = TRUE),
    max_impact = max(fragmentation_impact, na.rm = TRUE),
    critical_members = sum(fragmentation_impact > 0.1),
    .groups = "drop"
  )
  
  dplyr::arrange(team_stats, dplyr::desc(avg_impact))
}

# Helper: Generate recommendations
generate_resilience_recommendations <- function(critical_points, vulnerability_ranking, 
                                               comparison, team_resilience) {
  recs <- character()
  
  # Overall resilience
  if (!is.null(critical_points)) {
    random_crit <- critical_points$critical_fraction[critical_points$strategy == "random"]
    
    if (!is.na(random_crit) && random_crit < 0.2) {
      recs <- c(recs, "CRITICAL: Network is fragile - fragments with <20% node loss")
      recs <- c(recs, "• Immediately add redundant connections between teams")
      recs <- c(recs, "• Cross-train employees to reduce single points of failure")
    } else if (!is.na(random_crit) && random_crit < 0.4) {
      recs <- c(recs, "WARNING: Network has moderate vulnerability")
      recs <- c(recs, "• Strengthen connections between weakly connected groups")
    } else {
      recs <- c(recs, "GOOD: Network shows strong resilience to random failures")
    }
  }
  
  # Vulnerable nodes
  if (!is.null(vulnerability_ranking)) {
    high_impact <- vulnerability_ranking[vulnerability_ranking$fragmentation_impact > 0.1, ]
    
    if (nrow(high_impact) > 0) {
      recs <- c(recs, paste0("\n", nrow(high_impact), " critical nodes identified:"))
      for (i in 1:min(5, nrow(high_impact))) {
        recs <- c(recs, paste0("• ", high_impact$node[i], 
                              " (impact: ", round(high_impact$fragmentation_impact[i] * 100, 1), "%)"))
      }
      recs <- c(recs, "\nRecommendations for critical nodes:")
      recs <- c(recs, "• Develop succession plans")
      recs <- c(recs, "• Document their key relationships and knowledge")
      recs <- c(recs, "• Create backup connections through their contacts")
    }
  }
  
  # Team resilience
  if (!is.null(team_resilience)) {
    vulnerable_teams <- team_resilience[team_resilience$avg_impact > 0.05, ]
    
    if (nrow(vulnerable_teams) > 0) {
      recs <- c(recs, "\nVulnerable teams:")
      for (i in 1:min(3, nrow(vulnerable_teams))) {
        recs <- c(recs, paste0("• ", vulnerable_teams$team[i], 
                              " (", vulnerable_teams$critical_members[i], " critical members)"))
      }
    }
  }
  
  recs
}

# Helper: Calculate baseline metrics
calculate_baseline_metrics <- function(g) {
  list(
    n_nodes = igraph::vcount(g),
    n_edges = igraph::ecount(g),
    density = igraph::edge_density(g),
    components = igraph::components(g)$no,
    diameter = tryCatch(igraph::diameter(g), error = function(e) Inf)
  )
}

# Print method
#' @export
print.network_resilience <- function(x, ...) {
  cat("=== Network Resilience Analysis ===\n\n")
  
  cat("Baseline Network:\n")
  cat("  Nodes:", x$baseline_metrics$n_nodes, "\n")
  cat("  Edges:", x$baseline_metrics$n_edges, "\n")
  cat("  Density:", round(x$baseline_metrics$density, 3), "\n\n")
  
  cat("Critical Failure Points:\n")
  print(x$critical_points)
  
  if (!is.null(x$comparison)) {
    cat("\n")
    print(x$comparison)
  }
  
  if (!is.null(x$vulnerability_ranking)) {
    cat("\n\nMost Vulnerable Nodes (Top 10):\n")
    print(head(x$vulnerability_ranking[, c("node", "fragmentation_impact", "degree")], 10))
  }
  
  if (!is.null(x$team_resilience)) {
    cat("\n\nTeam Resilience:\n")
    print(x$team_resilience)
  }
  
  cat("\n=== Recommendations ===\n")
  cat(paste(x$recommendations, collapse = "\n"))
  cat("\n")
  
  invisible(x)
}

# Plot method
#' @export
plot.network_resilience <- function(x, ...) {
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("ggplot2 package required for plotting")
  }
  
  ggplot2::ggplot(x$resilience_curves, 
                  ggplot2::aes(x = removal_fraction, y = largest_component, 
                              color = strategy, linetype = strategy)) +
    ggplot2::geom_line(size = 1.2) +
    ggplot2::geom_hline(yintercept = 0.8, linetype = "dashed", color = "red", alpha = 0.5) +
    ggplot2::labs(
      title = "Network Resilience Curve",
      subtitle = "Largest component size vs. node removal",
      x = "Fraction of Nodes Removed",
      y = "Fraction in Largest Component",
      color = "Attack Strategy",
      linetype = "Attack Strategy"
    ) +
    ggplot2::theme_minimal() +
    ggplot2::theme(legend.position = "bottom")
}
