#' Identify "Glue Guys" - Team Cohesion Maintainers
#'
#' @description
#' Identifies "glue guys" in a network - individuals who hold the team together
#' through their structural position rather than through high centrality or popularity.
#' Glue guys are characterized by their role in maintaining network cohesion, bridging
#' subgroups, and preventing fragmentation.
#'
#' Unlike stars or hubs, glue guys work behind the scenes to keep the team connected.
#' They may not have the most connections or highest betweenness, but their removal
#' would significantly impact team cohesion and connectivity.
#'
#' @param g An igraph object representing the network
#' @param team_attr Optional character string specifying a vertex attribute for team/group
#'   membership. If provided, identifies glue guys who bridge between teams.
#' @param weight_var Optional character string specifying edge weight attribute.
#'   If provided, uses weighted metrics.
#' @param top_n Integer. Number of top glue guys to return. Default: 10
#' @param min_connections Integer. Minimum number of connections required to be
#'   considered. Filters out isolates. Default: 2
#' @param verbose Logical. Print detailed analysis? Default: TRUE
#'
#' @return A list with the following components:
#' \describe{
#'   \item{glue_scores}{Data frame with glue guy scores and component metrics for all nodes}
#'   \item{top_glue_guys}{Data frame of top N glue guys with interpretations}
#'   \item{network_impact}{Data frame showing impact of removing each top glue guy}
#'   \item{glue_guy_types}{Classification of glue guys by their primary mechanism}
#'   \item{summary_stats}{Overall network cohesion statistics}
#' }
#'
#' @details
#' The glue guy score is a composite measure based on six key dimensions:
#'
#' \strong{1. Structural Cohesion Impact (30%)}
#' - Measures how much network cohesion decreases if the node is removed
#' - Based on changes in clustering coefficient and component structure
#' - High impact = critical for holding network together
#'
#' \strong{2. Bridge Diversity (25%)}
#' - Counts connections to different subgroups/communities
#' - Weighted by how disconnected those groups are from each other
#' - High diversity = connects otherwise separate groups
#'
#' \strong{3. Redundancy Reduction (20%)}
#' - Identifies non-redundant connections (edges that would create structural holes if removed)
#' - Based on edge embeddedness and local bridge detection
#' - High score = provides unique, irreplaceable connections
#'
#' \strong{4. Balanced Connectivity (15%)}
#' - Rewards moderate, well-distributed connections over extreme centrality
#' - Penalizes both isolates and super-hubs
#' - High score = steady, reliable connector
#'
#' \strong{5. Reciprocity Facilitation (5%)}
#' - Measures involvement in reciprocal relationships
#' - Indicates mutual, stable connections
#' - High score = builds lasting relationships
#'
#' \strong{6. Transitivity Contribution (5%)}
#' - Measures participation in closed triads
#' - Indicates role in creating cohesive subgroups
#' - High score = helps form tight-knit clusters
#'
#' \strong{Glue Guy Types:}
#' - \strong{Bridge Builder}: Connects disparate groups (high bridge diversity)
#' - \strong{Cohesion Anchor}: Critical for overall network cohesion (high structural impact)
#' - \strong{Unique Connector}: Provides irreplaceable links (high redundancy reduction)
#' - \strong{Steady Connector}: Reliable, balanced connections (high balanced connectivity)
#' - \strong{Hybrid}: Combination of multiple mechanisms
#'
#' @references
#' Burt, R. S. (2004). Structural holes and good ideas. American Journal of Sociology, 110(2), 349-399.
#'
#' Moody, J., & White, D. R. (2003). Structural cohesion and embeddedness: A hierarchical
#' concept of social groups. American Sociological Review, 68(1), 103-127.
#'
#' Borgatti, S. P. (2006). Identifying sets of key players in a social network.
#' Computational & Mathematical Organization Theory, 12(1), 21-34.
#'
#' @examples
#' \dontrun{
#' library(igraph)
#' library(hineycombs)
#'
#' # Basic usage
#' results <- identify_glue_guys(g)
#'
#' # View top glue guys
#' print(results$top_glue_guys)
#'
#' # See network impact of removing them
#' print(results$network_impact)
#'
#' # With team attribute to identify cross-team bridges
#' results <- identify_glue_guys(g, team_attr = "department")
#'
#' # With edge weights
#' results <- identify_glue_guys(g, weight_var = "weight", top_n = 5)
#' }
#'
#' @importFrom igraph V E degree betweenness transitivity constraint vcount ecount
#' @importFrom igraph delete_vertices components cluster_louvain membership
#' @importFrom igraph as.undirected is_directed vertex_attr edge_attr
#' @importFrom igraph neighborhood induced_subgraph graph.density
#' @importFrom dplyr arrange desc mutate select
#' @export
run_identify_glue_guys <- function(g,
                                team_attr = NULL,
                                weight_var = NULL,
                                top_n = 10,
                                min_connections = 2,
                                verbose = TRUE) {
  
  if (!inherits(g, "igraph")) stop("g must be an igraph object")
  
  if (verbose) {
    cat("=== Glue Guy Analysis ===\n")
    cat("Identifying team cohesion maintainers...\n\n")
  }
  
  # Convert to undirected for cohesion analysis
  if (igraph::is_directed(g)) {
    g_undirected <- igraph::as.undirected(g, mode = "collapse")
    if (verbose) cat("Note: Using undirected version for cohesion analysis\n")
  } else {
    g_undirected <- g
  }
  
  n <- igraph::vcount(g)
  node_names <- igraph::V(g)$name
  if (is.null(node_names)) node_names <- as.character(1:n)
  
  # Initialize results data frame
  results <- data.frame(
    name = node_names,
    degree = igraph::degree(g_undirected),
    stringsAsFactors = FALSE
  )
  
  # Filter by minimum connections
  results <- results[results$degree >= min_connections, ]
  
  if (nrow(results) == 0) {
    stop("No nodes meet the minimum connection threshold")
  }
  
  if (verbose) cat("Analyzing", nrow(results), "nodes with >=", min_connections, "connections\n\n")
  
  # ============================================================================
  # 1. STRUCTURAL COHESION IMPACT (30%)
  # ============================================================================
  if (verbose) cat("1. Calculating structural cohesion impact...\n")
  
  baseline_transitivity <- igraph::transitivity(g_undirected, type = "global")
  baseline_components <- igraph::components(g_undirected)$no
  baseline_density <- igraph::graph.density(g_undirected)
  
  cohesion_impact <- sapply(results$name, function(node_name) {
    node_idx <- which(igraph::V(g_undirected)$name == node_name)
    if (length(node_idx) == 0) node_idx <- which(as.character(1:n) == node_name)
    
    g_removed <- igraph::delete_vertices(g_undirected, node_idx)
    
    new_transitivity <- igraph::transitivity(g_removed, type = "global")
    new_components <- igraph::components(g_removed)$no
    new_density <- igraph::graph.density(g_removed)
    
    # Calculate impact (higher = more important for cohesion)
    trans_impact <- ifelse(is.na(baseline_transitivity) || is.na(new_transitivity), 0,
                          (baseline_transitivity - new_transitivity) / (baseline_transitivity + 0.001))
    comp_impact <- (new_components - baseline_components) / baseline_components
    dens_impact <- (baseline_density - new_density) / (baseline_density + 0.001)
    
    # Composite cohesion impact
    mean(c(trans_impact, comp_impact * 2, dens_impact), na.rm = TRUE)
  })
  
  results$cohesion_impact <- cohesion_impact
  results$cohesion_impact_s <- scale(cohesion_impact)[,1]
  
  # ============================================================================
  # 2. BRIDGE DIVERSITY (25%)
  # ============================================================================
  if (verbose) cat("2. Calculating bridge diversity...\n")
  
  # Detect communities
  communities <- igraph::cluster_louvain(g_undirected)
  membership_vec <- igraph::membership(communities)
  
  # If team attribute provided, use that instead
  if (!is.null(team_attr) && team_attr %in% igraph::vertex_attr_names(g)) {
    membership_vec <- as.numeric(as.factor(igraph::vertex_attr(g, team_attr)))
    if (verbose) cat("   Using team attribute:", team_attr, "\n")
  }
  
  bridge_diversity <- sapply(results$name, function(node_name) {
    node_idx <- which(igraph::V(g_undirected)$name == node_name)
    if (length(node_idx) == 0) node_idx <- which(as.character(1:n) == node_name)
    
    node_community <- membership_vec[node_idx]
    neighbors_idx <- igraph::neighbors(g_undirected, node_idx)
    
    if (length(neighbors_idx) == 0) return(0)
    
    neighbor_communities <- membership_vec[neighbors_idx]
    
    # Count unique communities connected to
    unique_communities <- length(unique(neighbor_communities))
    
    # Weight by proportion of connections to other communities
    cross_community_prop <- mean(neighbor_communities != node_community)
    
    # Diversity score
    unique_communities * cross_community_prop
  })
  
  results$bridge_diversity <- bridge_diversity
  results$bridge_diversity_s <- scale(bridge_diversity)[,1]
  
  # ============================================================================
  # 3. REDUNDANCY REDUCTION (20%)
  # ============================================================================
  if (verbose) cat("3. Calculating redundancy reduction...\n")
  
  redundancy_reduction <- sapply(results$name, function(node_name) {
    node_idx <- which(igraph::V(g_undirected)$name == node_name)
    if (length(node_idx) == 0) node_idx <- which(as.character(1:n) == node_name)
    
    neighbors_idx <- igraph::neighbors(g_undirected, node_idx)
    
    if (length(neighbors_idx) <= 1) return(0)
    
    # Count non-redundant connections (neighbors not connected to each other)
    neighbor_subgraph <- igraph::induced_subgraph(g_undirected, neighbors_idx)
    neighbor_edges <- igraph::ecount(neighbor_subgraph)
    max_possible_edges <- length(neighbors_idx) * (length(neighbors_idx) - 1) / 2
    
    # Proportion of neighbors NOT connected (structural holes)
    if (max_possible_edges == 0) return(0)
    
    structural_holes <- 1 - (neighbor_edges / max_possible_edges)
    
    # Weight by constraint (Burt's measure)
    constraint_val <- igraph::constraint(g_undirected, nodes = node_idx)
    
    # Lower constraint + more structural holes = higher redundancy reduction
    structural_holes * (1 - min(constraint_val, 1))
  })
  
  results$redundancy_reduction <- redundancy_reduction
  results$redundancy_reduction_s <- scale(redundancy_reduction)[,1]
  
  # ============================================================================
  # 4. BALANCED CONNECTIVITY (15%)
  # ============================================================================
  if (verbose) cat("4. Calculating balanced connectivity...\n")
  
  # Reward moderate, well-distributed connections
  mean_degree <- mean(results$degree)
  sd_degree <- sd(results$degree)
  
  balanced_connectivity <- sapply(results$degree, function(d) {
    # Penalize extremes (both too low and too high)
    z_score <- abs((d - mean_degree) / sd_degree)
    
    # Optimal range is within 1 SD of mean
    if (z_score <= 1) {
      return(1 - z_score * 0.2)  # Slight penalty within 1 SD
    } else {
      return(max(0, 1 - (z_score - 1) * 0.5))  # Larger penalty beyond 1 SD
    }
  })
  
  results$balanced_connectivity <- balanced_connectivity
  results$balanced_connectivity_s <- scale(balanced_connectivity)[,1]
  
  # ============================================================================
  # 5. RECIPROCITY FACILITATION (5%) - for directed networks
  # ============================================================================
  if (verbose) cat("5. Calculating reciprocity facilitation...\n")
  
  if (igraph::is_directed(g)) {
    reciprocity_facilitation <- sapply(results$name, function(node_name) {
      node_idx <- which(igraph::V(g)$name == node_name)
      if (length(node_idx) == 0) node_idx <- which(as.character(1:n) == node_name)
      
      out_neighbors <- igraph::neighbors(g, node_idx, mode = "out")
      in_neighbors <- igraph::neighbors(g, node_idx, mode = "in")
      
      if (length(out_neighbors) == 0 && length(in_neighbors) == 0) return(0)
      
      # Proportion of reciprocal connections
      mutual <- length(intersect(out_neighbors, in_neighbors))
      total <- length(union(out_neighbors, in_neighbors))
      
      if (total == 0) return(0)
      mutual / total
    })
  } else {
    # For undirected, use local transitivity as proxy
    reciprocity_facilitation <- igraph::transitivity(g_undirected, type = "local")
    reciprocity_facilitation[is.na(reciprocity_facilitation)] <- 0
    reciprocity_facilitation <- reciprocity_facilitation[match(results$name, node_names)]
  }
  
  results$reciprocity_facilitation <- reciprocity_facilitation
  results$reciprocity_facilitation_s <- scale(reciprocity_facilitation)[,1]
  
  # ============================================================================
  # 6. TRANSITIVITY CONTRIBUTION (5%)
  # ============================================================================
  if (verbose) cat("6. Calculating transitivity contribution...\n")
  
  local_transitivity <- igraph::transitivity(g_undirected, type = "local")
  local_transitivity[is.na(local_transitivity)] <- 0
  
  results$transitivity_contribution <- local_transitivity[match(results$name, node_names)]
  results$transitivity_contribution_s <- scale(results$transitivity_contribution)[,1]
  
  # ============================================================================
  # COMPOSITE GLUE GUY SCORE
  # ============================================================================
  if (verbose) cat("\n7. Computing composite glue guy scores...\n")
  
  results$glue_score <- (
    0.30 * results$cohesion_impact_s +
    0.25 * results$bridge_diversity_s +
    0.20 * results$redundancy_reduction_s +
    0.15 * results$balanced_connectivity_s +
    0.05 * results$reciprocity_facilitation_s +
    0.05 * results$transitivity_contribution_s
  )
  
  # Normalize to 0-100 scale
  results$glue_score_normalized <- scales::rescale(results$glue_score, to = c(0, 100))
  
  # Sort by glue score
  results <- results[order(-results$glue_score_normalized), ]
  
  # ============================================================================
  # CLASSIFY GLUE GUY TYPES
  # ============================================================================
  if (verbose) cat("8. Classifying glue guy types...\n")
  
  results$glue_type <- sapply(1:nrow(results), function(i) {
    scores <- c(
      cohesion = results$cohesion_impact_s[i],
      bridge = results$bridge_diversity_s[i],
      unique = results$redundancy_reduction_s[i],
      balanced = results$balanced_connectivity_s[i]
    )
    
    max_score <- max(scores)
    top_mechanisms <- names(scores)[scores >= max_score - 0.5]
    
    if (length(top_mechanisms) >= 3) {
      return("Hybrid")
    } else if ("cohesion" %in% top_mechanisms) {
      return("Cohesion Anchor")
    } else if ("bridge" %in% top_mechanisms) {
      return("Bridge Builder")
    } else if ("unique" %in% top_mechanisms) {
      return("Unique Connector")
    } else {
      return("Steady Connector")
    }
  })
  
  # ============================================================================
  # TOP GLUE GUYS
  # ============================================================================
  top_glue <- head(results, top_n)
  
  top_glue$interpretation <- sapply(1:nrow(top_glue), function(i) {
    type <- top_glue$glue_type[i]
    score <- round(top_glue$glue_score_normalized[i], 1)
    
    base_msg <- paste0("Glue Score: ", score, "/100. ")
    
    type_msg <- switch(type,
      "Cohesion Anchor" = "Critical for overall network cohesion - removal would fragment the team.",
      "Bridge Builder" = "Connects disparate groups - bridges between otherwise separate subgroups.",
      "Unique Connector" = "Provides irreplaceable connections - fills structural holes in the network.",
      "Steady Connector" = "Reliable, balanced connector - maintains steady relationships across the network.",
      "Hybrid" = "Multi-faceted glue guy - combines multiple cohesion mechanisms."
    )
    
    paste0(base_msg, type_msg)
  })
  
  # ============================================================================
  # NETWORK IMPACT ANALYSIS
  # ============================================================================
  if (verbose) cat("9. Analyzing network impact of top glue guys...\n")
  
  network_impact <- data.frame(
    name = top_glue$name,
    glue_score = round(top_glue$glue_score_normalized, 1),
    cohesion_impact_pct = round(top_glue$cohesion_impact * 100, 1),
    communities_bridged = round(top_glue$bridge_diversity, 1),
    structural_holes_filled = round(top_glue$redundancy_reduction, 2),
    stringsAsFactors = FALSE
  )
  
  # ============================================================================
  # SUMMARY STATISTICS
  # ============================================================================
  summary_stats <- list(
    total_nodes = n,
    nodes_analyzed = nrow(results),
    baseline_transitivity = round(baseline_transitivity, 3),
    baseline_components = baseline_components,
    baseline_density = round(baseline_density, 3),
    mean_glue_score = round(mean(results$glue_score_normalized), 1),
    top_glue_score = round(max(results$glue_score_normalized), 1),
    glue_type_distribution = table(results$glue_type)
  )
  
  # ============================================================================
  # OUTPUT
  # ============================================================================
  if (verbose) {
    cat("\n=== Top", top_n, "Glue Guys ===\n")
    for (i in 1:nrow(top_glue)) {
      cat(i, ". ", top_glue$name[i], " (", top_glue$glue_type[i], ")\n", sep = "")
      cat("   ", top_glue$interpretation[i], "\n\n", sep = "")
    }
    
    cat("=== Glue Guy Type Distribution ===\n")
    print(summary_stats$glue_type_distribution)
    cat("\n")
  }
  
  list(
    glue_scores = results,
    top_glue_guys = top_glue[, c("name", "glue_score_normalized", "glue_type", "interpretation",
                                  "degree", "cohesion_impact", "bridge_diversity",
                                  "redundancy_reduction", "balanced_connectivity")],
    network_impact = network_impact,
    glue_guy_types = table(results$glue_type),
    summary_stats = summary_stats
  )
}
